/* ═══════════════════════════════════════════════════════════
   SPX Faculty Command Center — sections.js (Part 2)
   Projects, Exams, Mocks, Interviews, Attendance, Profile
   + All form event handlers
   ═══════════════════════════════════════════════════════════ */

// ─── SECTION 3: PROJECTS ──────────────────────────────────────
async function renderProjects(main) {
  const projs = await api('/api/projects/list');
  if (!projs) return;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Strategic Projects</h2>
        <p class="section-sub">${projs.length} active operations</p>
      </div>
      <button class="btn" onclick="openModal('projectModal')">＋ Deploy Project</button>
    </div>
    ${projs.length === 0 ? `<div class="empty-state"><div class="empty-icon">🚀</div><h3>No Projects</h3><p>Deploy your first collaborative project above.</p></div>` :
    `<div style="display:flex;flex-direction:column;gap:1.2rem;animation: fadeUp 0.4s both">
      ${projs.map(p => {
        const statusColor = p.status==='completed'?'#22c55e':p.status==='on_hold'?'#eab308':'#4f46e5';
        const dl = p.deadline ? new Date(p.deadline).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : '—';
        return `
        <div class="glass-panel hover-card" style="display:flex;justify-content:space-between;align-items:center;gap:1.5rem;flex-wrap:wrap;padding:1.5rem 2rem;">
          <div style="display:flex;align-items:center;gap:1.5rem;flex:1;">
            <div style="width:48px;height:48px;background:var(--accent-gradient);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0;">🚀</div>
            <div>
              <h4 style="margin-bottom:0.2rem;">${p.title}</h4>
              <p style="font-size:0.78rem;color:var(--text-light);margin-bottom:0.4rem;">${p.description.substring(0,80)}${p.description.length>80?'...':''}</p>
              <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                <span style="font-size:0.72rem;color:var(--text-muted)">📅 ${dl}</span>
                ${p.tech_stack?`<span style="font-size:0.72rem;color:var(--text-muted)">⚙️ ${p.tech_stack}</span>`:''}
                <span style="font-size:0.72rem;color:var(--text-muted)">👥 ${p.team_members&&p.team_members.length>0?p.team_members.length+' members':'Open Team'}</span>
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:2rem;flex-shrink:0;">
            <div style="text-align:right;min-width:160px;">
              <div class="progress-bar" style="margin-bottom:0.4rem;"><div class="progress-fill" style="width:${p.progress||0}%"></div></div>
              <span style="font-size:0.72rem;font-weight:700;color:${statusColor}">${p.progress||0}% · ${(p.status||'in_progress').replace('_',' ').toUpperCase()}</span>
            </div>
            <div style="display:flex;gap:0.5rem;">
              <button class="btn btn-sm btn-secondary" onclick="openProgressModal('${p._id}',${p.progress||0},'${p.status||'in_progress'}')">✏️ Update</button>
              <button class="btn btn-sm btn-danger" onclick="deleteProject('${p._id}')">🗑️</button>
            </div>
          </div>
        </div>`;
      }).join('')}
    </div>`}`;
}

function openProgressModal(id, progress, status) {
  document.getElementById('progressProjectId').value = id;
  document.getElementById('progressValue').value = progress;
  document.getElementById('progressStatus').value = status;
  openModal('progressModal');
}

async function submitProgressUpdate() {
  const id  = document.getElementById('progressProjectId').value;
  const v   = parseInt(document.getElementById('progressValue').value);
  const st  = document.getElementById('progressStatus').value;
  const res = await api(`/api/projects/${id}`, 'PATCH', { progress: v, status: st });
  if (res) { showToast('Project updated!', 'success'); closeModal('progressModal'); switchSection('projects'); }
}

async function deleteProject(id) {
  if (!confirm('Decommission this project?')) return;
  const res = await api(`/api/projects/${id}`, 'DELETE');
  if (res) { showToast('Project deleted.', 'success'); switchSection('projects'); }
}

// ─── SECTION 4: EXAMS ─────────────────────────────────────────
async function renderExams(main) {
  const exams = await api('/api/exams/list');
  if (!exams) return;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Examination Terminal</h2>
        <p class="section-sub">${exams.length} assessments · Toggle to publish to interns</p>
      </div>
      <div style="display:flex;gap:1rem;">
        <button class="btn btn-secondary" onclick="openAIModal()">✨ Generate with AI</button>
        <button class="btn" onclick="openModal('examModal')">＋ Create Exam</button>
      </div>
    </div>
    ${exams.length===0 ? `<div class="empty-state"><div class="empty-icon">🧠</div><h3>No Exams</h3><p>Initialize your first assessment above.</p></div>` :
    `<div class="table-wrapper fade-up">
      <table>
        <thead><tr><th>Exam</th><th>Type</th><th>Duration</th><th>Anti-Cheat</th><th>Results</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          ${exams.map(e=>`
          <tr>
            <td>
              <p style="font-weight:700">${e.title}</p>
              <p style="font-size:0.72rem;color:var(--text-muted)">${e.description?e.description.substring(0,50):''}</p>
            </td>
            <td><span class="badge badge-assigned">${e.type}</span></td>
            <td style="font-weight:600">${e.duration_minutes} min</td>
            <td>
              <div style="display:flex;gap:0.3rem;flex-wrap:wrap;">
                ${e.anti_cheating?.disable_tab_switch?'<span title="Tab block" style="font-size:1rem;">🔒</span>':''}
                ${e.anti_cheating?.disable_copy_paste?'<span title="Clipboard block" style="font-size:1rem;">📋</span>':''}
                ${e.anti_cheating?.disable_right_click?'<span title="Right-click block" style="font-size:1rem;">🖱️</span>':''}
              </div>
            </td>
            <td>
              <div style="display:flex;gap:0.4rem;">
                <button class="btn btn-sm btn-secondary" onclick="viewExamResults('${e._id}','${e.title.replace(/'/g,"\\'")}')">📊 ${e.results_count||0}</button>
                <button class="btn btn-sm" onclick="openQuestionsModal('${e._id}','${e.title.replace(/'/g,"\\'")}')">🧠 Q's</button>
              </div>
            </td>
            <td>
              <label class="toggle" title="${e.is_active?'Click to disable':'Click to enable'}">
                <input type="checkbox" ${e.is_active?'checked':''} onchange="toggleExam('${e._id}',this.checked)">
                <span class="toggle-slider"></span>
              </label>
            </td>
            <td>
              <div style="display:flex;gap:0.5rem;">
                <button class="btn btn-sm btn-success" onclick="openLiveMonitor('${e._id}','${e.title.replace(/'/g,"\\'")}')">🛰️ Live</button>
                <button class="btn btn-sm btn-danger" onclick="deleteExam('${e._id}')">🗑️</button>
              </div>
            </td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`}`;
}

async function toggleExam(id, status) {
  const res = await api(`/api/exams/toggle/${id}?is_active=${status}`, 'PATCH');
  if (res) showToast(status ? 'Exam is now LIVE 🛰️' : 'Exam set OFFLINE', status ? 'success' : 'info');
}

async function deleteExam(id) {
  if (!confirm('Delete this exam?')) return;
  const res = await api(`/api/exams/${id}`, 'DELETE');
  if (res) { showToast('Exam deleted.', 'success'); switchSection('exams'); }
}

async function openLiveMonitor(examId, title) {
    const drafts = await api(`/api/exams/drafts/${examId}`);
    if (!drafts) return;

    window._submissionRegistry = window._submissionRegistry || {};

    const el = document.createElement('div');
    el.className = 'modal-overlay active'; el.style.display='flex'; el.id='liveMonitorModal';
    el.innerHTML=`<div class="modal-box modal-wide" style="max-width:1100px;">
        <div class="modal-header">
            <div><h2>🛰️ Live Examination Monitor</h2><p>${title} · ${drafts.length} Active Sessions</p></div>
            <button class="modal-close" onclick="document.getElementById('liveMonitorModal').remove()">✕</button>
        </div>
        ${drafts.length === 0 ? '<div class="empty-state"><p>No interns are currently active in this exam.</p></div>' :
        `<div class="table-wrapper"><table>
            <thead><tr><th>Intern ID</th><th>Network Origin</th><th>Progress</th><th>Time Remaining</th><th>Last Sync</th><th>Action</th></tr></thead>
            <tbody>${drafts.map((d, di) => {
                const regId = `live_${di}`;
                window._submissionRegistry[regId] = d.answers;
                return `<tr>
                    <td><p style="font-weight:700">${d.student_id}</p></td>
                    <td><code style="font-size:0.75rem; color:var(--accent-light);">${d.client_ip || '---'}</code></td>
                    <td>
                        <div style="font-size:0.75rem; color:var(--text-muted);">
                            ${(d.answers || []).filter(a => a !== null && a !== '').length} / ${(d.answers || []).length} items addressed
                        </div>
                    </td>
                    <td><span style="font-weight:700; color:#ef4444;">${Math.floor((d.time_remaining || 0) / 60)}m ${(d.time_remaining || 0) % 60}s</span></td>
                    <td style="font-size:0.78rem">${d.updated_at ? new Date(d.updated_at).toLocaleTimeString() : 'Recently'}</td>
                    <td>
                        <button class="btn btn-sm btn-secondary" onclick="viewStudentExamAnswersByRegistry('${regId}', 'LIVE: ${d.student_id}')">🛰️ Spy Draft</button>
                    </td>
                </tr>`;
            }).join('')}</tbody>
        </table></div>`}
    </div>`;
    document.body.appendChild(el);
    el.onclick = e => { if (e.target === el) el.remove(); };
}

window.viewStudentExamAnswersByRegistry = function(regId, name) {
    const entry = window._submissionRegistry ? window._submissionRegistry[regId] : { answers: [] };
    const answers = Array.isArray(entry) ? entry : (entry.answers || []);
    const submissionId = entry._id || entry.submissionId || null;
    const violations = entry.violation_details || [];
    viewStudentExamAnswers(answers, name, submissionId, violations);
};

async function viewExamResults(examId, title) { 
  const results = await api(`/api/exams/results/${examId}`);
  if (!results) return;

  window._submissionRegistry = window._submissionRegistry || {};

  const el = document.createElement('div');
  el.className = 'modal-overlay active'; el.style.display='flex'; el.id='examResModal';
  el.innerHTML=`<div class="modal-box modal-wide" style="max-width:1100px;">
    <div class="modal-header">
      <div><h2>Exam Results & Submissions</h2><p>${title}</p></div>
      <button class="modal-close" onclick="document.getElementById('examResModal').remove()">✕</button>
    </div>
    ${results.length===0?'<div class="empty-state"><p>No submissions yet.</p></div>':
    `<div class="table-wrapper"><table>
      <thead><tr><th>Intern</th><th>Score</th><th>Flags</th><th>Submitted</th><th>Action</th></tr></thead>
      <tbody>${results.map((r, idx)=>{
        const regId = `exam_res_${idx}`;
        window._submissionRegistry[regId] = r; // Store full result
        return `<tr>
          <td><p style="font-weight:700">${r.student_name||r.student_id}</p><p style="font-size:0.7rem;color:var(--text-muted)">${r.student_id}</p></td>
          <td class="score-badge">${r.score??'—'} / ${r.max_score||'100'}</td>
          <td>${(r.violation_count||0) > 0 ? `<span class="badge badge-inactive" style="background:#fee2e2; color:#ef4444; border:1px solid #fecaca;">⚠️ ${r.violation_count} violations</span>` : '<span class="badge badge-graded">Clean</span>'}</td>
          <td style="font-size:0.78rem">${r.submitted_at?new Date(r.submitted_at).toLocaleString('en-IN'):''}</td>
          <td>
             <button class="btn btn-sm btn-secondary" onclick="viewStudentExamAnswersByRegistry('${regId}', '${r.student_name||r.student_id}')">👁️ Audit Details</button>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`}
  </div>`;
  document.body.appendChild(el);
  el.onclick = e => { if(e.target===el) el.remove(); };
}

window.viewStudentExamAnswers = function(answers, name, submissionId = null, violations = []) {
    const el = document.createElement('div');
    el.className = 'modal-overlay active'; el.style.display='flex'; el.id='studentAnsModal';
    el.style.zIndex = '2000';
    el.innerHTML=`<div class="modal-box modal-wide" style="max-width:900px; max-height:85vh; display:flex; flex-direction:column;">
      <div class="modal-header">
        <div><h2>Student Submission Detail</h2><p>Intern: ${name}</p></div>
        <div style="display:flex; gap:1rem; align-items:center;">
            ${submissionId ? `<button class="btn btn-sm accent-gradient" onclick="loadAIReview('${submissionId}')">✨ View AI Insights</button>` : ''}
            <button class="modal-close" onclick="document.getElementById('studentAnsModal').remove()">✕</button>
        </div>
      </div>
      
      <div style="flex:1; overflow-y:auto; padding:1.5rem;">
        <div id="aiReviewContainer" style="display:none; margin-bottom: 2rem;"></div>

        <!-- NEW: Violation Audit Section -->
        <div style="margin-bottom:2rem; background:#fff; border:1.5px solid ${violations.length > 0 ? '#fecaca' : '#e2e8f0'}; border-radius:16px; overflow:hidden;">
            <div style="background:${violations.length > 0 ? '#fee2e2' : '#f8fafc'}; padding:1rem 1.5rem; border-bottom:1.5px solid ${violations.length > 0 ? '#fecaca' : '#e2e8f0'}; display:flex; justify-content:space-between; align-items:center;">
                <h3 style="font-size:0.95rem; font-weight:800; color:${violations.length > 0 ? '#dc2626' : 'var(--text-main)'}; display:flex; align-items:center; gap:0.6rem;">
                    🛡️ Security Audit Log
                    ${violations.length > 0 ? `<span class="badge badge-inactive" style="background:#dc2626; color:#fff;">${violations.length} VIOLATIONS</span>` : '<span class="badge badge-graded">SESSION SECURE</span>'}
                </h3>
            </div>
            <div style="padding:1.5rem;">
                ${violations.length === 0 ? `
                    <p style="color:var(--text-light); font-size:0.85rem; text-align:center; padding:1rem;">No security violations detected during this assessment.</p>
                ` : `
                    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(250px, 1fr)); gap:1rem;">
                        ${violations.map(v => `
                            <div style="background:#fef2f2; border:1px solid #fee2e2; border-radius:10px; padding:0.8rem; display:flex; gap:0.8rem; align-items:center;">
                                <div style="width:32px; height:32px; background:#fee2e2; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#dc2626; font-weight:900;">!</div>
                                <div>
                                    <p style="font-weight:800; color:#dc2626; font-size:0.8rem; margin-bottom:0.1rem;">${v.reason}</p>
                                    <p style="font-size:0.68rem; color:var(--text-muted);">${new Date(v.timestamp).toLocaleString('en-IN')}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `}
            </div>
        </div>

        <h3 style="font-size:1.1rem; font-weight:800; margin-bottom:1.2rem; color:var(--text-sub);">Assessment Response Artifacts</h3>
        <div style="display:flex; flex-direction:column; gap:1.5rem;">
          ${(answers||[]).map((ans, i) => `
              <div style="background:#fff; border:1.5px solid #e2e8f0; border-radius:16px; padding:1.5rem; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
                  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                    <h4 style="color:var(--primary); font-weight:800; font-size:0.95rem;">Question ${i+1}</h4>
                    <span class="badge" style="background:var(--primary)10; color:var(--primary);">${typeof ans === 'string' ? 'CODING' : 'MCQ'}</span>
                  </div>
                  ${typeof ans === 'string' ? `
                      <div style="position:relative;">
                        <div style="position:absolute; top:1rem; right:1rem; color:rgba(255,255,255,0.4); font-size:0.65rem; font-weight:900; letter-spacing:1px;">SOURCE CODE</div>
                        <pre style="background:#0f172a; color:#cbd5e1; padding:1.5rem; border-radius:12px; font-family:'Fira Code', monospace; font-size:0.85rem; overflow-x:auto; line-height:1.6; border:1px solid rgba(255,255,255,0.1);">${esc(ans)}</pre>
                      </div>
                  ` : `
                      <div style="background:#f8fafc; border-radius:12px; padding:1rem; border:1px solid #e2e8f0;">
                        <p style="font-weight:700; color:var(--text-main);">Selected Option Index: <span style="color:var(--primary); font-size:1.1rem; margin-left:0.5rem;">${ans !== null ? (typeof ans === 'object' ? (ans.answer_index ?? JSON.stringify(ans)) : ans) : 'No answer'}</span></p>
                      </div>
                  `}
              </div>
          `).join('')}
        </div>
      </div>
    </div>`;
    document.body.appendChild(el);
    el.onclick = e => { if(e.target===el) el.remove(); };
}

window.loadAIReview = function(submissionId) {
    const container = document.getElementById('aiReviewContainer');
    container.style.display = 'block';
    window.aiPanel = new AIReviewPanel('aiReviewContainer');
    window.aiPanel.fetchAndRender(submissionId);
};

// ─── SECTION 5: MOCKS ─────────────────────────────────────────
async function renderMocks(main) {
  const mocks = await api('/api/mocks/list');
  if (!mocks) return;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Mock Exam Terminal</h2>
        <p class="section-sub">${mocks.length} assessments · Toggle to publish diagnostic mocks</p>
      </div>
      <button class="btn" onclick="openModal('mockModal')">＋ Deploy Mock</button>
    </div>
    ${mocks.length===0?`<div class="empty-state"><div class="empty-icon">📝</div><h3>No Mocks</h3><p>Deploy diagnostic mocks above.</p></div>`:
    `<div class="table-wrapper fade-up"><table>
      <thead><tr><th>Mock</th><th>Category</th><th>Duration</th><th>Results</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>${mocks.map(m=>`
      <tr>
        <td><p style="font-weight:700">${m.title}</p><p style="font-size:0.72rem;color:var(--text-muted)">${m.description||''}</p></td>
        <td><span class="badge badge-assigned">${m.category||'General'}</span></td>
        <td>${m.duration} min</td>
        <td>
          <div style="display:flex;gap:0.4rem;flex-wrap:wrap;">
            <button class="btn btn-sm btn-secondary" onclick="viewMockResults('${m._id}','${m.title.replace(/'/g,"\\'")}')">📊 ${m.results_count||0}</button>
            <button class="btn btn-sm" onclick="openMockQuestionsModal('${m._id}','${m.title.replace(/'/g,"\\'")}')">🧠 Q's</button>
          </div>
        </td>
        <td><label class="toggle">
          <input type="checkbox" ${m.is_active?'checked':''} onchange="toggleMock('${m._id}',this.checked)">
          <span class="toggle-slider"></span>
        </label></td>
        <td><button class="btn btn-sm btn-danger" onclick="deleteMock('${m._id}')">🗑️</button></td>
      </tr>`).join('')}</tbody>
    </table></div>`}`;
}

async function toggleMock(id, status) {
  const res = await api(`/api/mocks/toggle/${id}?is_active=${status}`, 'PATCH');
  if (res) showToast(status ? 'Mock is now LIVE' : 'Mock set OFFLINE', 'info');
}

async function deleteMock(id) {
  if (!confirm('Delete this mock?')) return;
  const res = await api(`/api/mocks/${id}`, 'DELETE');
  if (res) { showToast('Mock deleted.', 'success'); switchSection('mocks'); }
}

async function viewMockResults(mockId, title) {
  const results = await api(`/api/mocks/results/${mockId}`);
  if (!results) return;

  window._submissionRegistry = window._submissionRegistry || {};

  const el = document.createElement('div');
  el.className = 'modal-overlay active';
  el.style.display = 'flex';
  el.id = 'mockResModal';
  el.innerHTML = `<div class="modal-box modal-wide" style="max-width:1100px;">
    <div class="modal-header">
      <div><h2>Mock Submissions</h2><p>${title}</p></div>
      <button class="modal-close" onclick="document.getElementById('mockResModal').remove()">✕</button>
    </div>
    ${results.length===0?'<div class="empty-state"><p>No submissions yet.</p></div>':
    `<div class="table-wrapper"><table>
      <thead><tr><th>Intern</th><th>Score</th><th>Flags</th><th>Submitted</th><th>Action</th></tr></thead>
      <tbody>${results.map((r, idx)=>{
        const regId = `mock_res_${idx}`;
        window._submissionRegistry[regId] = { answers: r.answers, submissionId: r._id };
        return `<tr>
          <td><p style="font-weight:700">${r.student_name||r.student_id}</p><p style="font-size:0.72rem;color:var(--text-muted)">${r.student_id||''}</p></td>
          <td class="score-badge">${r.score??'—'}${r.max_score!==undefined?` / ${r.max_score}`:''}</td>
          <td>${(r.violation_count||0) > 0 ? `<span class="badge badge-inactive">${r.violation_count} flag(s)</span>` : '<span class="badge badge-graded">Clean</span>'}</td>
          <td style="font-size:0.78rem">${r.submitted_at?new Date(r.submitted_at).toLocaleString('en-IN'):''}</td>
          <td>
             <button class="btn btn-sm btn-secondary" onclick="viewStudentExamAnswersByRegistry('${regId}', '${r.student_name||r.student_id}')">👁️ View Answers</button>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`}
  </div>`;
  document.body.appendChild(el);
  el.onclick = e => { if (e.target === el) el.remove(); };
}

// ─── SECTION 6: INTERVIEWS ────────────────────────────────────
async function renderInterviews(main) {
  const interviews = await api('/api/interviews/list');
  if (!interviews) return;

  const catCount = {};
  interviews.forEach(i => { catCount[i.category] = (catCount[i.category]||0) + 1; });
  const passCount = interviews.filter(i=>i.outcome==='Pass').length;
  const failCount = interviews.filter(i=>i.outcome==='Fail').length;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Interview Terminal</h2>
        <p class="section-sub">${interviews.length} sessions · ${passCount} passed · ${failCount} failed</p>
      </div>
      <button class="btn" onclick="openModal('interviewModal')">＋ Schedule Session</button>
    </div>

    <div class="stats-grid stagger" style="margin-bottom:2rem;">
      ${['Logic','Architecture','Soft Skills','Technical'].map(cat=>`
      <div class="stat-card">
        <div class="stat-label">${cat}</div>
        <div class="stat-value" style="font-size:1.8rem">${catCount[cat]||0}</div>
        <div class="stat-meta">sessions</div>
      </div>`).join('')}
    </div>

    ${interviews.length===0?`<div class="empty-state"><div class="empty-icon">🎙️</div><h3>No Interviews Scheduled</h3><p>Schedule your first session above.</p></div>`:
    `<div class="table-wrapper fade-up"><table>
      <thead><tr><th>Intern</th><th>Category</th><th>Scheduled (IST)</th><th>Duration</th><th>Score</th><th>Outcome</th><th>Actions</th></tr></thead>
      <tbody>${interviews.map(i=>{
        const dt = i.scheduled_at ? new Date(i.scheduled_at).toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}) : '—';
        const outClass = i.outcome==='Pass'?'badge-graded':i.outcome==='Fail'?'badge-inactive':'badge-submitted';
        return `<tr>
          <td><p style="font-weight:700">${i.intern_name||i.intern_email}</p><p style="font-size:0.72rem;color:var(--text-muted)">${i.intern_email}</p></td>
          <td><span class="badge badge-assigned">${i.category}</span></td>
          <td style="font-size:0.8rem">${dt}</td>
          <td>${i.duration_minutes||45} min</td>
          <td class="score-badge">${i.score!==null&&i.score!==undefined?i.score+'/100':'—'}</td>
          <td>${i.outcome?`<span class="badge ${outClass}">${i.outcome}</span>`:`<span style="color:var(--text-muted);font-size:0.75rem">Pending</span>`}</td>
          <td style="display:flex;gap:0.4rem;">
            ${i.status!=='Completed'?`<button class="btn btn-sm btn-success" onclick="openScoreModal('${i._id}')">🏆 Score</button>`:''}
            <button class="btn btn-sm btn-danger" onclick="cancelInterview('${i._id}')">🗑️</button>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`}`;
}

function openScoreModal(id) {
  document.getElementById('scoreInterviewId').value = id;
  document.getElementById('interviewScore').value = '';
  document.getElementById('interviewFeedback').value = '';
  openModal('scoreModal');
}

async function submitInterviewScore() {
  const id  = document.getElementById('scoreInterviewId').value;
  const res = await api(`/api/interviews/score/${id}`, 'POST', {
    score:    parseInt(document.getElementById('interviewScore').value),
    feedback: document.getElementById('interviewFeedback').value,
    outcome:  document.getElementById('interviewOutcome').value
  });
  if (res) { showToast('Score recorded ✅', 'success'); closeModal('scoreModal'); switchSection('interviews'); }
}

async function cancelInterview(id) {
  if (!confirm('Cancel this interview session?')) return;
  const res = await api(`/api/interviews/${id}`, 'DELETE');
  if (res) { showToast('Session cancelled.', 'info'); switchSection('interviews'); }
}

async function renderAttendance(main) {
  const [config, logs] = await Promise.all([
    api('/api/attendance/status'),
    api('/api/attendance/logs/today')
  ]);
  if (!config) return;

  window.currentAttendanceLogs = logs || [];

  const armed = config.is_active;
  const hasNetwork = !!config.allowed_ip_prefix;
  const hasGeo = !!(config.geo_lat && config.geo_lng);
  const networkSource = config.network_source || 'unknown';
  const networkSourceMeta = {
    manual: {
      label: 'Manual Prefix',
      color: '#0f766e',
      note: 'Configured from a manually provided network prefix.'
    },
    request: {
      label: 'Direct Client IP',
      color: '#2563eb',
      note: 'Captured directly from your dashboard request IP.'
    },
    host: {
      label: 'LAN Fallback',
      color: '#b45309',
      note: 'Client IP looked local/proxied; using detected server LAN network.'
    },
    unknown: {
      label: 'Not Captured',
      color: '#64748b',
      note: 'Capture network to activate reliable WiFi locking.'
    }
  };
  const activeNetworkSource = networkSourceMeta[networkSource] || networkSourceMeta.unknown;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Attendance Terminal</h2>
        <p class="section-sub">Scanner is <strong style="color:${armed?'#22c55e':'#ef4444'}">${armed?'ARMED ●':'DISARMED ●'}</strong> · ${(logs||[]).length} check-ins today</p>
      </div>
      <div style="display:flex; gap:0.8rem;">
        <button class="btn btn-secondary" style="border-color:#ef4444; color:#ef4444;" onclick="finalizeDay(this)">🕒 Finalize Day (10 PM)</button>
        <button class="btn btn-secondary" onclick="openAttendanceOverrideModal()">✏️ Manual Override</button>
      </div>
    </div>

    <!-- Master Toggle Panel -->
    <div class="att-panel ${armed?'armed':''} fade-up" style="margin-bottom:1.5rem;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;">
        <div>
          <h4 style="font-size:1.1rem;font-weight:800;margin-bottom:0.3rem;">Master Attendance Scanner</h4>
          <p style="font-size:0.82rem;color:var(--text-light)">When ARMED, interns on the correct network can check in from their dashboard.</p>
        </div>
        <label class="toggle" style="width:60px;height:32px;">
          <input type="checkbox" id="masterToggle" ${armed?'checked':''} onchange="handleAttToggle(this.checked)">
          <span class="toggle-slider"></span>
        </label>
      </div>

      <!-- Security Configuration Grid -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem;">

        <!-- IP / WiFi Card -->
        <div class="glass-panel" style="padding:1.4rem;background:var(--glass-bg);border-radius:16px;border-left:4px solid ${config.require_ip?'#4f46e5':'#e2e8f0'};">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.8rem;">
            <p style="font-weight:900;font-size:0.82rem;color:var(--primary);">🌐 WiFi NETWORK LOCK</p>
            <label class="toggle">
              <input type="checkbox" id="ipToggle" ${config.require_ip?'checked':''} onchange="toggleIpSection(this.checked)">
              <span class="toggle-slider"></span>
            </label>
          </div>
          <p style="font-size:0.75rem;color:var(--text-light);margin-bottom:1rem;">Only allow check-ins from the same WiFi network as this device.</p>
          <div id="ipConfigSection" style="${config.require_ip?'':'display:none;'}">
            <div style="background:rgba(255,255,255,0.58);border-radius:10px;padding:0.8rem;margin-bottom:0.8rem;">
              <p style="font-size:0.65rem;font-weight:900;color:var(--text-muted);text-transform:uppercase;margin-bottom:0.3rem;">REGISTERED NETWORK PREFIX</p>
              <p id="displayIpPrefix" style="font-size:0.9rem;font-weight:800;color:${hasNetwork?'#4f46e5':'#ef4444'};font-family:monospace;">
                ${hasNetwork ? config.allowed_ip_prefix+'.* ✔' : 'Not captured yet'}
              </p>
            </div>
            <input type="hidden" id="ipPrefixValue" value="${config.allowed_ip_prefix||''}">
            <button class="btn btn-sm" style="width:100%;" onclick="captureCurrentNetwork(this)">
              📡 Capture My Network
            </button>
          </div>
        </div>

        <!-- Geo Fence Card -->
        <div class="glass-panel" style="padding:1.4rem;background:var(--glass-bg);border-radius:16px;border-left:4px solid ${config.require_geo?'#4f46e5':'#e2e8f0'};">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.8rem;">
            <p style="font-weight:900;font-size:0.82rem;color:var(--primary);">📍 GEOFENCE RADAR</p>
            <label class="toggle">
              <input type="checkbox" id="geoToggle" ${config.require_geo?'checked':''} onchange="toggleGeoSection(this.checked)">
              <span class="toggle-slider"></span>
            </label>
          </div>
          <p style="font-size:0.75rem;color:var(--text-light);margin-bottom:1rem;">Enforce physical presence within a radius of the office.</p>
          <div id="geoConfigSection" style="${config.require_geo?'':'display:none;'}">
            <div style="background:rgba(255,255,255,0.58);border-radius:10px;padding:0.8rem;margin-bottom:0.8rem;">
              <p style="font-size:0.65rem;font-weight:900;color:var(--text-muted);text-transform:uppercase;margin-bottom:0.3rem;">REGISTERED OFFICE LOCATION</p>
              <p id="displayGeoCoords" style="font-size:0.85rem;font-weight:800;color:${hasGeo?'#4f46e5':'#ef4444'};font-family:monospace;">
                ${hasGeo ? `${config.geo_lat.toFixed(4)}°N, ${config.geo_lng.toFixed(4)}°E ✔` : 'Not captured yet'}
              </p>
            </div>
            <input type="hidden" id="geoLatValue" value="${config.geo_lat||''}">
            <input type="hidden" id="geoLngValue" value="${config.geo_lng||''}">
            <div style="display:flex;gap:0.5rem;margin-bottom:0.8rem;">
              <div style="flex:1;">
                <p style="font-size:0.65rem;color:var(--text-muted);margin-bottom:0.3rem;">RADIUS (meters)</p>
                <input type="number" id="geoRadius" value="${config.geo_radius_meters||200}" min="50" max="2000" style="background:rgba(255,255,255,0.68);padding:0.5rem;border-radius:8px;width:100%;font-size:0.85rem;">
              </div>
            </div>
            <button class="btn btn-sm" style="width:100%;" onclick="captureCurrentLocation(this)">
              🛰️ Set Office Location
            </button>
          </div>
        </div>
      </div>

      <!-- Network Source / Configure Metadata -->
      ${config.require_ip ? `
        <div style="display:flex; flex-wrap:wrap; gap:0.5rem; align-items:center; margin-bottom:0.7rem;">
          <span style="font-size:0.68rem; font-weight:900; letter-spacing:0.4px; color:var(--text-muted); text-transform:uppercase;">WiFi Lock Source</span>
          <span style="display:inline-flex; align-items:center; gap:0.35rem; padding:0.26rem 0.55rem; border-radius:999px; font-size:0.70rem; font-weight:800; color:${activeNetworkSource.color}; background:${activeNetworkSource.color}1a; border:1px solid ${activeNetworkSource.color}55;">
            ${activeNetworkSource.label}
          </span>
          <span style="font-size:0.72rem; color:var(--text-muted);">${activeNetworkSource.note}</span>
        </div>
      ` : ''}

      <!-- ID of configured by -->
      ${config.configured_by_ip ? `<p style="font-size:0.7rem;color:var(--text-muted);margin-bottom:0.8rem;">⚡ Last configured from IP: <code>${config.configured_by_ip}</code> · ${config.configured_at ? new Date(config.configured_at).toLocaleString('en-IN') : ''}</p>` : ''}

      <button class="btn" style="width:100%;" onclick="saveAttendanceConfig()">
        💾 Save & Apply Configuration
      </button>
    </div>

    <!-- Filter Bar -->
    <div class="glass-panel fade-up" style="margin-bottom:2rem; padding:1.5rem; display:flex; align-items:center; gap:1.5rem; flex-wrap:wrap; border-radius:24px; background:rgba(255,255,255,0.92); border:1px solid rgba(79, 70, 229, 0.08);">
      <div style="flex:1; min-width:240px;">
        <p style="font-size:0.68rem; font-weight:900; color:var(--primary); margin-bottom:0.6rem; text-transform:uppercase; letter-spacing:1px; display:flex; align-items:center; gap:0.4rem;">
          <span style="font-size:0.9rem;">📅</span> Select Timeframe
        </p>
        <div style="position:relative;">
          <select id="attFilterType" class="input-field" style="margin:0; border-radius:14px; background:#f8fafc; border:1.5px solid #e2e8f0; padding-left:1rem; height:48px; font-weight:600;" onchange="handleAttFilterChange(this.value)">
            <option value="daily">Daily (Today)</option>
            <option value="weekly">Weekly (Last 7 Days)</option>
            <option value="monthly">Monthly (This Month)</option>
            <option value="yearly">Yearly (This Year)</option>
            <option value="custom">Custom Range</option>
          </select>
        </div>
      </div>
      <div id="customDateRange" style="display:none; align-items:center; gap:1rem;">
        <div>
          <p style="font-size:0.68rem; font-weight:900; color:var(--text-muted); margin-bottom:0.6rem; text-transform:uppercase; letter-spacing:1px;">Start Date</p>
          <input type="date" id="attStartDate" class="input-field" style="margin:0; border-radius:14px; background:#f8fafc; border:1.5px solid #e2e8f0; height:48px;">
        </div>
        <div>
          <p style="font-size:0.68rem; font-weight:900; color:var(--text-muted); margin-bottom:0.6rem; text-transform:uppercase; letter-spacing:1px;">End Date</p>
          <input type="date" id="attEndDate" class="input-field" style="margin:0; border-radius:14px; background:#f8fafc; border:1.5px solid #e2e8f0; height:48px;">
        </div>
      </div>
      <button class="btn accent-gradient" style="margin-top:1.4rem; min-width:180px; height:48px; border-radius:14px; font-size:0.95rem; box-shadow:0 10px 20px rgba(79, 70, 229, 0.2);" onclick="loadFilteredLogs()">
        <span>🔍</span> Fetch Records
      </button>
    </div>

    <!-- Summary Stats Bar -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2rem; flex-wrap:wrap; gap:1.5rem; background:#fff; padding:1.5rem; border-radius:24px; border:1px solid rgba(79, 70, 229, 0.08);">
      <div style="display:flex; gap:2rem;">
        <div style="text-align:center;">
          <p style="font-size:0.65rem; font-weight:900; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; margin-bottom:0.3rem;">Total Records</p>
          <p id="sumTotal" style="font-size:1.4rem; font-weight:900; color:var(--text-main);">0</p>
        </div>
        <div style="text-align:center; border-left:1px solid #e2e8f0; padding-left:2rem;">
          <p style="font-size:0.65rem; font-weight:900; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; margin-bottom:0.3rem;">Unique Dates</p>
          <p id="sumDates" style="font-size:1.4rem; font-weight:900; color:var(--text-main);">0</p>
        </div>
        <div style="text-align:center; border-left:1px solid #e2e8f0; padding-left:2rem;">
          <p style="font-size:0.65rem; font-weight:900; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; margin-bottom:0.3rem;">Present Count</p>
          <p id="sumPresent" style="font-size:1.4rem; font-weight:900; color:var(--text-main);">0</p>
        </div>
        <div style="text-align:center; border-left:1px solid #e2e8f0; padding-left:2rem;">
          <p style="font-size:0.65rem; font-weight:900; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; margin-bottom:0.3rem;">Cohort Avg.</p>
          <div style="display:flex; align-items:center; gap:0.6rem;">
            <p id="sumAvg" style="font-size:1.4rem; font-weight:900; color:var(--primary);">0%</p>
            <div style="width:60px; height:6px; background:#f1f5f9; border-radius:10px; overflow:hidden;">
              <div id="sumAvgBar" style="width:0%; height:100%; background:var(--primary); border-radius:10px;"></div>
            </div>
          </div>
        </div>
      </div>
      
      <button class="btn" style="background:#f8fafc; border:1px solid #e2e8f0; color:var(--text-main); height:48px; padding:0 1.5rem; font-weight:700;" onclick="finalizeDay()">
        🏁 Close Business Day
      </button>
    </div>

    <!-- Attendance Logs Content -->
    <div class="glass-panel fade-up" style="border-radius:28px; padding:2rem;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:2rem; flex-wrap:wrap; gap:1.5rem;">
        <div>
          <h4 style="font-size:1.2rem;font-weight:800; color:var(--text-main);" id="logTableTitle">Shift Attendance Logs</h4>
          <p style="font-size:0.8rem; color:var(--text-light); margin-top:0.2rem;">Detailed telemetry and biometric verification</p>
        </div>
        <div style="display:flex;gap:0.75rem; align-items:center;">
          <select id="attBatchFilter" style="height:40px; padding:0 1rem; border-radius:12px; border:1.5px solid #e2e8f0; background:#f8fafc; font-weight:600; color:var(--text-main); outline:none;" onchange="renderGroupedLogsTable(window.currentAttendanceLogs)">
            <option value="">All Batches</option>
            <option value="Summer-Interns-2024">Summer Interns (2024)</option>
            <option value="Winter-Interns-2024">Winter Interns (2024)</option>
            <option value="Autumn-Interns-2024">Autumn Interns (2024)</option>
            <option value="Spring-Interns-2025">Spring Interns (2025)</option>
            <option value="Summer-Interns-2026">Summer Interns (2026)</option>
            <option value="Spring-Interns-2026">Spring Interns (2026)</option>
          </select>
          <div style="background:rgba(79, 70, 229, 0.05); padding:0.4rem; border-radius:14px; display:flex; gap:0.25rem;">
            <button id="viewModeUsers" class="btn btn-sm" style="height:36px; border-radius:10px; font-weight:700;" onclick="setAttViewMode('users')">
              👥 By User
            </button>
            <button id="viewModeLogs" class="btn btn-sm btn-secondary" style="height:36px; border-radius:10px; border:none; background:transparent; font-weight:700;" onclick="setAttViewMode('logs')">
              📜 Raw Logs
            </button>
          </div>
          <button class="btn btn-sm btn-secondary" style="height:40px; padding:0 1.2rem; border-radius:12px; font-weight:700;" onclick="exportAttendanceCSV()">
            📥 Export
          </button>
        </div>
      </div>
      <div id="logTable" style="margin-top:1rem;">
        <div class="spinner" style="margin:2rem auto"></div>
      </div>
    </div>`;

    window.currentAttViewMode = 'users';
    setTimeout(() => {
      setAttViewMode('users'); // Initialize buttons
      loadFilteredLogs();
    }, 100);
}


function setAttViewMode(mode) {
  window.currentAttViewMode = mode;
  const btnUsers = document.getElementById('viewModeUsers');
  const btnLogs = document.getElementById('viewModeLogs');
  
  if (mode === 'users') {
    btnUsers.style.background = 'var(--accent-gradient)';
    btnUsers.style.color = 'white';
    btnUsers.style.boxShadow = '0 4px 12px rgba(79, 70, 229, 0.2)';
    btnLogs.style.background = 'transparent';
    btnLogs.style.color = 'var(--text-sub)';
    btnLogs.style.boxShadow = 'none';
  } else {
    btnLogs.style.background = 'var(--accent-gradient)';
    btnLogs.style.color = 'white';
    btnLogs.style.boxShadow = '0 4px 12px rgba(79, 70, 229, 0.2)';
    btnUsers.style.background = 'transparent';
    btnUsers.style.color = 'var(--text-sub)';
    btnUsers.style.boxShadow = 'none';
  }
  
  if (window.currentAttendanceLogs) {
    const tableEl = document.getElementById('logTable');
    tableEl.innerHTML = (mode === 'users') 
      ? renderGroupedLogsTable(window.currentAttendanceLogs) 
      : renderLogsTable(window.currentAttendanceLogs);
  }
}

function handleAttFilterChange(val) {
  document.getElementById('customDateRange').style.display = (val === 'custom') ? 'flex' : 'none';
}

async function loadFilteredLogs() {
  const type = document.getElementById('attFilterType').value;
  const start = document.getElementById('attStartDate').value;
  const end = document.getElementById('attEndDate').value;
  
  if (type === 'custom' && (!start || !end)) {
    showToast('Please select both start and end dates.', 'warning');
    return;
  }

  const titleMap = { daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', yearly: 'Yearly', custom: 'Custom' };
  const modeSuffix = window.currentAttViewMode === 'users' ? 'User Summary' : 'Activity Logs';
  document.getElementById('logTableTitle').textContent = `${titleMap[type]} ${modeSuffix}`;
  document.getElementById('logTable').innerHTML = '<div class="spinner" style="margin:2rem auto"></div>';

  const logs = await api(`/api/attendance/logs/records?filter_type=${type}&start_date=${start}&end_date=${end}`);
  if (logs) {
    window.currentAttendanceLogs = logs;
    const tableEl = document.getElementById('logTable');
    tableEl.innerHTML = (window.currentAttViewMode === 'users') 
      ? renderGroupedLogsTable(logs) 
      : renderLogsTable(logs);
    updateAttendanceSummary(logs);
  }
}


function getWeekdaysInRange(startDate, endDate) {
  let count = 0;
  let cur = new Date(startDate);
  cur.setHours(0, 0, 0, 0);
  const end = new Date(endDate);
  end.setHours(23, 59, 59, 999);
  
  while (cur <= end) {
    const day = cur.getDay();
    if (day !== 0 && day !== 6) count++;
    cur.setDate(cur.getDate() + 1);
  }
  return count;
}

async function updateAttendanceSummary(logs) {
  const total = logs.length;
  const uniqueDatesSet = new Set();
  const presentWeights = {}; // Stores "studentId:dateStr" -> cumulative weight (max 1.0)
  
  logs.forEach(l => {
    let dateStr = "";
    if (l.timestamp_display) {
      const parts = l.timestamp_display.split(' ');
      if (parts.length >= 3) {
        const day = parts[0], monthStr = parts[1], year = parts[2];
        const months = {Jan:'01',Feb:'02',Mar:'03',Apr:'04',May:'05',Jun:'06',Jul:'07',Aug:'08',Sep:'09',Oct:'10',Nov:'11',Dec:'12'};
        dateStr = `${year}-${months[monthStr] || '01'}-${day.padStart(2,'0')}`;
      }
    }
    if (!dateStr) {
      const d = new Date(l.timestamp);
      const istDate = new Date(d.getTime() + (5.5 * 60 * 60 * 1000));
      dateStr = istDate.toISOString().split('T')[0];
    }
    
    uniqueDatesSet.add(dateStr);
    if (l.status === 'present') {
      const key = `${l.student_id}:${dateStr}`;
      if (!presentWeights[key]) presentWeights[key] = 0;
      
      if (l.method === 'manual_override') {
        presentWeights[key] = 1.0;
      } else if (l.log_type === 'check-in') {
        presentWeights[key] += 0.5;
      } else if (l.log_type === 'check-out') {
        presentWeights[key] += 0.5;
      }
      
      // Cap at 1.0 per day
      if (presentWeights[key] > 1.0) presentWeights[key] = 1.0;
    }
  });

  const uniqueDates = uniqueDatesSet.size;
  const present = Object.values(presentWeights).reduce((a, b) => a + b, 0);
  
  const filterType = document.getElementById('attFilterType').value;
  const startVal = document.getElementById('attStartDate').value;
  const endVal = document.getElementById('attEndDate').value;
  
  let expectedDays = uniqueDates; // Fallback
  
  // Calculate expected working days (Mon-Fri)
  const now = new Date();
  let rangeStart, rangeEnd;
  
  if (filterType === 'daily') {
    rangeStart = rangeEnd = now;
  } else if (filterType === 'weekly') {
    // Find Current Week's Monday
    const d = new Date(now);
    const day = d.getDay(); // 0=Sun, 1=Mon...
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    rangeStart = new Date(d.setDate(diff));
    rangeEnd = new Date(rangeStart);
    rangeEnd.setDate(rangeStart.getDate() + 4); // Friday
  } else if (filterType === 'monthly') {
    rangeStart = new Date(now.getFullYear(), now.getMonth(), 1);
    rangeEnd = now;
  } else if (filterType === 'yearly') {
    rangeStart = new Date(now.getFullYear(), 0, 1);
    rangeEnd = now;
  } else if (filterType === 'custom' && startVal && endVal) {
    rangeStart = new Date(startVal);
    rangeEnd = new Date(endVal);
  }
  
  if (rangeStart && rangeEnd) {
    expectedDays = getWeekdaysInRange(rangeStart, rangeEnd) || 1;
  }
  
  // Custom label for the stats card
  let expectedLabel = `${expectedDays} Expected Days`;
  if (filterType === 'weekly') expectedLabel = "5 Working Days Target";
  else if (filterType === 'daily') expectedLabel = "Today Only";
  else if (filterType === 'monthly') expectedLabel = "Weekdays So Far";
  else if (filterType === 'yearly') expectedLabel = "Yearly Weekdays";

  const interns = await api('/api/performance/overview');
  const internCount = interns ? interns.total_interns : 1;
  
  // Denominator is (Weekdays in period * Intern Count)
  const totalSlots = Math.max(expectedDays, 1) * internCount;
  const avgPct = Math.round((present / totalSlots) * 100);

  document.getElementById('sumTotal').textContent = internCount;
  document.getElementById('sumDates').textContent = uniqueDates;
  document.getElementById('sumPresent').textContent = present;
  document.getElementById('sumAvg').textContent = `${Math.min(avgPct, 100)}%`;
  
  // Update labels for better context
  const totalCard = document.getElementById('sumTotal').closest('.stat-mini-card') || document.getElementById('sumTotal').parentElement;
  const totalLabel = totalCard.querySelector('.stat-mini-label');
  if (totalLabel) totalLabel.textContent = "Total Cohort";

  const datesCard = document.getElementById('sumDates').closest('.stat-mini-card') || document.getElementById('sumDates').parentElement;
  const datesLabel = datesCard.querySelector('.stat-mini-label');
  if (datesLabel) {
    datesLabel.innerHTML = `<span style="color:var(--primary)">${uniqueDates}</span> / <span style="font-weight:900;">${expectedDays}</span> <span style="font-size:0.6rem;opacity:0.8;">(${expectedLabel})</span>`;
  }

  const bar = document.getElementById('sumAvgBar');
  if (bar) bar.style.width = `${Math.min(avgPct, 100)}%`;
}

async function loadPendingAttendanceStudents() {
  const list = document.getElementById('pendingAttendanceList');
  const hint = document.getElementById('pendingAttendanceHint');
  const applyButton = document.getElementById('overrideApplyBtn');
  if (!list) return;

  list.innerHTML = '<p style="color:var(--text-muted);font-size:0.78rem;">Loading pending students...</p>';

  const students = await api('/api/attendance/pending-students');
  if (students === null) {
    list.innerHTML = '<div class="empty-state" style="padding:1.25rem 0;"><div class="empty-icon">⚠️</div><p>Unable to load pending students right now.</p></div>';
    if (hint) hint.textContent = 'Try again after the connection is restored.';
    if (applyButton) applyButton.disabled = true;
    return;
  }

  window.pendingAttendanceStudents = students || [];

  if (!students || students.length === 0) {
    list.innerHTML = `
      <div class="empty-state" style="padding:1.25rem 0;">
        <div class="empty-icon">✅</div>
        <h3 style="font-size:0.95rem;">Attendance Complete</h3>
        <p>Every student has already been marked for today.</p>
      </div>`;
    if (hint) hint.textContent = 'No pending students remain for today.';
    document.getElementById('ovStudentId').value = '';
    document.getElementById('ovStudentName').value = '';
    document.getElementById('ovSelectedStudent').value = '';
    document.getElementById('ovSelectedStudent').placeholder = 'No students pending';
    if (applyButton) applyButton.disabled = true;
    return;
  }

  if (hint) hint.textContent = `${students.length} student${students.length === 1 ? '' : 's'} still need attendance.`;
  if (applyButton) applyButton.disabled = false;

  list.innerHTML = students.map(student => `
    <button type="button" class="pending-student-card" data-student-id="${student.user_id}" onclick="selectPendingAttendanceStudent('${student.user_id}','${(student.display_name || student.full_name || student.email || '').replace(/'/g, "\\'")}', '${(student.email || '').replace(/'/g, "\\'")}')" style="display:block; width:100%; text-align:left; border:1px solid #e2e8f0; background:white; border-radius:12px; padding:0.85rem 1rem; margin-bottom:0.6rem; cursor:pointer; transition:all 0.2s ease;">
      <div style="display:flex; justify-content:space-between; gap:0.75rem; align-items:flex-start;">
        <div>
          <p style="font-weight:800; color:var(--text-main); margin-bottom:0.15rem;">${student.display_name || student.full_name || student.email}</p>
          <p style="font-size:0.72rem; color:var(--text-muted);">${student.user_id || ''}${student.email ? ' · ' + student.email : ''}</p>
        </div>
        <span class="badge badge-submitted">Pending</span>
      </div>
    </button>
  `).join('');

  selectPendingAttendanceStudent(
    students[0].user_id,
    students[0].display_name || students[0].full_name || students[0].email,
    students[0].email || ''
  );
}

function selectPendingAttendanceStudent(studentId, studentName, studentEmail) {
  const selectedStudent = document.getElementById('ovSelectedStudent');
  const selectedId = document.getElementById('ovStudentId');
  const selectedName = document.getElementById('ovStudentName');

  if (!selectedStudent || !selectedId || !selectedName) return;

  selectedId.value = studentId || studentEmail || '';
  selectedName.value = studentName || studentEmail || studentId || '';
  selectedStudent.value = studentName || studentEmail || studentId || '';

  document.querySelectorAll('.pending-student-card').forEach(card => {
    card.style.borderColor = '#e2e8f0';
    card.style.background = 'white';
  });

  const clickedCard = document.querySelector(`.pending-student-card[data-student-id="${studentId}"]`);
  if (clickedCard) {
    clickedCard.style.borderColor = 'var(--primary)';
    clickedCard.style.background = 'rgba(79, 70, 229, 0.06)';
  }
}

async function openAttendanceOverrideModal() {
  document.getElementById('ovStudentId').value = '';
  document.getElementById('ovStudentName').value = '';
  document.getElementById('ovSelectedStudent').value = '';
  document.getElementById('ovSelectedStudent').placeholder = 'Choose a pending student';
  document.getElementById('ovStatus').value = 'present';
  document.getElementById('ovReason').value = '';
  openModal('overrideModal');
  await loadPendingAttendanceStudents();
}

function toggleIpSection(checked) {
  document.getElementById('ipConfigSection').style.display = checked ? '' : 'none';
}

function toggleGeoSection(checked) {
  document.getElementById('geoConfigSection').style.display = checked ? '' : 'none';
}

async function captureCurrentNetwork(btn) {
  // BUG-09 FIX: receive btn element directly instead of using implicit global event
  btn.disabled = true; btn.textContent = 'Detecting...';
  try {
    const info = await api('/api/attendance/network-info');
    if (info && info.suggested_prefix) {
      document.getElementById('ipPrefixValue').value = info.suggested_prefix;
      document.getElementById('displayIpPrefix').innerHTML = `<span style="color:#4f46e5">${info.suggested_prefix}.* ✔</span>`;
      const sourceHint = info.source === 'host' ? ' (LAN auto-detected)' : '';
      showToast(`Network captured: ${info.suggested_prefix}.x${sourceHint}`, 'success');
      if (info.warning) {
        showToast(info.warning, 'info');
      }
    } else {
      showToast('Could not detect network prefix. Open dashboard via LAN IP and retry.', 'error');
    }
  } catch(e) {
    showToast('Could not detect network. Check connectivity.', 'error');
  }
  btn.disabled = false; btn.textContent = '📡 Capture My Network';
}

function captureCurrentLocation(btn) {
  // BUG-09 FIX: receive btn element directly instead of using implicit global event
  btn.disabled = true; btn.textContent = '📡 Acquiring GPS...';
  if (!navigator.geolocation) {
    showToast('Geolocation not supported by this browser.', 'error');
    btn.disabled = false; btn.textContent = '🛰️ Set Office Location';
    return;
  }
  navigator.geolocation.getCurrentPosition(
    pos => {
      const lat = pos.coords.latitude.toFixed(6);
      const lng = pos.coords.longitude.toFixed(6);
      document.getElementById('geoLatValue').value = lat;
      document.getElementById('geoLngValue').value = lng;
      document.getElementById('displayGeoCoords').innerHTML = `<span style="color:#4f46e5">${lat}°N, ${lng}°E ✔</span>`;
      showToast(`Office coords set: ${lat}, ${lng}`, 'success');
      btn.disabled = false; btn.textContent = '🛰️ Set Office Location';
    },
    err => {
      showToast('Location access denied. Enable browser permissions.', 'error');
      btn.disabled = false; btn.textContent = '🛰️ Set Office Location';
    },
    { timeout: 8000, enableHighAccuracy: true }
  );
}

function exportAttendanceCSV() {
  const logs = window.currentAttendanceLogs;
  if (!logs || logs.length === 0) {
    showToast('No logs to export.', 'warning');
    return;
  }
  
  const filterType = document.getElementById('attFilterType')?.value || 'today';
  
  const batchFilter = document.getElementById('attBatchFilter')?.value || '';
  const filteredLogs = logs.filter(l => !batchFilter || l.batch === batchFilter);

  if (filteredLogs.length === 0) {
    showToast('No filtered logs to export.', 'warning');
    return;
  }

  const headers = ['Intern Name', 'Intern ID', 'Batch', 'Time (IST)', 'Method', 'Network IP', 'Geo Location (m)', 'Status'];
  const rows = filteredLogs.map(l => [
    `"${(l.student_name || '').replace(/"/g, '""')}"`,
    `"${l.student_id || ''}"`,
    `"${l.batch || 'N/A'}"`,
    `"${l.timestamp_display || new Date(l.timestamp).toLocaleString('en-IN')}"`,
    `"${l.method === 'manual_override' ? 'Override' : 'Biometric'}"`,
    `"${l.ipv4 || '-'}"`,
    `"${l.geo_distance_m !== undefined && l.geo_distance_m !== null ? l.geo_distance_m : '-'}"`,
    `"${(l.status || 'present').toUpperCase()}"`
  ]);
  
  const csvContent = [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `attendance_${filterType}_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function renderGroupedLogsTable(logs) {
  if (logs.length === 0) return `<div class="empty-state" style="padding:4rem 0;"><div class="empty-icon" style="font-size:4rem; margin-bottom:1rem; opacity:0.5;">📡</div><p style="font-weight:600; color:var(--text-muted);">No records found for this period.</p></div>`;
  
  const batchFilter = document.getElementById('attBatchFilter')?.value || '';
  const groups = {};
  const uniqueDates = new Set();
  
  logs.forEach(l => {
    if (batchFilter && l.batch !== batchFilter) return;
    
    const sid = l.student_id;
    // CRITICAL: Use the display date or manually adjust to IST to avoid UTC shifts
    let dateStr = "";
    if (l.timestamp_display) {
      // Format: "05 May 2026 ..." -> "2026-05-05"
      const parts = l.timestamp_display.split(' ');
      if (parts.length >= 3) {
        const day = parts[0];
        const monthMap = { 'Jan':'01','Feb':'02','Mar':'03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12' };
        const month = monthMap[parts[1]] || '01';
        const year = parts[2];
        dateStr = `${year}-${month}-${day.padStart(2, '0')}`;
      }
    }
    
    if (!dateStr) {
      const d = new Date(l.timestamp);
      // Fallback for local offset
      const istDate = new Date(d.getTime() + (5.5 * 60 * 60 * 1000));
      dateStr = istDate.toISOString().split('T')[0];
    }
    
    uniqueDates.add(dateStr);
    
    if (!groups[sid]) {
      groups[sid] = {
        name: l.student_name || sid,
        id: sid,
        batch: l.batch || 'N/A',
        dayWeights: {}, // Mapping of dateStr -> 0.5 or 1.0
        logs: []
      };
    }
    if (l.status === 'present') {
      if (!groups[sid].dayWeights[dateStr]) groups[sid].dayWeights[dateStr] = 0;
      
      if (l.method === 'manual_override') {
        groups[sid].dayWeights[dateStr] = 1.0;
      } else if (l.log_type === 'check-in') {
        groups[sid].dayWeights[dateStr] += 0.5;
      } else if (l.log_type === 'check-out') {
        groups[sid].dayWeights[dateStr] += 0.5;
      }
      
      if (groups[sid].dayWeights[dateStr] > 1.0) groups[sid].dayWeights[dateStr] = 1.0;
    }
    groups[sid].logs.push(l);
  });
  
  // Convert weights to total numeric sum
  Object.values(groups).forEach(g => {
    g.totalWeight = Object.values(g.dayWeights).reduce((a, b) => a + b, 0);
  });
  
  const filterType = document.getElementById('attFilterType').value;
  const startVal = document.getElementById('attStartDate').value;
  const endVal = document.getElementById('attEndDate').value;
  
  let totalPeriodDays = 1;
  const now = new Date();
  let rangeStart, rangeEnd;
  
  if (filterType === 'daily') {
    rangeStart = rangeEnd = now;
  } else if (filterType === 'weekly') {
    const d = new Date(now);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    rangeStart = new Date(d.setDate(diff));
    rangeEnd = new Date(rangeStart);
    rangeEnd.setDate(rangeStart.getDate() + 4);
  } else if (filterType === 'monthly') {
    rangeStart = new Date(now.getFullYear(), now.getMonth(), 1);
    rangeEnd = now;
  } else if (filterType === 'yearly') {
    rangeStart = new Date(now.getFullYear(), 0, 1);
    rangeEnd = now;
  } else if (filterType === 'custom' && startVal && endVal) {
    rangeStart = new Date(startVal);
    rangeEnd = new Date(endVal);
  }

  if (rangeStart && rangeEnd) {
    totalPeriodDays = getWeekdaysInRange(rangeStart, rangeEnd) || 1;
  } else {
    totalPeriodDays = uniqueDates.size || 1;
  }
  
  const sortedUsers = Object.values(groups).sort((a, b) => b.totalWeight - a.totalWeight);

  return `<div class="table-wrapper" style="border:none; box-shadow:none; background:transparent;">
    <table style="border-spacing: 0 0.75rem; border-collapse: separate;">
    <thead>
      <tr style="background:transparent; border:none;">
        <th style="padding:0.75rem 1rem;">Intern Details</th>
        <th style="padding:0.75rem 1rem;">Present Days</th>
        <th style="padding:0.75rem 1rem;">Attendance Rate</th>
        <th style="padding:0.75rem 1rem;">Latest Activity</th>
        <th style="padding:0.75rem 1rem; text-align:right;">Performance</th>
      </tr>
    </thead>
    <tbody>${sortedUsers.map(u => {
    const pCount = u.totalWeight;
      const rawPct = Math.round((pCount / totalPeriodDays) * 100);
      const pct = Math.min(rawPct, 100);
      const latest = u.logs.sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
      const label = pct >= 90 ? 'EXCELLENT' : pct >= 75 ? 'GOOD' : pct >= 50 ? 'AVERAGE' : 'LOW';
      const labelColor = pct >= 90 ? '#10b981' : pct >= 75 ? '#8b5cf6' : pct >= 50 ? '#f59e0b' : '#ef4444';

      return `
      <tr class="hover-row" style="background:#fff; box-shadow:0 2px 10px rgba(15,23,42,0.03); transition:all 0.2s ease;">
        <td style="padding:1.2rem 1rem; border-radius:16px 0 0 16px;">
          <div style="display:flex; align-items:center; gap:0.8rem;">
            <div style="width:42px; height:42px; border-radius:12px; background:linear-gradient(135deg, rgba(79,70,229,0.1), rgba(217,70,239,0.05)); display:flex; align-items:center; justify-content:center; color:var(--primary); font-weight:800; font-size:1rem;">
              ${u.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <p style="font-weight:800; color:var(--text-main); font-size:0.95rem; margin-bottom:0.1rem;">${u.name}</p>
              <p style="font-size:0.72rem;color:var(--text-muted); font-weight:600; letter-spacing:0.4px;">${u.id} • <span style="color:var(--primary)">${u.batch}</span></p>
            </div>
          </div>
        </td>
        <td style="padding:1.2rem 1rem; font-weight:700; color:var(--text-main); font-size:1rem;">
          ${pCount} <span style="font-size:0.75rem; color:var(--text-muted); font-weight:500;">/ ${totalPeriodDays} Days</span>
        </td>
        <td style="padding:1.2rem 1rem;">
          <div style="display:flex; align-items:center; gap:0.8rem;">
            <div style="flex:1; width:80px; height:8px; background:#f1f5f9; border-radius:10px; overflow:hidden;">
              <div style="width:${pct}%; height:100%; background:${labelColor}; border-radius:10px;"></div>
            </div>
            <span style="font-weight:800; font-size:0.9rem; color:${labelColor}; min-width:40px;">${pct}%</span>
          </div>
        </td>
        <td style="padding:1.2rem 1rem; font-size:0.8rem; color:var(--text-light); font-weight:500;">
          <div style="display:flex; align-items:center; gap:0.6rem;">
            <div style="display:flex; flex-direction:column;">
              <span>${latest.timestamp_display ? latest.timestamp_display.split(' ').slice(0,3).join(' ') : '---'}</span>
              <span style="font-size:0.7rem; color:var(--text-muted); margin-top:0.1rem;">${latest.timestamp_display ? latest.timestamp_display.split(' ').slice(3).join(' ') : ''}</span>
            </div>
            ${(() => {
              const isOut = latest.log_type === 'check-out';
              const isOverride = latest.method === 'manual_override';
              const color = isOverride ? '#10b981' : (isOut ? '#d946ef' : '#4f46e5');
              const label = isOverride ? 'ADMIN' : (isOut ? 'OUT' : 'IN');
              return `<span style="background:${color}12; color:${color}; font-size:0.6rem; font-weight:900; padding:0.2rem 0.45rem; border-radius:6px; border:1px solid ${color}25; letter-spacing:0.5px;">${label}</span>`;
            })()}
          </div>
        </td>
        <td style="padding:1.2rem 1rem; border-radius:0 16px 16px 0; text-align:right;">
          <span style="background:${labelColor}15; color:${labelColor}; padding:0.4rem 0.8rem; border-radius:10px; font-weight:900; font-size:0.7rem; letter-spacing:0.5px;">${label}</span>
        </td>
      </tr>`;
    }).join('')}</tbody>
  </table></div>`;
}

function renderLogsTable(logs) {
  if (logs.length === 0) return `<div class="empty-state" style="padding:4rem 0;"><div class="empty-icon" style="font-size:4rem; margin-bottom:1rem; opacity:0.5;">📡</div><p style="font-weight:600; color:var(--text-muted);">No telemetry recorded for this timeframe.</p></div>`;
  return `<div class="table-wrapper" style="border:none; box-shadow:none; background:transparent;">
    <table style="border-spacing: 0 0.75rem; border-collapse: separate;">
    <thead>
      <tr style="background:transparent; border:none;">
        <th style="padding:0.75rem 1rem;">Intern</th>
        <th style="padding:0.75rem 1rem;">Time (IST)</th>
        <th style="padding:0.75rem 1rem;">Method</th>
        <th style="padding:0.75rem 1rem;">Network</th>
        <th style="padding:0.75rem 1rem;">Location</th>
        <th style="padding:0.75rem 1rem; text-align:right;">Status</th>
      </tr>
    </thead>
    <tbody>${logs.map(l => {
      const isOut = l.log_type === 'check-out';
      const isOverride = l.method === 'manual_override';
      const phaseColor = isOverride ? '#10b981' : (isOut ? '#d946ef' : '#4f46e5');
      const phaseLabel = isOverride ? 'OVERRIDE' : (isOut ? 'CHECK-OUT' : 'CHECK-IN');
      const statusColor = l.status === 'present' ? '#10b981' : '#ef4444';

      return `
      <tr class="hover-row" style="background:#fff; box-shadow:0 2px 10px rgba(15,23,42,0.03); transition:all 0.2s ease;">
      <td style="padding:1.2rem 1rem; border-radius:16px 0 0 16px;">
        <div style="display:flex; align-items:center; gap:0.8rem;">
          <div style="width:36px; height:36px; border-radius:10px; background:rgba(79, 70, 229, 0.08); display:flex; align-items:center; justify-content:center; color:var(--primary); font-weight:800; font-size:0.8rem;">
            ${(l.student_name || 'I').charAt(0).toUpperCase()}
          </div>
          <div>
            <p style="font-weight:800; color:var(--text-main); font-size:0.9rem; margin-bottom:0.1rem;">${l.student_name || l.student_id}</p>
            <p style="font-size:0.72rem;color:var(--text-muted); font-weight:600; letter-spacing:0.4px;">${l.student_id}</p>
          </div>
        </div>
      </td>
      <td style="padding:1.2rem 1rem; font-size:0.85rem; font-weight:600; color:var(--text-sub);">${l.timestamp_display || new Date(l.timestamp).toLocaleString('en-IN')}</td>
      <td style="padding:1.2rem 1rem;"><span class="badge" style="background:rgba(99, 102, 241, 0.1); color:var(--primary); padding:0.4rem 0.8rem; border-radius:8px;">${l.method === 'manual_override' ? 'OVERRIDE' : 'BIOMETRIC'}</span></td>
      <td style="padding:1.2rem 1rem;">
        ${l.method === 'manual_override' ? '<span style="color:var(--text-muted);font-size:0.8rem; font-style:italic;">Bypassed</span>' :
          l.ip_verified === false
            ? '<span style="color:#ef4444;font-weight:700;font-size:0.8rem;">❌ MISMATCH</span>'
            : l.ipv4
              ? `<span style="color:#10b981;font-weight:700;font-size:0.85rem; display:flex; align-items:center; gap:0.3rem;" title="${l.ipv4}">
                   <span style="font-size:0.9rem;">✓</span> ${l.ipv4}
                 </span>`
              : '<span style="color:var(--text-muted);font-size:0.8rem;">—</span>'
        }
      </td>
      <td style="padding:1.2rem 1rem;">
        ${l.method === 'manual_override' ? '<span style="color:var(--text-muted);font-size:0.8rem; font-style:italic;">Bypassed</span>' :
          l.geo_verified === false
            ? '<span style="color:#ef4444;font-weight:700;font-size:0.8rem;">❌ MISMATCH</span>'
            : l.geo_distance_m != null
              ? `<span style="color:#10b981;font-weight:700;font-size:0.85rem; display:flex; align-items:center; gap:0.3rem;">
                   <span style="font-size:0.9rem;">✓</span> ${l.geo_distance_m}m away
                 </span>`
              : '<span style="color:var(--text-muted);font-size:0.8rem;">—</span>'
        }
      </td>
    </tr>`;
    }).join('')}</tbody>
  </table></div>`;
}

async function handleAttToggle(status) {
  await saveAttendanceConfig(status);
}

async function saveAttendanceConfig(overrideActive) {
  const is_active   = overrideActive !== undefined ? overrideActive : document.getElementById('masterToggle').checked;
  const require_ip  = document.getElementById('ipToggle')?.checked || false;
  const require_geo = document.getElementById('geoToggle')?.checked || false;
  const geo_lat     = parseFloat(document.getElementById('geoLatValue')?.value) || null;
  const geo_lng     = parseFloat(document.getElementById('geoLngValue')?.value) || null;
  const geo_radius  = parseInt(document.getElementById('geoRadius')?.value)     || 200;
  const ip_prefix   = (document.getElementById('ipPrefixValue')?.value || '').trim().replace(/(\.\*|\.x)$/i, '');

  if (require_ip && !ip_prefix) {
    showToast('Capture your WiFi network before enabling Network Lock.', 'error');
    return;
  }

  const res = await api('/api/attendance/configure', 'POST', {
    is_active, require_ip, require_geo,
    geo_lat, geo_lng,
    geo_radius_meters: geo_radius,
    allowed_ip_prefix: ip_prefix
  });
  if (res) {
    const networkTag = res.captured_ip_prefix ? ` | Network: ${res.captured_ip_prefix}.x` : '';
    const sourceTag = res.network_source === 'host' ? ' (LAN auto)' : '';
    const msg = is_active
      ? `Scanner ARMED 🛰️${networkTag}${sourceTag}`
      : 'Scanner DISARMED';
    showToast(msg, is_active ? 'success' : 'info');
    switchSection('attendance');
  }
}

async function submitOverride() {
  const studentId = document.getElementById('ovStudentId').value.trim();
  const studentName = document.getElementById('ovStudentName').value.trim();
  if (!studentId) {
    showToast('Select a pending student first.', 'error');
    return;
  }

  const res = await api('/api/attendance/override', 'POST', {
    student_id: studentId,
    student_name: studentName,
    status:       document.getElementById('ovStatus').value,
    reason:       document.getElementById('ovReason').value || 'Faculty Override'
  });
  if (res) {
    showToast('Override applied ✅', 'success');
    closeModal('overrideModal');
    switchSection('attendance');
  }
}

async function finalizeDay(btn) {
  const confirmed = confirm("Are you sure you want to finalize today's attendance? This will mark all pending interns as ABSENT or PARTIAL ABSENT and should only be done after the shift ends (10:00 PM).");
  if (!confirmed) return;
  
  let originalText = '';
  if (btn) {
    originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⌛ Finalizing...';
  }
  
  const res = await api('/api/attendance/finalize-day', 'POST');
  if (res) {
    showToast(res.message || 'Business day closed successfully!', 'success');
    // Refresh the attendance view
    const main = document.getElementById('main-content') || document.getElementById('mainContent');
    if (main) renderAttendance(main);
  }
  
  if (btn) {
    btn.disabled = false;
    btn.textContent = originalText;
  }
}


// ─── SECTION 8: LEAVES (NEW) ──────────────────────────────────
async function renderLeaves(main) {
  const leaves = await api('/api/leaves/all');
  if (!leaves) return;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Leave Operations</h2>
        <p class="section-sub">${leaves.length} total requests processed</p>
      </div>
    </div>

    ${leaves.length === 0 ? '<div class="empty-state"><div class="empty-icon">📧</div><h3>Inbox Clear</h3><p>No active leave requests from interns.</p></div>' :
    `<div class="table-wrapper fade-up">
      <table>
        <thead><tr><th>Intern</th><th>Subject/Dates</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          ${leaves.map(l => {
            const sc = l.status === 'APPROVED' ? '#22c55e' : l.status === 'REJECTED' ? '#ef4444' : '#eab308';
            return `
            <tr class="hover-row">
              <td>
                <p style="font-weight:700">${l.student_name}</p>
                <p style="font-size:0.7rem; color:var(--text-muted)">${l.student_id}</p>
              </td>
              <td style="max-width:300px;">
                <p style="font-size:0.85rem; font-weight:700; color:var(--primary);">${l.subject}</p>
                <p style="font-size:0.75rem; color:var(--text-light); margin-top:0.2rem;">${l.start_date} → ${l.end_date}</p>
                <p style="font-size:0.78rem; color:var(--text-muted); margin-top:0.4rem; font-style:italic;">"${l.body.substring(0,80)}${l.body.length>80?'...':''}"</p>
              </td>
              <td>
                <span class="badge" style="background:${sc}15; color:${sc}; border:1px solid ${sc}40;">${l.status}</span>
              </td>
              <td>
                <button class="btn btn-sm" onclick="openRespondModal('${l._id}')">⚖️ Decide</button>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`}
  `;
}

function openRespondModal(id) {
  document.getElementById('rlId').value = id;
  document.getElementById('rlComment').value = '';
  openModal('respondLeaveModal');
}

// ─── SECTION 9: PROFILE ───────────────────────────────────────
async function renderProfile(main) {
  const me = await api('/api/auth/me');
  if (!me) return;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Faculty Profile</h2>
        <p class="section-sub">Your identity synchronized from the Atlas cluster</p>
      </div>
      <button class="btn" onclick="openProfileModal('${me.full_name||''}','${me.phone||''}','${me.department||''}')">✏️ Edit Profile</button>
    </div>
    <div class="glass-panel fade-up" style="max-width:600px;">
      <div style="display:flex;align-items:center;gap:2rem;margin-bottom:2.5rem;">
        <div style="width:90px;height:90px;background:var(--accent-gradient);border-radius:24px;display:flex;align-items:center;justify-content:center;font-size:2.5rem;color:white;font-weight:900;flex-shrink:0;">
          ${(me.full_name||me.email||'F').charAt(0).toUpperCase()}
        </div>
        <div>
          <h2 style="font-size:1.6rem;font-weight:900;margin-bottom:0.2rem;">${me.full_name||'—'}</h2>
          <p style="color:var(--primary);font-weight:700;font-size:0.9rem;">INSTRUCTOR · SPX Faculty Terminal</p>
          ${me.department?`<p style="color:var(--text-muted);font-size:0.8rem;margin-top:0.2rem;">${me.department}</p>`:''}
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem;">
        ${[
          ['User ID', me.user_id||'—'],
          ['Email', me.email||'—'],
          ['Phone', me.phone||'Not set'],
          ['Role', me.role||'INSTRUCTOR'],
          ['Department', me.department||'Not set'],
          ['Last Login', me.profile_updated_at ? new Date(me.profile_updated_at).toLocaleString('en-IN') : 'N/A']
        ].map(([label, val])=>`
          <div style="background:#f8fafc;border-radius:12px;padding:1rem;">
            <p style="font-size:0.65rem;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-muted);margin-bottom:0.3rem;">${label}</p>
            <p style="font-weight:700;color:var(--text-sub);font-size:0.9rem;">${val}</p>
          </div>`).join('')}
      </div>
    </div>
    
    <div class="glass-panel fade-up" style="max-width:600px; margin-top:1.5rem; border-color: #fee2e2;">
      <h3 style="font-size:1rem; font-weight:800; color:#ef4444; margin-bottom:1rem;">Security Options</h3>
      <p style="font-size:0.82rem; color:var(--text-light); margin-bottom:1.5rem;">Update your authentication credentials for institutional access.</p>
      
      <div style="display:grid; grid-template-columns:1fr auto; gap:1rem; align-items:flex-end;">
        <div style="background:#f8fafc; border-radius:12px; padding:0.5rem 1rem; border:1px solid #e2e8f0;">
          <label style="display:block; font-size:0.65rem; font-weight:800; text-transform:uppercase; color:var(--text-muted); margin-bottom:0.2rem;">New Password</label>
          <div class="password-wrapper">
            <input type="password" id="instructor-new-pwd" placeholder="Enter new password..." style="width:100%; border:none; background:transparent; outline:none; font-weight:600; font-size:0.9rem;">
            <span class="password-toggle" onclick="togglePassword('instructor-new-pwd', this)">👁️</span>
          </div>
        </div>
        <button class="btn btn-danger" style="height:48px;" onclick="resetInstructorPassword()">Update</button>
      </div>
    </div>`;
}

async function resetInstructorPassword() {
  const pwd = document.getElementById('instructor-new-pwd').value;
  if (!pwd || pwd.length < 6) {
    showToast('Security Rule: Password must be at least 6 characters.', 'warning');
    return;
  }
  if (!confirm('Update institutional security credentials?')) return;

  const res = await api('/api/auth/change-password', 'POST', { new_password: pwd });
  if (res) {
    showToast('Security credentials updated successfully.', 'success');
    document.getElementById('instructor-new-pwd').value = '';
  }
}

function openProfileModal(name, phone, dept) {
  document.getElementById('profileName').value = name;
  document.getElementById('profilePhone').value = phone;
  document.getElementById('profileDept').value = dept;
  openModal('profileModal');
}

async function submitProfileUpdate() {
  const res = await api('/api/auth/me', 'PUT', {
    full_name:  document.getElementById('profileName').value || undefined,
    phone:      document.getElementById('profilePhone').value || undefined,
    department: document.getElementById('profileDept').value || undefined
  });
  if (res) {
    showToast('Profile synchronized ✅', 'success');
    closeModal('profileModal');
    // Update sidebar name
    const name = document.getElementById('profileName').value;
    document.getElementById('facultyName').textContent = name;
    document.getElementById('facultyAvatar').textContent = name.charAt(0).toUpperCase();
  }
}

// ─── ALL FORM EVENT HANDLERS ──────────────────────────────────
function setupForms() {
  const preventEnterSubmit = formId => {
    document.getElementById(formId)?.addEventListener('keydown', e => {
      if (e.key !== 'Enter') return;
      if (e.target && e.target.tagName === 'TEXTAREA') return;
      e.preventDefault();
    });
  };

  ['userForm', 'taskForm', 'gradeForm', 'rejectForm', 'projectForm', 'examForm', 'mockForm', 'interviewForm', 'respondLeaveForm'].forEach(preventEnterSubmit);

  document.getElementById('userForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const errPanel = document.getElementById('modal-error');

    const res = await api('/api/auth/create', 'POST', {
      full_name: document.getElementById('fn').value,
      email: document.getElementById('em').value,
      password: document.getElementById('pw').value,
      phone: document.getElementById('ph').value,
      department: document.getElementById('dept').value,
      designation: document.getElementById('desig').value,
      internship_role: document.getElementById('intern-role').value,
      internship_duration: document.getElementById('intern-duration').value,
      batch: document.getElementById('batch').value,
      otp: document.getElementById('otp-code').value,
    });

    if (res) {
      showToast(res.message || 'Intern account provisioned.', 'success');
      e.target.reset();
      closeModal('userModal');
      await loadInternCheckboxes();
      switchSection('interns');
      return;
    }

    if (errPanel) {
      errPanel.innerText = 'Provisioning failed. Check the notification banner for details.';
      errPanel.style.display = 'block';
    }
  });

  // Create/Update Task
  document.getElementById('taskForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const taskId = document.getElementById('taskId').value;
    const mode = document.getElementById('taskAssignMode').value;
    let assigned = [];
    if (mode === 'specific') {
      document.querySelectorAll('.intern-cb:checked').forEach(cb => assigned.push(cb.value));
    }
    
    const payload = {
      title:       document.getElementById('taskTitle').value,
      description: document.getElementById('taskDesc').value,
      deadline:    document.getElementById('taskDeadline').value || null,
      assigned_to: assigned
    };

    let res;
    if (taskId) {
      res = await api(`/api/tasks/update/${taskId}`, 'PUT', payload);
    } else {
      res = await api('/api/tasks/create', 'POST', payload);
    }

    if (res) {
      showToast(taskId ? 'Task updated successfully!' : 'Task deployed! Interns can see it now.', 'success');
      e.target.reset();
      document.getElementById('internSelectGroup').style.display = 'none';
      closeModal('taskModal');
      switchSection('tasks');
    }
  });

  // Grade Task
  document.getElementById('gradeForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const res = await api('/api/tasks/grade', 'POST', {
      task_id:      document.getElementById('gradeTaskId').value,
      intern_email: document.getElementById('gradeEmail').value,
      marks:        parseInt(document.getElementById('gradeMarks').value),
      feedback:     document.getElementById('gradeFeedback').value,
      action:       'approve'
    });
    if (res) {
      showToast('Grade submitted! Intern sees it immediately.', 'success');
      closeModal('gradeModal');
      switchSection('tasks');
    }
  });

  // Reject Task
  document.getElementById('rejectForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const res = await api('/api/tasks/grade', 'POST', {
      task_id:      document.getElementById('rejectTaskId').value,
      intern_email: document.getElementById('rejectEmail').value,
      feedback:     document.getElementById('rejectFeedback').value,
      action:       'reject'
    });
    if (res) {
      showToast('Task rejected. Intern will be notified.', 'info');
      closeModal('rejectModal');
      switchSection('tasks');
    }
  });

  // Create Project
  document.getElementById('projectForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const teamRaw = document.getElementById('projTeam').value;
    const team = teamRaw ? teamRaw.split(',').map(s=>s.trim()).filter(Boolean) : [];
    const res = await api('/api/projects/create', 'POST', {
      title:        document.getElementById('projTitle').value,
      description:  document.getElementById('projDesc').value,
      deadline:     document.getElementById('projDeadline').value,
      tech_stack:   document.getElementById('projTech').value,
      team_members: team
    });
    if (res) { showToast('Project deployed!', 'success'); closeModal('projectModal'); e.target.reset(); switchSection('projects'); }
  });

  // Create Exam
  document.getElementById('examForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const res = await api('/api/exams/create', 'POST', {
      title:            document.getElementById('examTitle').value,
      description:      document.getElementById('examDesc').value,
      type:             document.getElementById('examType').value,
      duration_minutes: parseInt(document.getElementById('examDuration').value),
      total_marks:      parseInt(document.getElementById('examMarks').value),
      anti_cheating: {
        disable_tab_switch: document.getElementById('acTabSwitch').checked,
        disable_copy_paste: document.getElementById('acCopyPaste').checked,
        disable_right_click: document.getElementById('acRightClick').checked,
        full_screen_required: document.getElementById('acFullscreen').checked
      }
    });
    if (res) { showToast('Exam initialized! Toggle to make it live.', 'success'); closeModal('examModal'); e.target.reset(); switchSection('exams'); }
  });

  // Create Mock
  document.getElementById('mockForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const res = await api('/api/mocks/create', 'POST', {
      title:       document.getElementById('mockTitle').value,
      description: document.getElementById('mockDesc').value,
      category:    document.getElementById('mockCategory').value,
      duration:    parseInt(document.getElementById('mockDuration').value)
    });
    if (res) { showToast('Mock deployed!', 'success'); closeModal('mockModal'); e.target.reset(); switchSection('mocks'); }
  });

  // Schedule Interview
  document.getElementById('interviewForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const res = await api('/api/interviews/schedule', 'POST', {
      intern_email:     document.getElementById('intEmail').value,
      intern_name:      document.getElementById('intName').value,
      category:         document.getElementById('intCategory').value,
      duration_minutes: parseInt(document.getElementById('intDuration').value),
      scheduled_at:     document.getElementById('intSchedule').value,
      notes:            document.getElementById('intNotes').value
    });
    if (res) { showToast('Interview scheduled!', 'success'); closeModal('interviewModal'); e.target.reset(); switchSection('interviews'); }
  });

  // Respond to Leave
  document.getElementById('respondLeaveForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const id = document.getElementById('rlId').value;
    const res = await api(`/api/leaves/${id}/respond`, 'PATCH', {
      status:              document.getElementById('rlStatus').value,
      instructor_response: document.getElementById('rlComment').value
    });
    if (res) {
      showToast('Leave update dispatched 📧', 'success');
      closeModal('respondLeaveModal');
      switchSection('leaves');
    }
  });
}

// ─── Submit Performance Label Update ─────────────────────────
async function submitLabelUpdate() {
  const userId   = document.getElementById('labelUserId').value;
  const label    = document.getElementById('labelValue').value;
  const progress = parseInt(document.getElementById('labelProgress').value);

  const [r1, r2] = await Promise.all([
    api(`/api/performance/label/${userId}`,    'PUT', { label }),
    api(`/api/performance/progress/${userId}`, 'PUT', { progress })
  ]);

  if (r1 && r2) {
    showToast('Performance data updated!', 'success');
    closeModal('labelModal');
    switchSection(getActiveSection());
  }
}
// ─── Exam Question Builder Logic ──────────────────────────────
let currentExamQuestions = [];
let questionEditors = {}; // Store Monaco instances by idx

const DEFAULT_BOILERPLATES = {
    'javascript': '// SPX JavaScript Environment\nconsole.log("Hello, World!");',
    'python': '# SPX Python Environment\nprint("Hello, World!")',
    'java': '// SPX Java Environment\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n    }\n}',
    'c': '// SPX C (Structural) Environment\n#include <stdio.h>\n\nint main() {\n    printf("Hello, World!\\n");\n    return 0;\n}',
    'cpp': '// SPX C++ (Object Oriented) Environment\n#include <iostream>\n\nint main() {\n    std::cout << "Hello, World!" << std::endl;\n    return 0;\n}',
    'html': '<!DOCTYPE html>\n<html>\n<head>\n    <title>SPX Assessment</title>\n</head>\n<body>\n    <h1>Hello, World!</h1>\n</body>\n</html>',
    'css': '/* SPX Custom CSS Styling */\nbody {\n    background-color: #f8fafc;\n    color: #1e293b;\n    font-family: "Outfit", sans-serif;\n}'
};

  let monacoLoaderPromise = null;

  function ensureMonacoLoader() {
    if (window.monaco && window.require) {
      return Promise.resolve();
    }

    if (!monacoLoaderPromise) {
      monacoLoaderPromise = new Promise((resolve, reject) => {
        const existing = document.querySelector('script[data-monaco-loader="true"]');
        if (existing && window.require) {
          resolve();
          return;
        }

        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.44.0/min/vs/loader.min.js';
        script.async = true;
        script.dataset.monacoLoader = 'true';
        script.onload = () => {
          if (window.require && typeof window.require.config === 'function') {
            window.require.config({
              paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.44.0/min/vs' }
            });
          }
          resolve();
        };
        script.onerror = () => {
          monacoLoaderPromise = null;
          reject(new Error('Failed to load Monaco editor.'));
        };
        document.head.appendChild(script);
      });
    }

    return monacoLoaderPromise;
  }

  function syncQuestionEditorsToArray() {
    Object.entries(questionEditors).forEach(([idx, editor]) => {
      const question = currentExamQuestions[idx];
      if (question && question.type === 'coding') {
        question.boilerplate = editor.getValue();
      }
    });
  }

  async function hydrateQuestionEditors() {
    const codingQuestions = currentExamQuestions.some(q => q.type === 'coding');
    if (!codingQuestions) {
      return;
    }

    try {
      await ensureMonacoLoader();
    } catch {
      showToast('Question editor failed to load.', 'error');
      return;
    }

    setTimeout(() => {
      currentExamQuestions.forEach((q, idx) => {
        if (q.type === 'coding' && !questionEditors[idx]) {
          window.require(['vs/editor/editor.main'], function() {
            if (!document.getElementById(`editor_${idx}`) || questionEditors[idx]) return;
            const editor = monaco.editor.create(document.getElementById(`editor_${idx}`), {
              value: q.boilerplate || '',
              language: q.language || 'javascript',
              theme: 'vs-light',
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
              fontSize: 13,
              automaticLayout: true
            });
            questionEditors[idx] = editor;
          });
        }
      });
    }, 100);
  }

async function openQuestionsModal(examId, title) {
    const targetField = document.getElementById('qExamId');
    targetField.value = examId;
    targetField.dataset.entityType = 'exam';
    document.getElementById('qModalTitle').innerText = `Logic Distribution: ${title}`;
    
    const exam = await api('/api/exams/list');
    if (!exam) return;

    const target = exam.find(e => e._id === examId);
    if (!target) {
      showToast('Assessment node was not found.', 'error');
      return;
    }

    currentExamQuestions = target.questions || [];

    renderQuestionBuilder();
    openModal('questionsModal');
}


async function openMockQuestionsModal(mockId, title) {
    const targetField = document.getElementById('qExamId');
    targetField.value = mockId;
    targetField.dataset.entityType = 'mock';
    document.getElementById('qModalTitle').innerText = `Logic Distribution: ${title} (Mock)`;

    const mocks = await api('/api/mocks/list');
    if (!mocks) return;

    const target = mocks.find(m => m._id === mockId);
    if (!target) {
      showToast('Mock node was not found.', 'error');
      return;
    }

    currentExamQuestions = target.questions || [];
    renderQuestionBuilder();
    openModal('questionsModal');
}

function parseLegacyTestCases(raw) {
    if (!raw || !raw.trim()) return [];
    try { const p = JSON.parse(raw); if (Array.isArray(p)) return p; } catch {}
    return raw.split('\n').filter(l=>l.trim()).map(line=>{
        const parts = line.split('|');
        return { input:(parts[0]||'').replace(/^in:/i,'').trim(), expected:(parts[1]||'').replace(/^out:/i,'').trim() };
    }).filter(tc=>tc.input||tc.expected);
}

window.addTestCaseRow = function(qIdx) {
    if (!currentExamQuestions[qIdx].test_cases_rows) {
        currentExamQuestions[qIdx].test_cases_rows = parseLegacyTestCases(currentExamQuestions[qIdx].test_cases||'');
    }
    currentExamQuestions[qIdx].test_cases_rows.push({input:'',expected:''});
    renderQuestionBuilder();
};

window.removeTestCaseRow = function(qIdx, tcIdx) {
    currentExamQuestions[qIdx].test_cases_rows.splice(tcIdx,1);
    renderQuestionBuilder();
};

window.updateTestCaseRow = function(qIdx, tcIdx, field, val) {
    if (!currentExamQuestions[qIdx].test_cases_rows) {
        currentExamQuestions[qIdx].test_cases_rows = [];
    }
    currentExamQuestions[qIdx].test_cases_rows[tcIdx][field] = val;
};

function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

function renderQuestionBuilder() {
    Object.values(questionEditors).forEach(ed => ed.dispose());
    questionEditors = {};

    // Ensure test_cases_rows is initialised for each coding question
    currentExamQuestions.forEach(q => {
        if (q.type === 'coding' && !q.test_cases_rows) {
            q.test_cases_rows = parseLegacyTestCases(q.test_cases || q.testCases || '');
        }
    });

    const container = document.getElementById('questionsContainer');
    if (currentExamQuestions.length === 0) {
        container.innerHTML = `<div class="empty-state" style="padding:2.5rem;text-align:center;"><div style="font-size:3rem;margin-bottom:1rem;">📋</div><h3>No questions yet</h3><p style="color:var(--text-muted);">Click <b>＋ Add MCQ Question</b> or <b>＋ Add Coding Question</b> below to add your first question.</p></div>`;
        return;
    }

    container.innerHTML = currentExamQuestions.map((q, idx) => {
      const tcRows = q.test_cases_rows || [];
      return `
      <div style="background:#fff;border:1.5px solid #e2e8f0;border-radius:16px;padding:1.8rem;box-shadow:0 2px 8px rgba(0,0,0,.04);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.4rem;padding-bottom:1rem;border-bottom:1.5px solid #f1f5f9;">
          <div style="display:flex;align-items:center;gap:0.8rem;">
            <span style="background:${q.type==='mcq'?'#e37933':'#007acc'};color:#fff;padding:0.3rem 0.9rem;border-radius:6px;font-weight:700;font-size:0.78rem;">
              ${q.type==='mcq'?'📋 MCQ (Multiple Choice)':'💻 Coding Challenge'}
            </span>
            <span style="color:var(--text-muted);font-size:0.8rem;font-weight:600;">Question ${idx+1}</span>
          </div>
          <button class="btn btn-sm btn-danger" onclick="removeQuestion(${idx})">🗑️ Remove</button>
        </div>

        <div class="form-group">
          <label style="font-weight:700;">Question Text <span style="color:#ef4444">*</span></label>
          <textarea onchange="updateQuestion(${idx},'text',this.value)" placeholder="${q.type==='mcq'?'e.g. What does the === operator do in JavaScript?':'Describe the problem clearly. e.g. Write a function that returns the square of a number.'}" style="height:90px;padding:0.85rem;font-size:0.9rem;">${q.text||''}</textarea>
        </div>

        ${q.type==='mcq'?`
        <div class="form-group">
          <label style="font-weight:700;">Options — select the correct answer using the radio button ✓</label>
          <div style="display:flex;flex-direction:column;gap:0.6rem;margin-top:0.5rem;">
            ${(q.options||['','','','']).map((opt,optIdx)=>`
            <div style="display:flex;align-items:center;gap:0.8rem;background:${q.correct_answer_index===optIdx?'#f0fdf4':'#f8fafc'};border:1.5px solid ${q.correct_answer_index===optIdx?'#22c55e':'#e2e8f0'};border-radius:10px;padding:0.6rem 0.9rem;transition:all .2s;">
              <input type="radio" name="correct_${idx}" ${q.correct_answer_index===optIdx?'checked':''} onchange="updateQuestion(${idx},'correct_answer_index',${optIdx})" style="width:18px;height:18px;cursor:pointer;" title="Mark as correct">
              <span style="background:${q.correct_answer_index===optIdx?'#22c55e':'#94a3b8'};color:#fff;border-radius:50%;width:24px;height:24px;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:700;flex-shrink:0;">${String.fromCharCode(65+optIdx)}</span>
              <input type="text" value="${esc(opt)}" onchange="updateQuestionOption(${idx},${optIdx},this.value)" placeholder="Option ${String.fromCharCode(65+optIdx)}" style="flex:1;border:none;background:transparent;font-size:0.9rem;outline:none;">
              ${q.correct_answer_index===optIdx?'<span style="color:#22c55e;font-size:0.78rem;font-weight:700;">✓ Correct Answer</span>':''}
            </div>`).join('')}
          </div>
        </div>
        <div class="form-group" style="margin-top:1rem;">
          <label style="font-weight:700;">Points for this Question</label>
          <input type="number" value="${q.points||1}" min="1" onchange="updateQuestion(${idx},'points',parseInt(this.value))" style="width:100px;padding:0.6rem;border-radius:8px;border:1.5px solid #e2e8f0;">
        </div>
        ` : `
        <div style="display:grid;grid-template-columns:190px 1fr;gap:1.5rem;margin-bottom:1.2rem;">
          <div>
            <div class="form-group">
              <label style="font-weight:700;">Programming Language</label>
              <select onchange="updateQuestion(${idx},'language',this.value)" style="background:#f8fafc;padding:0.6rem;border-radius:8px;border:1.5px solid #e2e8f0;width:100%;">
                <option value="python" ${q.language==='python'?'selected':''}>🐍 Python</option>
                <option value="javascript" ${q.language==='javascript'?'selected':''}>🟨 JavaScript</option>
                <option value="java" ${q.language==='java'?'selected':''}>☕ Java</option>
                <option value="cpp" ${q.language==='cpp'?'selected':''}>⚙️ C++</option>
                <option value="c" ${q.language==='c'?'selected':''}>🔧 C</option>
                <option value="html" ${q.language==='html'?'selected':''}>🌐 HTML</option>
                <option value="css" ${q.language==='css'?'selected':''}>🎨 CSS</option>
              </select>
            </div>
            <div class="form-group">
              <label style="font-weight:700;">Points</label>
              <input type="number" value="${q.points||10}" min="1" onchange="updateQuestion(${idx},'points',parseInt(this.value))" style="width:100%;padding:0.6rem;border-radius:8px;border:1.5px solid #e2e8f0;">
            </div>
            <div class="form-group">
              <label style="font-weight:700;">Constraints <small style="color:var(--text-muted)">(optional)</small></label>
              <textarea onchange="updateQuestion(${idx},'constraints',this.value)" placeholder="e.g. 1 ≤ n ≤ 1000, Time: 1s" style="height:70px;background:#f8fafc;font-size:0.82rem;">${q.constraints||''}</textarea>
            </div>
          </div>
          <div class="form-group">
            <label style="font-weight:700;">Starter Code <small style="color:var(--text-muted)">(shown to intern in the editor)</small></label>
            <div id="editor_${idx}" style="height:240px;border:1.5px solid #e2e8f0;border-radius:10px;overflow:hidden;"></div>
          </div>
        </div>

        <div style="background:#f8fafc;border-radius:12px;padding:1.2rem;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.8rem;">
            <div>
              <label style="font-weight:700;font-size:0.88rem;">Test Cases</label>
              <p style="font-size:0.76rem;color:var(--text-muted);margin-top:0.2rem;">Enter an Input value and the Expected Output. The system auto-checks when the intern clicks Run.</p>
            </div>
            <button class="btn btn-sm btn-secondary" onclick="addTestCaseRow(${idx})" style="white-space:nowrap;flex-shrink:0;">＋ Add Test Case</button>
          </div>
          <div id="tcRows_${idx}" style="display:flex;flex-direction:column;gap:0.5rem;">
            ${tcRows.length===0
              ? `<p style="color:var(--text-muted);font-size:0.82rem;text-align:center;padding:0.6rem;background:#fff;border-radius:8px;border:1px dashed #e2e8f0;">No test cases yet — click <b>＋ Add Test Case</b></p>`
              : tcRows.map((tc,ti)=>`
              <div style="display:grid;grid-template-columns:1fr 1fr 32px;gap:0.7rem;align-items:end;background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:0.7rem 0.9rem;">
                <div>
                  <label style="font-size:0.7rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Input</label>
                  <input type="text" value="${esc(tc.input||'')}" onchange="updateTestCaseRow(${idx},${ti},'input',this.value)" placeholder="e.g. 5" style="width:100%;margin-top:0.2rem;padding:0.45rem 0.6rem;border:1px solid #e2e8f0;border-radius:6px;font-family:monospace;font-size:0.85rem;">
                </div>
                <div>
                  <label style="font-size:0.7rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Expected Output</label>
                  <input type="text" value="${esc(tc.expected||tc.output||'')}" onchange="updateTestCaseRow(${idx},${ti},'expected',this.value)" placeholder="e.g. 25" style="width:100%;margin-top:0.2rem;padding:0.45rem 0.6rem;border:1px solid #e2e8f0;border-radius:6px;font-family:monospace;font-size:0.85rem;">
                </div>
                <button onclick="removeTestCaseRow(${idx},${ti})" title="Remove" style="background:none;border:1px solid #fecaca;color:#ef4444;border-radius:6px;cursor:pointer;width:32px;height:32px;font-size:1rem;display:flex;align-items:center;justify-content:center;">✕</button>
              </div>`).join('')}
          </div>
        </div>
        `}
      </div>`;
    }).join('');

        void hydrateQuestionEditors();
}

function addQuestion(type) {
        syncQuestionEditorsToArray();
    const defaultLang = 'javascript';
    const q = {
        type,
        text: '',
        points: 10,
        options: type === 'mcq' ? ['', '', '', ''] : [],
        correct_answer_index: type === 'mcq' ? 0 : null,
        language: defaultLang,
        boilerplate: DEFAULT_BOILERPLATES[defaultLang] || '',
        constraints: '',
        test_cases: ''
    };
    currentExamQuestions.push(q);
    renderQuestionBuilder();
}

function removeQuestion(idx) {
  syncQuestionEditorsToArray();
    if (questionEditors[idx]) {
        questionEditors[idx].dispose();
        delete questionEditors[idx];
    }
    currentExamQuestions.splice(idx, 1);
    renderQuestionBuilder();
}

function updateQuestion(idx, key, val) {
    currentExamQuestions[idx][key] = val;
    
    // Update Monaco language dynamically if language select changed
    if (key === 'language' && questionEditors[idx]) {
        const model = questionEditors[idx].getModel();
        monaco.editor.setModelLanguage(model, val);
        
        // If current boilerplate is empty or matches a default, update it to the new default
        const currentVal = questionEditors[idx].getValue().trim();
        const isCurrentlyEmptyOrDefault = !currentVal || Object.values(DEFAULT_BOILERPLATES).some(b => b.trim() === currentVal);
        
        if (isCurrentlyEmptyOrDefault && DEFAULT_BOILERPLATES[val]) {
            questionEditors[idx].setValue(DEFAULT_BOILERPLATES[val]);
            currentExamQuestions[idx].boilerplate = DEFAULT_BOILERPLATES[val];
        }
    }
}

function updateQuestionOption(qIdx, optIdx, val) {
    currentExamQuestions[qIdx].options[optIdx] = val;
}

async function saveQuestions() {
    // Sync Monaco content to array
    currentExamQuestions.forEach((q, idx) => {
        if (q.type === 'coding' && questionEditors[idx]) {
            q.boilerplate = questionEditors[idx].getValue();
        }
        // Convert row-based test cases back to the stored array format
        if (q.test_cases_rows) {
            q.test_cases = q.test_cases_rows.filter(tc => tc.input || tc.expected);
            // Keep rows in sync
        }
    });

    const targetField = document.getElementById('qExamId');
    const targetId = targetField.value;
    const entityType = targetField.dataset.entityType || 'exam';
    const endpoint = entityType === 'mock'
      ? `/api/mocks/${targetId}/questions`
      : `/api/exams/${targetId}/questions`;

    const res = await api(endpoint, 'PATCH', currentExamQuestions);
    if (res) {
        showToast('✅ Questions saved successfully!', 'success');
        closeModal('questionsModal');
      switchSection(entityType === 'mock' ? 'mocks' : 'exams');
    }
}


async function showInternInsights(studentId) {
  const group = (window.currentAttendanceGroups || {})[studentId];
  if (!group) return;

  const totalWeights = group.totalWeight;
  const totalDays = window.currentAttendanceTotalDays || 1;
  const pct = Math.min(Math.round((totalWeights / totalDays) * 100), 100);

  // Calculate breakdown
  const days = Object.keys(group.dayWeights).length;
  const fullDays = Object.values(group.dayWeights).filter(w => w >= 0.95).length;
  const partialDays = Object.values(group.dayWeights).filter(w => w > 0 && w < 0.95).length;
  const absentDays = totalDays - (fullDays + partialDays);

  const modalHtml = `
    <div class='modal-header'>
      <div>
        <h2 style="font-size:1.3rem; font-weight:900; background:var(--accent-gradient); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;">Intern Reliability Report</h2>
        <p style='font-weight:700; color:var(--primary); font-size:0.9rem;'>${group.name} (${group.id})</p>
      </div>
      <button class='modal-close' onclick='closeModal()'>&times;</button>
    </div>
    
    <div style='display:grid; grid-template-columns: 1fr 1.2fr; gap:2rem; align-items:center;'>
      <div style='text-align:center; position:relative;'>
        <div style='width:160px; height:160px; margin:0 auto; border-radius:50%; background:conic-gradient(var(--primary) ${pct}%, #f1f5f9 0); display:flex; align-items:center; justify-content:center; box-shadow:0 15px 35px rgba(79, 70, 229, 0.1);'>
          <div style='width:130px; height:130px; background:#fff; border-radius:50%; display:flex; flex-direction:column; align-items:center; justify-content:center;'>
            <span style='font-size:2.2rem; font-weight:900; color:var(--text-main); line-height:1;'>${pct}%</span>
            <span style='font-size:0.6rem; font-weight:800; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; margin-top:0.2rem;'>Reliability</span>
          </div>
        </div>
        <div style='margin-top:1.5rem; font-size:0.85rem; color:var(--text-sub); font-weight:700;'>
          <span style="color:var(--primary)">${totalWeights}</span> Credits Earned / ${totalDays} Max
        </div>
      </div>
      
      <div>
        <div style='margin-bottom:1.5rem;'>
          <h4 style='font-size:0.7rem; font-weight:900; color:var(--text-muted); text-transform:uppercase; margin-bottom:1rem; letter-spacing:1px;'>Performance Breakdown</h4>
          <div style='display:flex; flex-direction:column; gap:0.6rem;'>
            <div style='display:flex; justify-content:space-between; align-items:center; background:#f0fdf4; padding:0.75rem 1rem; border-radius:12px; border:1px solid #dcfce7;'>
              <span style='font-size:0.82rem; font-weight:700; color:#166534;'>Full Presence</span>
              <span style='font-weight:900; color:#15803d; font-size:0.9rem;'>${fullDays} Days</span>
            </div>
            <div style='display:flex; justify-content:space-between; align-items:center; background:#fff7ed; padding:0.75rem 1rem; border-radius:12px; border:1px solid #ffedd5;'>
              <span style='font-size:0.82rem; font-weight:700; color:#9a3412;'>Partial (In-Only)</span>
              <span style='font-weight:900; color:#c2410c; font-size:0.9rem;'>${partialDays} Days</span>
            </div>
            <div style='display:flex; justify-content:space-between; align-items:center; background:#fef2f2; padding:0.75rem 1rem; border-radius:12px; border:1px solid #fee2e2;'>
              <span style='font-size:0.82rem; font-weight:700; color:#991b1b;'>Absences / Missed</span>
              <span style='font-weight:900; color:#b91c1c; font-size:0.9rem;'>${absentDays} Days</span>
            </div>
          </div>
        </div>
        
        <div style='background:linear-gradient(135deg, rgba(79,70,229,0.05), rgba(217,70,239,0.05)); border:1px solid rgba(79,70,229,0.1); border-radius:16px; padding:1.2rem;'>
          <h5 style='font-size:0.7rem; font-weight:900; color:var(--primary); text-transform:uppercase; margin-bottom:0.5rem; letter-spacing:0.5px;'>Insights & Guidance</h5>
          <p style='font-size:0.82rem; color:var(--text-sub); line-height:1.5; font-weight:500;'>
            ${pct >= 90 ? 'Exceptional consistency. Intern is highly reliable and follows all check-in/out protocols.' : 
              pct >= 75 ? 'Good reliability. Minor gaps in check-out consistency but generally compliant.' : 
              'Low consistency detected. Frequent missing check-outs. Intervention recommended to improve professional logging habits.'}
          </p>
        </div>
      </div>
    </div>`;

  const modal = document.getElementById('modalBox');
  const modalOverlay = document.getElementById('modalOverlay');
  modal.innerHTML = modalHtml;
  modalOverlay.classList.add('active');
}
