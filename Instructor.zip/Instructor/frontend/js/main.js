
// Centralized API Configuration
const API_BASE_URL = ''; // Same-Origin Integration enabled

// Utility function for fetching
async function apiCall(endpoint, method = 'GET', data = null) {
    const token = localStorage.getItem('access_token');
    const headers = {
        'Content-Type': 'application/json'
    };
    
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    const options = {
        method,
        headers
    };
    
    if (data) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const error = new Error(payload.detail || 'Please enter valid details.');
            error.status = response.status;
            throw error;
        }
        return payload;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Instructor Login Orchestrator
async function handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const statusDiv = document.getElementById('login-status');
    
    if (!email || !password) {
        statusDiv.innerText = 'Please provide full identity credentials.';
        return;
    }
    
    try {
        statusDiv.style.color = 'var(--secondary)';
        statusDiv.innerText = 'Authenticating with Faculty Mainframe...';
        
        const data = await apiCall('/api/auth/login', 'POST', { email, password });

        if (!data || !data.access_token) {
            throw new Error('Please enter valid details.');
        }

        localStorage.setItem('access_token', data.access_token);
        statusDiv.style.color = '#22c55e';
        statusDiv.innerText = 'Identity Verified. Redirecting to Terminal...';
        
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    } catch (err) {
        statusDiv.style.color = '#ef4444';
        statusDiv.innerText = 'Please enter valid details.';
    }
}

// Initialize Login Terminal
document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('loginBtn');
    if (loginBtn) {
        loginBtn.addEventListener('click', handleLogin);
    }
});
