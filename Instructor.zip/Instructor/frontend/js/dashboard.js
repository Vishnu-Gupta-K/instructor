/* ═══════════════════════════════════════════════════════════
   SPX Faculty Command Center — dashboard.js (Part 1)
   Core init, utilities, Performance & Tasks sections
   ═══════════════════════════════════════════════════════════ */

const API = '';  // same-origin
const DASHBOARD_SECTION_KEY = 'spx.dashboard.section';
const DASHBOARD_SECTIONS = new Set([
  'performance',
  'interns',
  'tasks',
  'projects',
  'exams',
  'mocks',
  'interviews',
  'attendance',
  'leaves',
  'profile'
]);
let dashboardScrollLockUntil = 0;

if ('scrollRestoration' in history) {
  history.scrollRestoration = 'manual';
}

function resetDashboardScroll() {
  window.scrollTo(0, 0);
  document.documentElement.scrollTop = 0;
  document.body.scrollTop = 0;
  const scroller = document.scrollingElement || document.documentElement;
  if (scroller) scroller.scrollTop = 0;
  const main = document.getElementById('mainContent');
  if (main) main.scrollTop = 0;
}

function forceDashboardTop(retries = 8) {
  resetDashboardScroll();
  if (retries <= 0) return;
  requestAnimationFrame(() => {
    resetDashboardScroll();
    setTimeout(() => forceDashboardTop(retries - 1), 50);
  });
}

function lockDashboardTop(duration = 1600) {
  dashboardScrollLockUntil = Date.now() + duration;
  forceDashboardTop();
}

function normalizeSection(id) {
  return DASHBOARD_SECTIONS.has(id) ? id : 'performance';
}

function getStoredSection() {
  try {
    return sessionStorage.getItem(DASHBOARD_SECTION_KEY);
  } catch {
    return null;
  }
}

function getActiveSection() {
  const url = new URL(window.location.href);
  return normalizeSection(url.searchParams.get('section') || getStoredSection());
}

function syncSectionState(id) {
  const sectionId = normalizeSection(id);
  const url = new URL(window.location.href);
  url.searchParams.set('section', sectionId);
  url.hash = '';
  try {
    sessionStorage.setItem(DASHBOARD_SECTION_KEY, sectionId);
  } catch {
    // Ignore storage failures and continue with the URL state.
  }
  history.replaceState(null, '', `${url.pathname}${url.search}`);
}

// ─── Auth Helpers ────────────────────────────────────────────
function getToken() { return localStorage.getItem('access_token'); }

function decodeToken() {
  const t = getToken();
  if (!t) return null;
  try { return JSON.parse(atob(t.split('.')[1])); } catch { return null; }
}

// ─── API Call ────────────────────────────────────────────────
async function api(endpoint, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${getToken()}`
    }
  };
  if (body) opts.body = JSON.stringify(body);
  try {
    const r = await fetch(API + endpoint, opts);
    if (r.status === 401) { logout(); return null; }
    if (r.status === 503) { showMaintenanceOverlay(); return null; }
    if (!r.ok) {
      const e = await r.json().catch(() => ({}));
      showToast(e.detail || 'Request failed', 'error');
      return null;
    }
    return await r.json();
  } catch(e) {
    showToast('Network error — check connection', 'error');
    return null;
  }
}

function showMaintenanceOverlay() {
  if (document.getElementById('maintenanceOverlay')) return;
  const overlay = document.createElement('div');
  overlay.id = 'maintenanceOverlay';
  overlay.style = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(15,23,42,0.95);z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;color:white;text-align:center;backdrop-filter:blur(8px);';
  overlay.innerHTML = `
    <div style="font-size:5rem;margin-bottom:1.5rem;">🏗️</div>
    <h1 style="font-size:2.5rem;margin-bottom:1rem;background:var(--accent-gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-weight:900;">NODE UNDER MAINTENANCE</h1>
    <p style="max-width:500px;line-height:1.6;color:rgba(255,255,255,0.7);font-size:1.1rem;margin-bottom:2rem;">
      The SPX Mainframe is currently undergoing critical infrastructure upgrades. 
      Access to this sector is temporarily restricted.
    </p>
    <div class="spinner"></div>
    <p style="margin-top:2rem;font-size:0.8rem;letter-spacing:1px;text-transform:uppercase;opacity:0.5;">Automatic reconnection attempt in progress...</p>
  `;
  document.body.appendChild(overlay);
  // Retry periodically
  setTimeout(() => { if (getToken()) location.reload(); }, 30000);
}

// ─── Toast ───────────────────────────────────────────────────
function showToast(msg, type = 'info') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${icons[type]}</span><span>${msg}</span>`;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ─── Modal ───────────────────────────────────────────────────
function openModal(id) {
  const m = document.getElementById(id);
  if (m) {
    document.body.appendChild(m); // Bring to front
    m.classList.add('active');
    m.style.display = 'flex';
    updateBodyScrollLock();
  }
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) {
    m.classList.remove('active');
    m.style.display = 'none';
    updateBodyScrollLock();
  }
}

function updateBodyScrollLock() {
  document.body.style.overflow = document.querySelector('.modal-overlay.active') ? 'hidden' : '';
}

// Close modal on backdrop click
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    closeModal(e.target.id);
  }
});

window.addEventListener('scroll', () => {
  if (Date.now() > dashboardScrollLockUntil) return;
  const currentY = window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
  if (currentY !== 0) resetDashboardScroll();
}, { passive: true });

// ─── Logout ──────────────────────────────────────────────────
function logout() {
  localStorage.removeItem('access_token');
  try {
    sessionStorage.removeItem(DASHBOARD_SECTION_KEY);
  } catch {
    // Ignore storage failures during logout.
  }
  window.location.href = 'login.html';
}

// ─── Auth Guard + Init ───────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  if (!getToken()) { window.location.href = 'login.html'; return; }

  lockDashboardTop();

  setupForms();

  const initialSection = getActiveSection();
  syncSectionState(initialSection);
  void switchSection(initialSection, true);

  void api('/api/auth/me').then(me => {
    if (me) {
      const name = me.full_name || me.email || 'Faculty';
      document.getElementById('facultyName').textContent = name;
      document.getElementById('facultyAvatar').textContent = name.charAt(0).toUpperCase();
    }
  });

  void loadInternCheckboxes();
  void updateSystemStats();

  // Keep the dashboard anchored at the top during the first paint.
  window.addEventListener('load', () => lockDashboardTop(), { once: true });
  window.addEventListener('pageshow', () => lockDashboardTop(), { once: true });

  // 2. Automated Background Synchronization (120s)
  setInterval(() => {
    if (document.visibilityState === 'visible') {
      const current = getActiveSection();
      void switchSection(current, true); // true = silent refresh
    }
  }, 120000);

  // 3. Hardware Diagnostics Sync (60s)
  setInterval(() => void updateSystemStats(), 60000);
});

async function updateSystemStats() {
  const stats = await api('/api/system/stats');
  if (!stats || !stats.hardware) return;
  document.getElementById('cpuVal').textContent = stats.hardware.cpu_load;
  document.getElementById('ramVal').textContent = stats.hardware.ram_usage;
  document.getElementById('uptimeVal').textContent = stats.hardware.uptime;
}

// ─── Section Router ───────────────────────────────────────────
async function switchSection(id, silent = false) {
  // Update section state without a full page refresh
  if (getActiveSection() !== id) {
    syncSectionState(id);
  }

  // Update nav active state
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  const activeBtn = document.getElementById('nav-' + id);
  if (activeBtn) activeBtn.classList.add('active');

  // Show spinner only on manual/new section switches
  const main = document.getElementById('mainContent');
  if (!silent) {
    main.innerHTML = `<div class="section-loading"><div class="spinner"></div><p>Loading ${id}...</p></div>`;
  }

  // Render section
  const renderers = {
    performance: renderPerformance,
    interns:     renderInterns,
    tasks:       renderTasks,
    projects:    renderProjects,
    exams:       renderExams,
    mocks:       renderMocks,
    interviews:  renderInterviews,
    attendance:  renderAttendance,
    leaves:      renderLeaves,
    profile:     renderProfile
  };
  if (renderers[id]) await renderers[id](main);

  if (!silent) {
    lockDashboardTop(1000);
  }
}

// ─── Load Interns for Task Assignment ────────────────────────
async function loadInternCheckboxes() {
  const interns = await api('/api/auth/interns');
  if (!interns) return;
  const container = document.getElementById('internCheckboxList');
  if (!container) return;
  container.innerHTML = interns.map(i => `
    <div class="checkbox-group">
      <input type="checkbox" id="intern-${i.user_id}" value="${i.user_id}" class="intern-cb">
      <label for="intern-${i.user_id}">${i.full_name} (${i.email})</label>
    </div>`).join('') || '<p style="color:var(--text-muted);font-size:0.8rem;">No interns registered yet.</p>';
}

// Toggle intern select panel
document.addEventListener('change', e => {
  if (e.target.id === 'taskAssignMode') {
    document.getElementById('internSelectGroup').style.display =
      e.target.value === 'specific' ? 'block' : 'none';
  }
});

async function syncAllPerformance(btn) {
  if (!confirm('Analyze and synchronize performance for all interns based on live production data? This will overwrite current labels and progress percentages.')) return;
  
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = '🔄 Analyzing...';
  
  const res = await api('/api/performance/sync-all', 'POST');
  if (res) {
    showToast(res.message, 'success');
    switchSection('performance');
  }
  btn.disabled = false;
  btn.textContent = originalText;
}

// ─── SECTION 1: PERFORMANCE ────────────────────────────────────
async function renderPerformance(main) {
  const [overview, interns] = await Promise.all([
    api('/api/performance/overview'),
    api('/api/performance/interns')
  ]);
  if (!overview || !interns) { main.innerHTML = '<p class="empty-state">Failed to load data.</p>'; return; }

  const ld = overview.label_distribution || {};
  const ts = overview.task_stats || {};
  const ss = overview.submission_stats || {};

  const labelColor = {
    'Excellent':         '#22c55e',
    'Average':           '#eab308',
    'Needs Improvement': '#ef4444',
    'Underperforming':   '#dc2626',
    'Needs Evaluation':  '#6366f1'
  };

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Performance Analytics</h2>
        <p class="section-sub">Live data — ${overview.total_interns} interns · ${ts.total || 0} tasks · ${overview.today_attendance || 0} present today</p>
      </div>
      <button class="btn" onclick="syncAllPerformance(this)">🔍 Analyze & Sync All</button>
    </div>

    <!-- Overview Stats -->
    <div class="stats-grid stagger">
      <div class="stat-card">
        <div class="stat-label">Total Interns</div>
        <div class="stat-value" style="color:#4f46e5">${overview.total_interns}</div>
        <div class="stat-meta">Registered in system</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Avg Progress</div>
        <div class="stat-value" style="color:#8b5cf6">${overview.avg_progress}%</div>
        <div class="stat-meta">Across all interns</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Pending Submissions</div>
        <div class="stat-value" style="color:#eab308">${ss.pending || 0}</div>
        <div class="stat-meta">Awaiting grading</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Graded</div>
        <div class="stat-value" style="color:#22c55e">${ss.graded || 0}</div>
        <div class="stat-meta">Assessments complete</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Today Attendance</div>
        <div class="stat-value" style="color:#d946ef">${overview.today_attendance || 0}</div>
        <div class="stat-meta">Check-ins (IST)</div>
      </div>
    </div>

    <!-- Label Distribution -->
    <div class="glass-panel fade-up" style="margin-bottom:2rem;">
      <h3 style="font-size:1rem;font-weight:800;margin-bottom:1.5rem;color:var(--text-sub);">Label Distribution</h3>
      <div style="display:flex;gap:1.5rem;flex-wrap:wrap;">
        ${Object.entries(ld).map(([label, count]) => `
          <div style="flex:1;min-width:120px;background:#f8fafc;border-radius:12px;padding:1rem;text-align:center;border-left:4px solid ${labelColor[label]||'#6366f1'}">
            <div style="font-size:1.5rem;font-weight:900;color:${labelColor[label]||'#6366f1'}">${count}</div>
            <div style="font-size:0.72rem;font-weight:700;color:var(--text-muted);margin-top:0.3rem;">${label}</div>
          </div>`).join('') || '<p style="color:var(--text-muted);">No labels assigned yet.</p>'}
      </div>
    </div>

    <!-- Intern Table -->
    <div class="glass-panel fade-up">
      <h3 style="font-size:1rem;font-weight:800;margin-bottom:1.5rem;color:var(--text-sub);">Intern Roster</h3>
      ${(() => {
        if (interns.length === 0) return `<div class="empty-state"><div class="empty-icon">👥</div><p>No interns registered yet.</p></div>`;
        return `
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>Identity</th><th>Email</th><th>Progress</th><th>Tasks</th><th>Avg Score</th><th>Label</th><th>Action</th>
          </tr></thead>
          <tbody>
            ${interns.map(i => {
              const ls = i.live_stats || {};
              const labelClass = {
                'Excellent':'label-excellent','Average':'label-average',
                'Needs Improvement':'label-needs-imp','Underperforming':'label-underperform',
                'Needs Evaluation':'label-eval'
              }[i.performance_label] || 'label-eval';
              return `<tr>
                <td><span style="font-weight:700;color:var(--primary)">${i.user_id || 'N/A'}</span><br><span style="font-size:0.75rem;color:var(--text-muted)">${i.full_name}</span></td>
                <td style="font-size:0.8rem;">${i.email}</td>
                <td style="min-width:140px;">
                  <div class="progress-bar"><div class="progress-fill" style="width:${i.overall_progress}%"></div></div>
                  <span style="font-size:0.7rem;color:var(--text-muted)">${i.overall_progress}%</span>
                </td>
                <td style="font-size:0.75rem;">
                  ${ls.tasks_submitted||0}/${ls.tasks_assigned||0}
                  <div style="font-size:0.62rem;color:var(--text-muted);margin-top:0.25rem;font-weight:600;">
                    Att: ${i.performance_metrics?.attendance_rate || 0}% | Score: ${i.performance_metrics?.academic_avg || 0}
                  </div>
                </td>
                <td style="font-weight:800;color:var(--primary)">${ls.avg_marks||0}</td>
                <td>
                  <span class="badge ${labelClass}">${i.performance_label}</span>
                  ${(i.suggested_label && i.suggested_label !== i.performance_label) ? `<br><span style="font-size:0.6rem;color:var(--text-muted);font-weight:800;">Suggest: ${i.suggested_label}</span>` : ''}
                </td>
                <td>
                  <div style="display:flex;gap:0.4rem;">
                    <button class="btn btn-sm btn-secondary" onclick="openLabelModal('${i.user_id}','${i.performance_label}',${i.overall_progress})">✏️ Edit</button>
                    <button class="btn btn-sm ${i.is_active ? 'btn-danger' : 'btn-success'}" onclick="toggleInternStatus('${i.user_id}', ${i.is_active})">
                      ${i.is_active ? '🚫 Deactivate' : '✅ Activate'}
                    </button>
                  </div>
                </td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>`;
      })()}
    </div>`;
}

async function renderInterns(main) {
  const [overview, interns] = await Promise.all([
    api('/api/performance/overview'),
    api('/api/performance/interns')
  ]);
  if (!overview || !interns) {
    main.innerHTML = '<p class="empty-state">Failed to load data.</p>';
    return;
  }

  const activeCount = interns.filter(i => i.is_active !== false).length;
  const inactiveCount = Math.max(0, interns.length - activeCount);
  const needsEvaluation = interns.filter(i => (i.performance_label || 'Needs Evaluation') === 'Needs Evaluation').length;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Intern Management</h2>
        <p class="section-sub">Provision accounts, review roster status, and keep the cohort synced with Atlas.</p>
      </div>
      <button class="btn" onclick="openProvisionModal()">＋ Provision Intern</button>
    </div>

    <div class="stats-grid stagger">
      <div class="stat-card">
        <div class="stat-label">Total Interns</div>
        <div class="stat-value" style="color:#4f46e5">${overview.total_interns}</div>
        <div class="stat-meta">Registered in system</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Active Accounts</div>
        <div class="stat-value" style="color:#22c55e">${activeCount}</div>
        <div class="stat-meta">Able to sign in</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Disabled</div>
        <div class="stat-value" style="color:#ef4444">${inactiveCount}</div>
        <div class="stat-meta">Held out of portal</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Needs Evaluation</div>
        <div class="stat-value" style="color:#eab308">${needsEvaluation}</div>
        <div class="stat-meta">Awaiting label update</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Avg Progress</div>
        <div class="stat-value" style="color:#8b5cf6">${overview.avg_progress}%</div>
        <div class="stat-meta">Across all interns</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Batch Filter</div>
        <div style="margin-top: 1rem;">
          <select id="batchFilter" onchange="renderInterns(document.getElementById('mainContent'))" style="width: 100%; padding: 0.5rem; border-radius: 8px; border: 1px solid var(--glass-border); background: var(--glass-bg); color: var(--text-main); font-weight: 600;">
            <option value="">All Batches</option>
            <option value="Summer-Interns-2024">Summer Interns (2024)</option>
            <option value="Winter-Interns-2024">Winter Interns (2024)</option>
            <option value="Autumn-Interns-2024">Autumn Interns (2024)</option>
            <option value="Spring-Interns-2025">Spring Interns (2025)</option>
            <option value="Summer-Interns-2026">Summer Interns (2026)</option>
            <option value="Spring-Interns-2026">Spring Interns (2026)</option>
          </select>
        </div>
      </div>
    </div>

    <div class="glass-panel fade-up">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;flex-wrap:wrap;margin-bottom:1.5rem;">
        <div>
          <h3 style="font-size:1rem;font-weight:800;color:var(--text-sub);margin-bottom:0.35rem;">Provisioned Interns</h3>
          <p style="font-size:0.82rem;color:var(--text-light);">Use the label and status actions to keep the roster aligned with the dashboard.</p>
        </div>
        <button class="btn btn-secondary" onclick="switchSection('performance')">View Analytics</button>
      </div>

      ${(() => {
        const batchFilter = document.getElementById('batchFilter')?.value || '';
        const filteredInterns = interns.filter(i => !batchFilter || i.batch === batchFilter);
        if (filteredInterns.length === 0) return `<div class="empty-state"><div class="empty-icon">👥</div><p>No interns found matching the filter.</p></div>`;
        
        return `
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>Identity</th><th>Contact</th><th>Batch</th><th>Progress</th><th>Label</th><th>Status</th><th>Action</th>
          </tr></thead>
          <tbody>
            ${filteredInterns.map(i => {
              const labelClass = {
                'Excellent':'label-excellent','Average':'label-average',
                'Needs Improvement':'label-needs-imp','Underperforming':'label-underperform',
                'Needs Evaluation':'label-eval'
              }[i.performance_label] || 'label-eval';
              const statusActive = i.is_active !== false;
              const statusColor = statusActive ? '#22c55e' : '#ef4444';
              const statusText = statusActive ? 'Active' : 'Disabled';
              const uBatch = i.batch || 'N/A';
              return `<tr>
                <td><span style="font-weight:700;color:var(--primary)">${i.user_id || 'N/A'}</span><br><span style="font-size:0.75rem;color:var(--text-muted)">${i.full_name || 'Unnamed Intern'}</span></td>
                <td style="font-size:0.8rem;line-height:1.5;">${i.email}<br><span style="color:var(--text-muted)">${i.phone || 'No phone'}</span></td>
                <td><span class="badge" style="background: var(--primary)10; color: var(--primary); border: 1px solid var(--primary)30;">${uBatch}</span></td>
                <td style="min-width:150px;">
                  <div class="progress-bar"><div class="progress-fill" style="width:${i.overall_progress || 0}%"></div></div>
                  <span style="font-size:0.7rem;color:var(--text-muted)">${i.overall_progress || 0}%</span>
                </td>
                <td>
                  <span class="badge ${labelClass}">${i.performance_label || 'Needs Evaluation'}</span>
                  ${(i.suggested_label && i.suggested_label !== i.performance_label) ? `<br><span style="font-size:0.6rem;color:var(--text-muted);font-weight:800;">Suggest: ${i.suggested_label}</span>` : ''}
                </td>
                <td><span class="badge" style="background:${statusColor}18;color:${statusColor};border:1px solid ${statusColor}33;">${statusText}</span></td>
                <td>
                  <div style="display:flex;gap:0.4rem;flex-wrap:wrap;">
                    <button class="btn btn-sm btn-secondary" onclick="openLabelModal('${i.user_id}','${i.performance_label || 'Needs Evaluation'}',${i.overall_progress || 0})">✏️ Edit</button>
                    <button class="btn btn-sm ${statusActive ? 'btn-danger' : 'btn-success'}" onclick="toggleInternStatus('${i.user_id}', ${statusActive})">
                      ${statusActive ? '🚫 Deactivate' : '✅ Activate'}
                    </button>
                  </div>
                </td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>`;
      })()}
    </div>`;
}

function openProvisionModal() {
  const form = document.getElementById('userForm');
  if (form) form.reset();


  const title = document.getElementById('modalTitle');
  if (title) title.innerText = 'Provision Intern';

  const otpNode = document.getElementById('otp-node');
  if (otpNode) otpNode.style.display = 'none';

  const otpBtn = document.getElementById('btn-otp-trigger');
  if (otpBtn) otpBtn.style.display = 'block';

  const finalBtn = document.getElementById('btn-final-provision');
  if (finalBtn) finalBtn.style.display = 'none';

  const errorPanel = document.getElementById('modal-error');
  if (errorPanel) {
    errorPanel.innerText = '';
    errorPanel.style.display = 'none';
  }

  openModal('userModal');
}

async function initiateProvisioningFlow() {
  const email = document.getElementById('em')?.value?.trim();
  const errPanel = document.getElementById('modal-error');
  if (!email) {
    if (errPanel) {
      errPanel.innerText = 'Error: System requires a valid Gmail address for identity verification.';
      errPanel.style.display = 'block';
    }
    return;
  }

  try {
    const res = await api('/api/auth/send-otp', 'POST', { email });
    if (res?.message) {
      const otpNode = document.getElementById('otp-node');
      if (otpNode) otpNode.style.display = 'block';

      const otpBtn = document.getElementById('btn-otp-trigger');
      if (otpBtn) otpBtn.style.display = 'none';

      const finalBtn = document.getElementById('btn-final-provision');
      if (finalBtn) finalBtn.style.display = 'block';

      if (errPanel) errPanel.style.display = 'none';

      showToast(`Verification sequence dispatched to ${email}`, 'success');
    } else if (errPanel) {
      errPanel.innerText = res?.detail || 'Identity Check Failed.';
      errPanel.style.display = 'block';
    }
  } catch (err) {
    if (errPanel) {
      errPanel.innerText = 'Connection Breach: SMTP Cluster unresponsive.';
      errPanel.style.display = 'block';
    }
  }
}

function resendOTP() {
  initiateProvisioningFlow();
}

// ─── SECTION 2: TASKS ─────────────────────────────────────────
async function renderTasks(main) {
  const tasks = await api('/api/tasks/list');
  if (!tasks) return;

  main.innerHTML = `
    <div class="section-header fade-up">
      <div>
        <h2 class="section-title">Task Management</h2>
        <p class="section-sub">${tasks.length} active assignments · Data reflects in intern portal instantly</p>
      </div>
      <button class="btn" onclick="openNewTaskModal()">＋ Deploy Task</button>
    </div>
    ${tasks.length === 0 ? `<div class="empty-state"><div class="empty-icon">No Tasks</div><h3>No Tasks Deployed</h3><p>Create your first assignment above.</p></div>` :
    `<div class="tasks-grid stagger">${tasks.map(t => renderTaskCard(t)).join('')}</div>`}
  `;
}

function renderTaskCard(t) {
  const assignedCount = t.assigned_to && t.assigned_to.length > 0 ? t.assigned_to.length : 'All Interns';
  const submittedCount = t.submission_count || 0;
  const gradedCount = t.graded_count || 0;
  const isFullyGraded = gradedCount > 0 && gradedCount >= (t.assigned_to?.length || 0);
  const isOverdue = t.deadline_state === 'overdue';
  const dueLabel = t.deadline ? `Due: ${t.deadline}` : 'Open';

  const accent = isFullyGraded ? '#22c55e' : isOverdue ? '#ef4444' : (submittedCount > gradedCount) ? '#eab308' : '#4f46e5';
  const statusLabel = isFullyGraded ? 'All Graded' : isOverdue ? 'Overdue' : (submittedCount > gradedCount) ? `${submittedCount - gradedCount} Pending` : 'Assigned';
  const statusClass = isFullyGraded ? 'badge-graded' : isOverdue ? 'badge-inactive' : (submittedCount > gradedCount) ? 'badge-submitted' : 'badge-assigned';
  const dateStr = t.created_at ? new Date(t.created_at).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : '';

  return `
  <div class="task-card fade-up">
    <div class="task-accent" style="background:${accent}"></div>
    <div class="task-status-row">
      <span class="badge ${statusClass}">${statusLabel}</span>
      <span style="font-size:0.7rem;color:var(--text-muted)">${dateStr}${t.deadline ? ` · ${dueLabel}` : ''}</span>
    </div>
    <h4>${t.title}</h4>
    <p class="task-desc">${t.description}</p>

    <!-- Progress Summary Row -->
    <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:0.5rem; margin:1rem 0; background:var(--off-white); border-radius:12px; padding:0.75rem;">
      <div style="text-align:center;">
        <p style="font-size:0.55rem; text-transform:uppercase; color:var(--text-muted); font-weight:800; margin-bottom:0.2rem;">Assigned</p>
        <p style="font-weight:800; font-size:0.85rem; color:var(--primary);">${assignedCount}</p>
      </div>
      <div style="text-align:center; border-left:1px solid var(--glass-border);">
        <p style="font-size:0.55rem; text-transform:uppercase; color:var(--text-muted); font-weight:800; margin-bottom:0.2rem;">Submitted</p>
        <p style="font-weight:800; font-size:0.85rem; color:var(--warning);">${submittedCount}</p>
      </div>
      <div style="text-align:center; border-left:1px solid var(--glass-border);">
        <p style="font-size:0.55rem; text-transform:uppercase; color:var(--text-muted); font-weight:800; margin-bottom:0.2rem;">Graded</p>
        <p style="font-weight:800; font-size:0.85rem; color:var(--success);">${gradedCount}</p>
      </div>
      <div style="text-align:center; border-left:1px solid var(--glass-border);">
        <p style="font-size:0.55rem; text-transform:uppercase; color:var(--text-muted); font-weight:800; margin-bottom:0.2rem;">Rejected</p>
        <p style="font-weight:800; font-size:0.85rem; color:var(--danger);">${t.rejected_count || 0}</p>
      </div>
    </div>

    <div class="task-footer">
      <div style="display:flex;align-items:center;gap:0.6rem;">
        <span style="font-size:0.75rem;font-weight:600;color:var(--text-light)">Interns: ${assignedCount}</span>
      </div>
      <div style="display:flex;gap:0.4rem;">
        <button class="btn btn-sm ${submittedCount > 0 ? 'btn-success' : 'btn-secondary'}" onclick="viewSubmissions('${t._id}','${t.title.replace(/'/g,"\\\\'")}')" title="View Submissions">
          ${submittedCount > 0 ? 'Submissions' : 'Details'}
        </button>
        <button class="btn btn-sm" style="background:rgba(79, 70, 229, 0.1); color:var(--primary); border:none;" onclick="openEditTaskModal('${t._id}')" title="Edit Task">
          Edit
        </button>
        <button class="btn btn-sm" style="background:rgba(239, 68, 68, 0.1); color:var(--danger); border:none;" onclick="deleteTask('${t._id}')" title="Delete Task">
          Delete
        </button>
      </div>
    </div>
  </div>`;
}

// ─── Grade Modal Opener ───────────────────────────────────────
function openGradeModal(taskId, email, currentMarks = '', currentFeedback = '') {
  document.getElementById('gradeTaskId').value = taskId;
  document.getElementById('gradeEmail').value = email || '';
  document.getElementById('gradeMarks').value = currentMarks;
  document.getElementById('gradeFeedback').value = currentFeedback;
  openModal('gradeModal');
}

// ─── Reject Modal Opener ──────────────────────────────────────
function openRejectModal(taskId, email, currentFeedback = '') {
  document.getElementById('rejectTaskId').value = taskId;
  document.getElementById('rejectEmail').value = email || '';
  document.getElementById('rejectFeedback').value = currentFeedback;
  openModal('rejectModal');
}

// ─── Task Edit & Delete ───────────────────────────────────────
async function deleteTask(taskId) {
  if (!confirm('Are you sure you want to delete this task? All associated submissions will also be purged.')) return;
  try {
    const res = await api(`/api/tasks/delete/${taskId}`, 'DELETE');
    if (res) {
      showToast('Task purged successfully', 'success');
      switchSection('tasks');
    }
  } catch (e) {
    showToast(e.message || 'Purge failed', 'error');
  }
}

async function openEditTaskModal(taskId) {
  // We can fetch from the list or re-fetch from API
  // For safety, let's fetch the list again or find in existing tasks if available
  // But usually we just fetch the list on section switch. 
  // Let's assume we can find it in the global state if we had one, 
  // but since we don't, we can just re-fetch the list and find it.
  const tasks = await api('/api/tasks/list');
  const task = tasks.find(t => t._id === taskId);
  if (!task) return;

  document.getElementById('taskId').value = task._id;
  document.getElementById('taskTitle').value = task.title;
  document.getElementById('taskDesc').value = task.description;
  document.getElementById('taskDeadline').value = task.deadline || '';
  document.getElementById('taskAssignMode').value = task.assigned_to && task.assigned_to.length > 0 ? 'specific' : 'all';
  
  if (task.assigned_to && task.assigned_to.length > 0) {
    document.getElementById('internSelectGroup').style.display = 'block';
    // We need to wait for the interns to be loaded if they aren't.
    // Usually they are loaded when modal opens or on demand.
    await loadInternCheckboxes(); 
    document.querySelectorAll('.intern-cb').forEach(cb => {
      cb.checked = task.assigned_to.includes(cb.value);
    });
  } else {
    document.getElementById('internSelectGroup').style.display = 'none';
  }

  document.getElementById('taskModalTitle').innerText = 'Edit Assignment';
  document.getElementById('taskSubmitBtn').innerText = '💾 Update Task';
  openModal('taskModal');
}

// Helper to reset task modal for new deployment
function openNewTaskModal() {
  document.getElementById('taskId').value = '';
  document.getElementById('taskForm').reset();
  document.getElementById('internSelectGroup').style.display = 'none';
  document.getElementById('taskModalTitle').innerText = 'Deploy New Assignment';
  document.getElementById('taskSubmitBtn').innerText = '🚀 Deploy Task';
  openModal('taskModal');
}

// ─── View Submissions Modal ───────────────────────────────────
async function viewSubmissions(taskId, title) {
  const subs = await api(`/api/tasks/submissions/${taskId}`);
  if (!subs) return;

  const el = document.createElement('div');
  el.className = 'modal-overlay active';
  el.style.display = 'flex';
  el.id = 'viewSubsModal';
  el.innerHTML = `
    <div class="modal-box modal-wide" style="max-height:85vh; display:flex; flex-direction:column;">
      <div class="modal-header">
        <div>
          <h2 style="font-size:1.4rem; margin-bottom:0.2rem;">Submission Pipeline</h2>
          <p style="color:var(--text-light); font-weight:500;">Task: ${title}</p>
        </div>
        <button class="modal-close" onclick="document.getElementById('viewSubsModal').remove()">✕</button>
      </div>
      
      <div style="flex:1; overflow-y:auto; padding-right:0.5rem; margin-top:0.5rem;">
        ${subs.length === 0 ? `
          <div class="empty-state" style="padding:4rem 0;">
            <div class="empty-icon" style="font-size:3rem; margin-bottom:1rem;">Empty</div>
            <h3>No Submissions Found</h3>
            <p>Wait for interns to push their deliverables to the terminal.</p>
          </div>
        ` : subs.map(s => {
          const isRejected = s.status === 'rejected';
          const isGraded = s.status === 'graded';
          
          let statusBadge = '<span class="badge badge-submitted">PENDING REVIEW</span>';
          let borderStyle = '1px solid var(--glass-border)';
          let bgStyle = 'var(--glass-bg)';
          
          if (isGraded) {
            statusBadge = '<span class="badge badge-graded">ASSESSMENT COMPLETE</span>';
            borderStyle = '1px solid #bbf7d0';
            bgStyle = '#f0fdf4';
          } else if (isRejected) {
            statusBadge = '<span class="badge badge-inactive">REJECTED / RESUBMIT</span>';
            borderStyle = '1px solid #fecaca';
            bgStyle = '#fef2f2';
          }

          return `
          <div class="glass-panel" style="background:${bgStyle}; border:${borderStyle}; padding:1.5rem; margin-bottom:1.2rem; border-radius:18px;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:1rem; gap:1rem;">
              <div style="display:flex; align-items:center; gap:1rem;">
                <div style="width:44px; height:44px; background:var(--accent-gradient); border-radius:12px; display:flex; align-items:center; justify-content:center; color:white; font-weight:800; font-size:1.1rem; flex-shrink:0;">
                  ${(s.student_name || s.student_id || 'I').charAt(0).toUpperCase()}
                </div>
                <div>
                  <h4 style="font-size:1rem; font-weight:800; color:var(--text-main); line-height:1.2;">${s.student_name || 'Anonymous Intern'}</h4>
                  <p style="font-size:0.75rem; color:var(--text-muted); font-weight:600;">${s.student_id || s.intern_email}</p>
                </div>
              </div>
              ${statusBadge}
            </div>

            <div style="background:rgba(15, 23, 42, 0.03); border-radius:12px; padding:1rem; margin-bottom:1.2rem;">
              <label style="display:block; font-size:0.65rem; font-weight:800; text-transform:uppercase; color:var(--text-muted); margin-bottom:0.5rem; letter-spacing:0.05em;">DELIVERABLE LINK</label>
              ${s.github_url ? `
                <a href="${s.github_url}" target="_blank" style="display:flex; align-items:center; gap:0.5rem; font-size:0.85rem; color:var(--primary); font-weight:700; text-decoration:none;">
                  Folder: ${s.github_url}
                </a>
              ` : '<p style="font-size:0.85rem; color:var(--text-light); font-style:italic;">No link provided</p>'}
              <p style="font-size:0.65rem; color:var(--text-muted); margin-top:0.8rem; font-weight:500;">Submitted: ${new Date(s.submitted_at).toLocaleString('en-IN')}</p>
            </div>

            ${(isGraded || isRejected) ? `
              <div class="grade-result-box" style="margin:0; background:rgba(255,255,255,0.45); border-color:${isRejected ? '#fca5a5' : '#86efac'}">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                   <span style="font-size:0.7rem; font-weight:900; color:${isRejected ? '#991b1b' : '#166534'}; text-transform:uppercase; letter-spacing:0.05em;">
                     ${isRejected ? 'REJECTION FEEDBACK' : 'SCORE ACHIEVED'}
                   </span>
                   ${isGraded ? `<span class="grade-score" style="font-size:1.2rem;">${s.marks}<span style="font-size:0.75rem; color:var(--text-light); font-weight:500;">/100</span></span>` : ''}
                </div>
                <p class="grade-feedback" style="margin:0; font-size:0.82rem; line-height:1.6; color:${isRejected ? '#991b1b' : '#166534'}">
                  "${s.feedback || 'No feedback provided.'}"
                </p>
              </div>
            ` : ''}
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.75rem; margin-top:1.2rem;">
              <button class="btn btn-success" onclick="openGradeModal('${taskId}','${s.intern_email || s.student_id}', '${s.marks || ''}', '${(s.feedback || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;')}')">
                ${isGraded ? 'Update Grade' : 'Approve'}
              </button>
              <button class="btn btn-danger" onclick="openRejectModal('${taskId}','${s.intern_email || s.student_id}', '${(s.feedback || '').replace(/'/g, "\\\\'").replace(/"/g, '&quot;')}')">
                ${isRejected ? 'Update Feedback' : 'Reject'}
              </button>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>`;
  document.body.appendChild(el);
  el.onclick = e => { if (e.target === el) el.remove(); };
}

// ─── Label Modal ─────────────────────────────────────────────
function openLabelModal(userId, label, progress) {
  document.getElementById('labelUserId').value = userId;
  document.getElementById('labelValue').value = label || 'Needs Evaluation';
  document.getElementById('labelProgress').value = progress || 0;
  openModal('labelModal');
}

// ─── Toggle Intern Active Status ─────────────────────────────
async function toggleInternStatus(userId, currentStatus) {
  const action = currentStatus ? 'DEACTIVATE' : 'ACTIVATE';
  if (!confirm(`${action} this intern account? ${currentStatus ? 'They will be barred from portal access.' : ''}`)) return;

  const res = await api(`/api/performance/toggle-active/${userId}`, 'PATCH');
  if (res) {
    showToast(res.message, res.is_active ? 'success' : 'info');
    switchSection(getActiveSection());
  }
}
