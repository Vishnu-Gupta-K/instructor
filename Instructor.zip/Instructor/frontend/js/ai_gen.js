/**
 * AI Question Generation UI Logic
 */

function openAIModal() {
    // Create the modal if it doesn't exist
    if (!document.getElementById('aiGenModal')) {
        injectAIModalHTML();
    }
    openModal('aiGenModal');
}

function injectAIModalHTML() {
    const modal = document.createElement('div');
    modal.id = 'aiGenModal';
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-box" style="max-width: 500px; background: #0f172a; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 50px 100px -20px rgba(0,0,0,0.5);">
            <div class="modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 1.5rem;">
                <div>
                    <h2 style="color: #fff; font-weight: 800; letter-spacing: -0.02em;">✨ AI Question Architect</h2>
                    <p style="color: #94a3b8; font-size: 0.85rem;">Harness state-of-the-art LLMs to expand your library.</p>
                </div>
                <button class="modal-close" onclick="closeModal('aiGenModal')" style="color: #94a3b8;">✕</button>
            </div>
            <div style="padding: 2rem;">
                <div class="form-group">
                    <label style="color: #6366f1; font-weight: 700; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.5rem; display: block;">Topic / Concept</label>
                    <input type="text" id="aiTopic" placeholder="e.g. Dynamic Programming, SQL Joins" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 0.8rem; border-radius: 8px; width: 100%; outline: none;" required>
                </div>
                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1.5rem;">
                    <div class="form-group">
                        <label style="color: #6366f1; font-weight: 700; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.5rem; display: block;">Difficulty</label>
                        <select id="aiDifficulty" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 0.8rem; border-radius: 8px; width: 100%; outline: none;">
                            <option value="Easy">Beginner</option>
                            <option value="Medium" selected>Intermediate</option>
                            <option value="Hard">Expert</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="color: #6366f1; font-weight: 700; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.5rem; display: block;">Target Exam</label>
                        <select id="aiExamSelect" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 0.8rem; border-radius: 8px; width: 100%; outline: none;">
                            <option value="">-- Select Destination --</option>
                        </select>
                    </div>
                </div>
                <div id="aiPreview" style="margin-top: 2rem; display: none; animation: slideDown 0.4s ease;">
                    <div style="background: rgba(99, 102, 241, 0.05); padding: 1.2rem; border-radius: 12px; border: 1px solid rgba(99, 102, 241, 0.2);">
                        <div style="display:flex; justify-content:space-between; margin-bottom: 0.5rem;">
                            <span style="color: #6366f1; font-size: 0.65rem; font-weight: 800; text-transform: uppercase;">Generated Challenge</span>
                            <span id="aiPreviewDiff" style="font-size: 0.65rem; padding: 2px 8px; border-radius: 4px; background: rgba(16, 185, 129, 0.2); color: #10b981;">Easy</span>
                        </div>
                        <h4 id="aiPreviewTitle" style="color: #fff; font-weight: 700; margin-bottom: 0.5rem;"></h4>
                        <p id="aiPreviewDesc" style="font-size: 0.8rem; color: #94a3b8; line-height: 1.5;"></p>
                    </div>
                </div>
                <div class="modal-footer" style="margin-top: 2.5rem; display: flex; gap: 1rem;">
                    <button class="btn" id="aiGenBtn" onclick="generateAIQuestion()" style="flex: 2; background: var(--accent-gradient); border: none; padding: 1rem; border-radius: 10px; color: #fff; font-weight: 700; box-shadow: 0 10px 20px -10px rgba(99, 102, 241, 0.5);">🚀 Generate Architectures</button>
                    <button class="btn btn-secondary" onclick="closeModal('aiGenModal')" style="flex: 1; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #94a3b8;">Cancel</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    populateExamSelect();
}

async function populateExamSelect() {
    const exams = await api('/api/exams/list');
    const select = document.getElementById('aiExamSelect');
    if (exams) {
        exams.forEach(e => {
            const opt = document.createElement('option');
            opt.value = e._id;
            opt.textContent = e.title;
            select.appendChild(opt);
        });
    }
}

async function generateAIQuestion() {
    const btn = document.getElementById('aiGenBtn');
    const topic = document.getElementById('aiTopic').value;
    const difficulty = document.getElementById('aiDifficulty').value;
    
    if (!topic) return showToast('Please specify a topic', 'error');

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-sm" style="margin-right: 8px;"></span> Engineering Logic...';

    try {
        const res = await api('/api/ai-generator/generate-question', 'POST', { topic, difficulty, count: 1 });
        if (res && res.success) {
            window._lastGeneratedQuestion = res.questions[0];
            const q = window._lastGeneratedQuestion;
            
            document.getElementById('aiPreview').style.display = 'block';
            document.getElementById('aiPreviewTitle').textContent = q.title;
            document.getElementById('aiPreviewDesc').textContent = q.description;
            document.getElementById('aiPreviewDiff').textContent = q.difficulty;
            
            btn.innerHTML = '✨ Commit to Exam';
            btn.style.background = '#10b981';
            btn.onclick = () => addAIQuestionToLibrary();
            showToast('AI Generation Complete', 'success');
        }
    } catch (err) {
        showToast('Processing Link Failure', 'error');
        btn.innerHTML = '🚀 Generate Architectures';
        btn.disabled = false;
    }
}

async function addAIQuestionToLibrary() {
    const examId = document.getElementById('aiExamSelect').value;
    if (!examId) return showToast('Please select a destination exam', 'error');
    if (!window._lastGeneratedQuestion) return;

    const btn = document.getElementById('aiGenBtn');
    btn.disabled = true;
    btn.textContent = '📦 Synchronizing...';

    try {
        // 1. Fetch current questions of that exam
        const exams = await api('/api/exams/list');
        const target = exams.find(e => e._id === examId);
        const questions = target.questions || [];
        
        // 2. Append new question
        questions.push(window._lastGeneratedQuestion);
        
        // 3. Save back
        await api(`/api/exams/${examId}/questions`, 'PATCH', questions);
        
        showToast('Question synchronized to library!', 'success');
        closeModal('aiGenModal');
        // Refresh the section if we are in exams
        if (typeof renderExams === 'function') {
            const main = document.getElementById('mainContent');
            if (main) renderExams(main);
        }
    } catch (err) {
        showToast('Sync failure', 'error');
        btn.disabled = false;
        btn.textContent = '✨ Commit to Exam';
    }
}
