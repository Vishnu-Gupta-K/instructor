/**
 * AI Code Review - Instructor View
 * Renders the AI analysis reports within the Instructor dashboard.
 */

class AIReviewPanel {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
    }

    async fetchAndRender(submissionId) {
        try {
            this.container.innerHTML = `<div class="spinner" style="margin:2rem auto"></div><p style="text-align:center; color:var(--text-muted)">Fetching AI Analysis...</p>`;
            
            // The dashboard api() returns null on 404 or other errors
            const data = await api(`/api/ai/report/${submissionId}`);
            
            if (!data) {
                // If data is null, it means the API returned a non-200 (likely 404)
                this.container.innerHTML = `
                    <div class="empty-state" style="padding: 2rem;">
                        <div class="empty-icon">📂</div>
                        <h3>No AI Analysis Found</h3>
                        <p style="max-width: 400px; margin: 0.5rem auto;">The AI Review for this submission is either still processing or does not exist (for older submissions).</p>
                        <button class="btn btn-sm btn-secondary" style="margin-top: 1rem;" onclick="aiPanel.fetchAndRender('${submissionId}')">🔄 Refresh Registry</button>
                    </div>`;
                return;
            }
            
            this.renderPanel(data);
        } catch (error) {
            console.error("AI Review Fetch Failure:", error);
            this.container.innerHTML = `<p style="color:var(--danger); text-align:center; padding:2rem;">Unable to connect to AI Service: ${error.message}</p>`;
        }
    }

    renderPanel(data) {
        const html = `
            <div class="ai-premium-card" style="margin-top:1.5rem; animation: slideIn 0.5s cubic-bezier(0.16, 1, 0.3, 1);">
                <!-- Header with Overall Score -->
                <div class="ai-card-header">
                    <div style="display:flex; align-items:center; gap:0.75rem;">
                        <span class="ai-spark-icon">✨</span>
                        <div>
                            <h3 style="margin:0; font-weight:800; letter-spacing:-0.01em;">AI Code Insights</h3>
                            <p style="margin:0; font-size:0.7rem; color:rgba(255,255,255,0.5); text-transform:uppercase; letter-spacing:0.05em;">Principal Reviewer Engine v4.0</p>
                        </div>
                    </div>
                    <div class="ai-score-ring">
                        <span class="score-val">${data.metrics.overall_score}%</span>
                        <span class="score-label">OVERALL</span>
                    </div>
                </div>
                
                <!-- Metrics Grid -->
                <div class="ai-metrics-grid">
                    ${this.createMetricCard('Correctness', data.metrics.correctness, '#10b981')}
                    ${this.createMetricCard('Efficiency', data.metrics.efficiency, '#6366f1')}
                    ${this.createMetricCard('Maintainability', data.metrics.maintainability, '#f59e0b')}
                    ${this.createMetricCard('Quality', data.metrics.code_quality, '#ec4899')}
                </div>

                <!-- Analysis Layout -->
                <div class="ai-analysis-split">
                    <!-- Left: Complexity & Risks -->
                    <div class="analysis-column">
                        <div class="analysis-section">
                            <h4><i class="icon">📊</i> Complexity Analysis</h4>
                            <div style="display:flex; gap:0.5rem; margin-bottom:1rem;">
                                <span class="ai-badge-outline">Time: ${data.complexity.time_complexity}</span>
                                <span class="ai-badge-outline">Space: ${data.complexity.space_complexity}</span>
                            </div>
                            <p class="ai-text-small">${data.complexity.reasoning}</p>
                        </div>
                        
                        ${data.bugs_and_risks && data.bugs_and_risks.length > 0 ? `
                        <div class="analysis-section" style="border-top:1px solid rgba(255,255,255,0.05); padding-top:1.5rem;">
                            <h4 style="color:#f87171;"><i class="icon">⚠️</i> Risks & Potential Bugs</h4>
                            <ul class="ai-list">
                                ${data.bugs_and_risks.map(risk => `<li>${risk}</li>`).join('')}
                            </ul>
                        </div>` : ''}
                    </div>

                    <!-- Right: Optimizations -->
                    <div class="analysis-column">
                        <div class="analysis-section">
                            <h4 style="color:#6366f1;"><i class="icon">🚀</i> Recommended Optimizations</h4>
                            <div class="ai-opt-list">
                                ${data.optimizations.map(opt => `
                                    <div class="ai-opt-item">
                                        <p class="opt-title">${opt.issue}</p>
                                        <p class="opt-desc">${opt.suggestion}</p>
                                        ${opt.code_snippet ? `<pre class="opt-code"><code>${opt.code_snippet}</code></pre>` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer Feedback -->
                <div class="ai-feedback-footer">
                    <div class="feedback-box instructor">
                        <span class="label">INSTRUCTOR SUMMARY</span>
                        <p>"${data.instructor_summary}"</p>
                    </div>
                    <div class="feedback-box intern">
                        <span class="label">INTERN FEEDBACK</span>
                        <p>"${data.intern_feedback}"</p>
                    </div>
                </div>
            </div>
        `;
        
        this.container.innerHTML = html;
        this.injectStyles();
    }

    createMetricCard(label, val, color) {
        return `
            <div class="ai-metric-card">
                <div class="metric-progress" style="--val:${val}%; --color:${color}"></div>
                <div class="metric-info">
                    <span class="m-val">${val}%</span>
                    <span class="m-label">${label}</span>
                </div>
            </div>
        `;
    }

    injectStyles() {
        if (document.getElementById('ai-panel-premium-styles')) return;
        const style = document.createElement('style');
        style.id = 'ai-panel-premium-styles';
        style.innerHTML = `
            .ai-premium-card {
                background: #0f172a;
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 20px;
                padding: 2rem;
                color: #f1f5f9;
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
                font-family: 'Inter', system-ui, sans-serif;
            }
            .ai-card-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 2.5rem;
            }
            .ai-spark-icon { font-size: 1.5rem; background: var(--accent-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
            .ai-score-ring { text-align: right; }
            .score-val { display: block; font-size: 2.2rem; font-weight: 900; line-height: 1; color: #fff; }
            .score-label { font-size: 0.65rem; font-weight: 700; color: #6366f1; letter-spacing: 0.1em; }

            .ai-metrics-grid {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 1rem;
                margin-bottom: 2.5rem;
            }
            .ai-metric-card {
                background: rgba(255,255,255,0.03);
                border: 1px solid rgba(255,255,255,0.05);
                border-radius: 12px;
                padding: 1.2rem;
                display: flex;
                align-items: center;
                gap: 1rem;
            }
            .metric-progress {
                width: 4px; height: 32px;
                background: rgba(255,255,255,0.1);
                position: relative;
                border-radius: 2px;
            }
            .metric-progress::after {
                content: ''; position: absolute; bottom: 0; left: 0; width: 100%; height: var(--val);
                background: var(--color); border-radius: 2px;
                box-shadow: 0 0 10px var(--color);
            }
            .metric-info { display: flex; flex-direction: column; }
            .m-val { font-size: 1.1rem; font-weight: 700; color: #fff; }
            .m-label { font-size: 0.6rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; }

            .ai-analysis-split { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2.5rem; }
            .analysis-section h4 { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; color: #94a3b8; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem; }
            .ai-badge-outline { padding: 4px 10px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.1); font-size: 0.75rem; font-weight: 600; color: #6366f1; }
            .ai-text-small { font-size: 0.85rem; color: #94a3b8; line-height: 1.6; }
            
            .ai-list { padding-left: 1.2rem; margin: 0; }
            .ai-list li { font-size: 0.85rem; color: #fca5a5; margin-bottom: 0.5rem; }

            .ai-opt-item { background: rgba(0,0,0,0.2); border-radius: 10px; padding: 1.2rem; border-left: 4px solid #6366f1; margin-bottom: 0.75rem; }
            .opt-title { font-weight: 700; font-size: 0.9rem; margin-bottom: 0.4rem; color: #fff; }
            .opt-desc { font-size: 0.8rem; color: #94a3b8; line-height: 1.4; margin-bottom: 0.8rem; }
            .opt-code { background: #000; padding: 0.8rem; border-radius: 6px; font-size: 0.75rem; color: #10b981; overflow-x: auto; border: 1px solid rgba(255,255,255,0.05); }

            .ai-feedback-footer { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
            .feedback-box { padding: 1.5rem; border-radius: 12px; position: relative; overflow: hidden; }
            .feedback-box.instructor { background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.2); }
            .feedback-box.intern { background: rgba(16, 185, 129, 0.05); border: 1px solid rgba(16, 185, 129, 0.1); }
            .feedback-box .label { font-size: 0.6rem; font-weight: 800; color: rgba(255,255,255,0.4); text-transform: uppercase; margin-bottom: 0.5rem; display: block; }
            .feedback-box p { font-size: 0.85rem; font-style: italic; color: #cbd5e1; margin: 0; line-height: 1.5; }

            @keyframes slideIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        `;
        document.head.appendChild(style);
    }
}

window.AIReviewPanel = AIReviewPanel;
