from __future__ import annotations

from dataclasses import dataclass
from email.message import EmailMessage
from html import escape
import logging

import aiosmtplib

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class MailDispatchResult:
    sent: bool
    reason: str


def smtp_configured() -> bool:
    return bool(settings.SMTP_HOST and settings.SMTP_USER and settings.SMTP_PASSWORD)


def _mail_security_flags() -> tuple[bool, bool]:
    use_tls = bool(settings.SMTP_USE_TLS or settings.SMTP_PORT == 465)
    start_tls = bool((settings.SMTP_STARTTLS or settings.SMTP_PORT == 587) and not use_tls)
    return use_tls, start_tls


async def send_mail(
    *,
    subject: str,
    recipient: str,
    text_body: str,
    html_body: str | None = None,
) -> MailDispatchResult:
    if not smtp_configured():
        return MailDispatchResult(sent=False, reason="smtp-not-configured")

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = settings.MAIL_FROM
    message["To"] = recipient
    message.set_content(text_body)
    if html_body:
        message.add_alternative(html_body, subtype="html")

    use_tls, start_tls = _mail_security_flags()

    try:
        await aiosmtplib.send(
            message,
            hostname=settings.SMTP_HOST,
            port=settings.SMTP_PORT,
            username=settings.SMTP_USER,
            password=settings.SMTP_PASSWORD,
            use_tls=use_tls,
            start_tls=start_tls,
            timeout=settings.SMTP_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        logger.warning("SMTP dispatch failed for %s: %s", recipient, exc)
        return MailDispatchResult(sent=False, reason=f"smtp-error:{type(exc).__name__}")

    return MailDispatchResult(sent=True, reason="sent")


def build_otp_email_payload(
    *,
    otp_code: str,
    expires_minutes: int,
    purpose: str,
    recipient_name: str | None = None,
) -> dict[str, str]:
    brand_name = settings.MAIL_BRAND_NAME or settings.PROJECT_NAME
    safe_name = escape(recipient_name or "SPX User")
    safe_purpose = escape(purpose)
    safe_otp = escape(otp_code)

    subject = f"{brand_name} verification code"
    text_body = (
        f"Hello {recipient_name or 'SPX User'},\n\n"
        f"Your verification code for {purpose} is: {otp_code}\n"
        f"This code expires in {expires_minutes} minutes.\n\n"
        "If you did not request this action, you can ignore this email."
    )

    html_body = f"""
<!doctype html>
<html lang=\"en\">
  <body style=\"margin:0;padding:0;background:#f1f5f9;font-family:Arial,sans-serif;color:#0f172a;\">
    <div style=\"max-width:560px;margin:24px auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden;\">
      <div style=\"background:linear-gradient(135deg,#0f172a,#1d4ed8);padding:18px 22px;color:#ffffff;\">
        <div style=\"font-size:12px;letter-spacing:0.12em;text-transform:uppercase;opacity:0.88;\">SPX Secure Mail</div>
        <h1 style=\"margin:6px 0 0 0;font-size:22px;line-height:1.2;\">{escape(brand_name)}</h1>
      </div>
      <div style=\"padding:22px;\">
        <p style=\"margin:0 0 12px 0;font-size:15px;line-height:1.6;\">Hello {safe_name},</p>
        <p style=\"margin:0 0 14px 0;font-size:15px;line-height:1.6;\">Use this verification code for <strong>{safe_purpose}</strong>.</p>
        <div style=\"margin:14px 0 16px 0;padding:14px;border:1px dashed #cbd5e1;border-radius:12px;text-align:center;background:#f8fafc;\">
          <div style=\"font-size:12px;color:#64748b;letter-spacing:0.08em;text-transform:uppercase;\">One-Time Code</div>
          <div style=\"font-size:34px;letter-spacing:0.25em;font-weight:800;color:#1d4ed8;margin-top:6px;\">{safe_otp}</div>
          <div style=\"font-size:12px;color:#475569;margin-top:8px;\">Expires in {expires_minutes} minutes</div>
        </div>
        <p style=\"margin:0;font-size:13px;color:#475569;line-height:1.5;\">If this was not requested by you, ignore this message and secure your account credentials.</p>
      </div>
    </div>
  </body>
</html>
""".strip()

    return {
        "subject": subject,
        "text": text_body,
        "html": html_body,
    }


def build_welcome_email_payload(
    *,
    full_name: str,
    role_label: str,
    account_details: dict[str, str | None] | None = None,
) -> dict[str, str]:
    brand_name = settings.MAIL_BRAND_NAME or settings.PROJECT_NAME
    safe_name = escape(full_name or "SPX User")
    safe_role = escape(role_label)

    detail_items: list[tuple[str, str]] = []
    if account_details:
        for label, value in account_details.items():
            if value is None:
                continue
            value_text = str(value).strip()
            if not value_text:
                continue
            detail_items.append((label, value_text))

    detail_lines = ""
    detail_block = ""
    if detail_items:
        detail_lines = "\n\nProvisioned account details:\n" + "\n".join(
            f"{label}: {value}" for label, value in detail_items
        )
        detail_block = """
        <div style="margin:14px 0 16px 0;padding:14px;border:1px solid #cbd5e1;border-radius:12px;background:#f8fafc;">
          <div style="font-size:12px;color:#64748b;letter-spacing:0.08em;text-transform:uppercase;font-weight:800;margin-bottom:10px;">Provisioned Details</div>
          <div style="display:flex;flex-direction:column;gap:8px;">
            {rows}
          </div>
        </div>
        """.strip().format(
            rows="".join(
                "<div style='display:flex;justify-content:space-between;gap:1rem;padding:0.35rem 0;border-bottom:1px solid #e2e8f0;'>"
                f"<span style='font-size:12px;color:#475569;font-weight:700;'>{escape(label)}</span>"
                f"<span style='font-size:13px;color:#0f172a;font-weight:700;text-align:right;'>{escape(value)}</span>"
                "</div>"
                for label, value in detail_items
            )
        )

    subject = f"Welcome to {brand_name}"
    text_body = (
        f"Hello {full_name or 'SPX User'},\n\n"
        f"Your {role_label} access has been successfully provisioned in {brand_name}.\n"
        "You can now sign in using your registered email and password.\n\n"
        f"{detail_lines}\n"
        "Regards,\nSPX Security Automation"
    )

    html_body = f"""
<!doctype html>
<html lang=\"en\">
  <body style=\"margin:0;padding:0;background:#f1f5f9;font-family:Arial,sans-serif;color:#0f172a;\">
    <div style=\"max-width:560px;margin:24px auto;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;overflow:hidden;\">
      <div style=\"background:linear-gradient(135deg,#0f172a,#1d4ed8);padding:18px 22px;color:#ffffff;\">
        <div style=\"font-size:12px;letter-spacing:0.12em;text-transform:uppercase;opacity:0.88;\">SPX Provisioning</div>
        <h1 style=\"margin:6px 0 0 0;font-size:22px;line-height:1.2;\">Welcome to {escape(brand_name)}</h1>
      </div>
      <div style=\"padding:22px;\">
        <p style=\"margin:0 0 12px 0;font-size:15px;line-height:1.6;\">Hello {safe_name},</p>
        <p style=\"margin:0 0 14px 0;font-size:15px;line-height:1.6;\">Your <strong>{safe_role}</strong> account is active and ready.</p>
        <div style=\"padding:12px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc;font-size:14px;color:#1e293b;\">
          Sign in with your registered institutional email to access the portal features.
        </div>
        {detail_block}
      </div>
    </div>
  </body>
</html>
""".strip()

    return {
        "subject": subject,
        "text": text_body,
        "html": html_body,
    }
