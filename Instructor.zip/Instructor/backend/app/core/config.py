from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    PROJECT_NAME: str = "SPX Instructor Portal"
    SECRET_KEY: str = "your-super-secret-key-for-jwt"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    MONGO_URI: str = "mongodb://localhost:27017" # Fallback
    DATABASE_NAME: str = "spx_dashboard"

    # SMTP Configuration for Identity Recovery
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    MAIL_FROM: str = "SPX Central Command <no-reply@spx.system>"
    MAIL_BRAND_NAME: str = "SPX Faculty Command Center"
    MAIL_DEBUG_MODE: bool = True
    SMTP_TIMEOUT_SECONDS: int = 15
    SMTP_USE_TLS: bool = False
    SMTP_STARTTLS: bool = True
    OTP_EXPIRE_MINUTES: int = 5
    RESET_TOKEN_EXPIRE_MINUTES: int = 15

    model_config = SettingsConfigDict(env_file=".env")

settings = Settings()

from datetime import datetime, timezone, timedelta
IST = timezone(timedelta(hours=5, minutes=30))

def get_ist_time():
    """Returns the current precise time in IST (+05:30) for unified global telemetry."""
    return datetime.now(IST)
