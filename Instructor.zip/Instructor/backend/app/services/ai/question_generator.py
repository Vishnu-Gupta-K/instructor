import random
import os
import json
import google.generativeai as genai
from typing import List, Dict, Any
from app.core.config import settings

class AIQuestionGenerator:
    def __init__(self):
        self.api_key = settings.GOOGLE_API_KEY
        if self.api_key:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel('gemini-2.5-flash')
        else:
            self.model = None

    async def generate_questions(self, topic: str, difficulty: str, count: int = 1) -> List[Dict[str, Any]]:
        """
        Generates programming questions using Gemini 1.5 Flash.
        """
        if not self.model:
            # Fallback to local template engine if no API key
            questions = []
            for _ in range(count):
                questions.append(self._generate_single_question(topic, difficulty))
            return questions

        try:
            prompt = f"""
            Generate {count} professional coding questions about '{topic}' with {difficulty} difficulty.
            Output ONLY a JSON list of objects matching this schema:
            {{
              "title": "...",
              "type": "coding",
              "language": "python",
              "description": "...",
              "points": 20,
              "boilerplate": "...",
              "test_cases": [{{"input": "...", "expected": "..."}}],
              "difficulty": "{difficulty}",
              "tags": ["{topic}", "AI-Generated"]
            }}
            """
            
            response = await self.model.generate_content_async(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    response_mime_type="application/json"
                )
            )
            
            # Robust JSON extraction
            content = response.text.strip()
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                content = content.split("```")[1].split("```")[0].strip()
                
            return json.loads(content)
            
        except Exception as e:
            print(f"[AI Gen Error] Gemini failed: {str(e)}")
            return [self._generate_single_question(topic, difficulty)]

    def _generate_single_question(self, topic: str, difficulty: str) -> Dict[str, Any]:
        # Intelligent Templates for more realistic generation
        templates = {
            "Arrays": [
                {"title": "Find the Missing Element", "desc": "Given an array of size N-1 containing distinct integers in range [1, N], find the missing number."},
                {"title": "Rotate Array", "desc": "Rotate an array of N elements to the right by K steps."},
                {"title": "Subarray with Given Sum", "desc": "Find a contiguous subarray which adds to a given number S."}
            ],
            "Strings": [
                {"title": "Valid Palindrome", "desc": "Determine if a string is a palindrome, considering only alphanumeric characters and ignoring cases."},
                {"title": "Longest Common Prefix", "desc": "Write a function to find the longest common prefix string amongst an array of strings."},
                {"title": "Anagram Detection", "desc": "Check if two strings are anagrams of each other."}
            ],
            "Dynamic Programming": [
                {"title": "Climbing Stairs", "desc": "You are climbing a staircase. It takes n steps to reach the top. Each time you can either take 1 or 2 steps. In how many distinct ways can you climb to the top?"},
                {"title": "Coin Change", "desc": "Given coins of different denominations and a total amount, find the fewest number of coins that you need to make up that amount."},
                {"title": "Longest Increasing Subsequence", "desc": "Find the length of the longest strictly increasing subsequence."}
            ]
        }

        # Select a template based on topic or fallback
        category = "Arrays"
        for cat in templates:
            if cat.lower() in topic.lower():
                category = cat
                break
        
        tpl = random.choice(templates.get(category, templates["Arrays"]))
        
        # Difficulty modifiers
        points = {"Easy": 10, "Medium": 25, "Hard": 50}.get(difficulty, 20)
        
        return {
            "title": f"[AI] {tpl['title']}",
            "type": "coding",
            "language": "python",
            "description": f"{tpl['desc']}\n\nConstraint: Use {topic} concepts. Focus on {difficulty} level complexity.",
            "points": points,
            "boilerplate": "def solve(data):\n    # TODO: Implement solution using " + topic + "\n    pass",
            "test_cases": [
                {"input": "sample_input", "expected": "sample_output"}
            ],
            "difficulty": difficulty,
            "tags": [topic, "AI-Generated", "Automated"]
        }
