from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from datetime import datetime
from typing import List, Optional
from app.core.database import get_db
from app.core.config import get_ist_time
from bson import ObjectId

router = APIRouter()


def parse_deadline_date(deadline: Optional[str]):
    if not deadline:
        return None
    try:
        return datetime.strptime(deadline, "%Y-%m-%d").date()
    except ValueError:
        return None


def get_task_deadline_state(task: dict) -> str:
    deadline_date = parse_deadline_date(task.get("deadline"))
    if not deadline_date:
        return "open"

    current_date = get_ist_time().date()
    if current_date > deadline_date:
        return "overdue"
    if current_date == deadline_date:
        return "due_today"
    return "open"

class TaskCreate(BaseModel):
    title: str
    description: str
    assigned_to: List[str]
    deadline: Optional[str] = None

class TaskGrade(BaseModel):
    task_id: str
    intern_email: str
    marks: Optional[int] = 0
    feedback: str
    action: str = "approve" # "approve" or "reject"

@router.post("/create")
async def create_task(task: TaskCreate, db = Depends(get_db)):
    task_dict = task.model_dump()
    task_dict["status"] = "assigned"
    task_dict["created_at"] = get_ist_time()
    task_dict["grades"] = {}  # Store per-intern grade: {email: {marks, feedback, graded_at}}
    result = await db["tasks"].insert_one(task_dict)
    return {"message": "Task created", "task_id": str(result.inserted_id)}

@router.get("/list", response_model=List[dict])
async def list_tasks(db = Depends(get_db)):
    cursor = db["tasks"].find().sort("created_at", -1)
    tasks = await cursor.to_list(length=100)
    for t in tasks:
        t["_id"] = str(t["_id"])
        # Attach submission count for each task
        sub_count = t.get("submission_count") or await db["submissions"].count_documents({"task_id": str(t["_id"])})
        t["submission_count"] = sub_count
        # Attach graded (approved) submission count
        graded_count = await db["submissions"].count_documents({"task_id": str(t["_id"]), "status": "graded"})
        t["graded_count"] = graded_count
        # Attach rejected submission count
        rejected_count = await db["submissions"].count_documents({"task_id": str(t["_id"]), "status": "rejected"})
        t["rejected_count"] = rejected_count
        t["deadline_state"] = get_task_deadline_state(t)
    return tasks

@router.get("/submissions/{task_id}", response_model=List[dict])
async def get_task_submissions(task_id: str, db = Depends(get_db)):
    """Fetch all submissions for a specific task. Used by instructor to review who submitted."""
    cursor = db["submissions"].find({"task_id": task_id}).sort("submitted_at", -1)
    subs = await cursor.to_list(length=500)
    for s in subs:
        s["_id"] = str(s["_id"])
    return subs

@router.get("/submissions", response_model=List[dict])
async def get_all_submissions(db = Depends(get_db)):
    """All pending (ungraded) submissions across all tasks."""
    cursor = db["submissions"].find({"graded": {"$ne": True}}).sort("submitted_at", -1)
    subs = await cursor.to_list(length=200)
    for s in subs:
        s["_id"] = str(s["_id"])
    return subs

@router.post("/grade")
async def grade_task(grade: TaskGrade, db = Depends(get_db)):
    """
    Grade a task submission. This writes to BOTH collections:
    1. 'tasks' collection — marks the task status as graded, stores grade data
    2. 'submissions' collection — updates the submission record so the intern can see their grade
    Both the Instructor Portal and Intern Portal share the same MongoDB database,
    so any write here is immediately visible to the student dashboard.
    """
    graded_at = get_ist_time()
    is_approve = grade.action == "approve"
    status = "graded" if is_approve else "rejected"

    # 1. Update the task record
    update_fields = {
        f"grades.{grade.intern_email.replace('.', '_')}": {
            "marks": grade.marks if is_approve else 0,
            "feedback": grade.feedback,
            "graded_at": graded_at,
            "status": status,
            "graded_by": "instructor"
        }
    }
    
    await db["tasks"].update_one(
        {"_id": ObjectId(grade.task_id)},
        {"$set": update_fields}
    )

    # 2. Update the submission record (BUG-13 FIX: match by intern_email only — NOT broken student_id regex)
    sub_update = {
        "graded": True,
        "marks": grade.marks if is_approve else 0,
        "feedback": grade.feedback,
        "graded_at": graded_at,
        "status": status
    }
    submission_cursor = db["submissions"].find({
        "task_id": grade.task_id,
        "intern_email": grade.intern_email,
    }).sort("submitted_at", -1).limit(1)
    submission_list = await submission_cursor.to_list(length=1)
    if submission_list:
        await db["submissions"].update_one(
            {"_id": submission_list[0]["_id"]},
            {"$set": sub_update}
        )

    msg = "Assessment complete. Grade synchronized." if is_approve else "Task rejected. Feedback sent to intern."
    return {"message": msg, "status": status}

@router.put("/update/{task_id}")
async def update_task(task_id: str, task: TaskCreate, db = Depends(get_db)):
    task_dict = task.model_dump()
    result = await db["tasks"].update_one(
        {"_id": ObjectId(task_id)},
        {"$set": task_dict}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Task updated successfully"}

@router.delete("/delete/{task_id}")
async def delete_task(task_id: str, db = Depends(get_db)):
    # Optional: Check if there are submissions before deleting?
    # For now, just delete.
    result = await db["tasks"].delete_one({"_id": ObjectId(task_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Also delete associated submissions
    await db["submissions"].delete_many({"task_id": task_id})
    
    return {"message": "Task and associated submissions deleted"}
