from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from app.core.database import get_db
from app.core.config import get_ist_time
from bson import ObjectId

router = APIRouter()


class AntiCheatConfig(BaseModel):
    disable_tab_switch: bool = True
    disable_copy_paste: bool = True
    disable_right_click: bool = True
    full_screen_required: bool = False


class ExamCreate(BaseModel):
    title: str
    description: str
    type: str                          # "MCQ", "Coding", or "Mixed"
    duration_minutes: int = 60
    total_marks: int = 100
    anti_cheating: AntiCheatConfig = AntiCheatConfig()
    instructions: Optional[str] = ""
    questions: List[Dict[str, Any]] = [] # New: Store MCQ/Coding items


class ExamToggle(BaseModel):
    is_active: bool


@router.post("/create")
async def create_exam(exam: ExamCreate, db=Depends(get_db)):
    doc = exam.dict()
    doc["is_active"] = False
    doc["created_at"] = get_ist_time()
    doc["results_count"] = 0
    result = await db["exams"].insert_one(doc)
    return {"message": "Exam node initialized.", "exam_id": str(result.inserted_id)}


@router.get("/list", response_model=List[dict])
async def list_exams(db=Depends(get_db)):
    cursor = db["exams"].find().sort("created_at", -1)
    exams = await cursor.to_list(length=200)
    for e in exams:
        e["_id"] = str(e["_id"])
        e.setdefault("is_active", False)
        e.setdefault("type", "MCQ")
        e.setdefault("duration_minutes", 60)
        e.setdefault("total_marks", 100)
        # Count how many interns have submitted results for this exam
        results_count = await db["exam_results"].count_documents({"exam_id": str(e["_id"])})
        e["results_count"] = results_count
    return exams


@router.patch("/toggle/{exam_id}")
async def toggle_exam(exam_id: str, is_active: bool, db=Depends(get_db)):
    result = await db["exams"].update_one(
        {"_id": ObjectId(exam_id)},
        {"$set": {
            "is_active": is_active,
            "toggled_at": get_ist_time()
        }}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Exam not found.")
    state = "LIVE" if is_active else "OFFLINE"
    return {"message": f"Exam status: {state}"}


@router.patch("/{exam_id}/questions")
async def update_exam_questions(exam_id: str, questions: List[Dict[str, Any]], db=Depends(get_db)):
    """Update assessment items for a specific exam node."""
    result = await db["exams"].update_one(
        {"_id": ObjectId(exam_id)},
        {"$set": {"questions": questions}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Exam not found.")
    return {"message": f"Synchronized {len(questions)} assessment items to node."}


@router.get("/results/{exam_id}", response_model=List[dict])
async def get_exam_results(exam_id: str, db=Depends(get_db)):
    """Fetch all intern results for a given exam. Shared DB — written by intern portal."""
    cursor = db["exam_results"].find({"exam_id": exam_id}).sort("submitted_at", -1)
    results = await cursor.to_list(length=500)
    for r in results:
        r["_id"] = str(r["_id"])
    return results


@router.get("/drafts/{exam_id}", response_model=List[dict])
async def list_exam_drafts(exam_id: str, db=Depends(get_db)):
    """Fetch real-time drafts for interns currently taking the exam."""
    cursor = db["exam_drafts"].find({"exam_id": exam_id}).sort("updated_at", -1)
    drafts = await cursor.to_list(length=200)
    for d in drafts:
        d["_id"] = str(d["_id"])
    return drafts


@router.delete("/{exam_id}")
async def delete_exam(exam_id: str, db=Depends(get_db)):
    result = await db["exams"].delete_one({"_id": ObjectId(exam_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Exam not found.")
    return {"message": "Exam node decommissioned."}
