from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Request
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from app.core.database import get_db
from app.core.config import get_ist_time
from bson import ObjectId

router = APIRouter()


class AntiCheatConfig(BaseModel):
    disable_tab_switch: bool = True
    disable_copy_paste: bool = True
    disable_right_click: bool = True
    full_screen_required: bool = False


class ExamCreate(BaseModel):
    title: str
    description: str
    type: str                          # "MCQ", "Coding", or "Mixed"
    duration_minutes: int = 60
    total_marks: int = 100
    anti_cheating: AntiCheatConfig = AntiCheatConfig()
    instructions: Optional[str] = ""
    questions: List[Dict[str, Any]] = []
    wifi_lock: bool = True             # Require company WiFi to access & submit


class ExamToggle(BaseModel):
    is_active: bool


@router.get("/network-info")
async def get_network_info(request: Request, db=Depends(get_db)):
    """Return the currently registered company WiFi prefix from attendance settings."""
    config = await db["system_settings"].find_one({"type": "attendance"})
    prefix = config.get("allowed_ip_prefix", "") if config else ""
    return {
        "allowed_ip_prefix": prefix,
        "display": f"{prefix}.*" if prefix else "Not configured",
        "configured": bool(prefix)
    }


@router.post("/create")
async def create_exam(exam: ExamCreate, request: Request, db=Depends(get_db)):
    doc = exam.dict()
    doc.pop("wifi_lock", None)  # Remove helper flag before storing

    # Auto-inject company WiFi prefix from attendance system settings
    if exam.wifi_lock:
        config = await db["system_settings"].find_one({"type": "attendance"})
        prefix = config.get("allowed_ip_prefix", "") if config else ""
        doc["allowed_ip_prefix"] = prefix
    else:
        doc["allowed_ip_prefix"] = ""  # No network restriction

    doc["is_active"] = False
    doc["created_at"] = get_ist_time()
    doc["results_count"] = 0
    result = await db["exams"].insert_one(doc)
    return {
        "message": "Exam node initialized.",
        "exam_id": str(result.inserted_id),
        "wifi_lock_prefix": doc["allowed_ip_prefix"]
    }


@router.get("/list", response_model=List[dict])
async def list_exams(db=Depends(get_db)):
    cursor = db["exams"].find().sort("created_at", -1)
    exams = await cursor.to_list(length=200)
    for e in exams:
        e["_id"] = str(e["_id"])
        e.setdefault("is_active", False)
        e.setdefault("type", "MCQ")
        e.setdefault("duration_minutes", 60)
        e.setdefault("total_marks", 100)
        # Count how many interns have submitted results for this exam
        results_count = await db["exam_results"].count_documents({"exam_id": str(e["_id"])})
        e["results_count"] = results_count
    return exams


@router.patch("/toggle/{exam_id}")
async def toggle_exam(exam_id: str, is_active: bool, db=Depends(get_db)):
    result = await db["exams"].update_one(
        {"_id": ObjectId(exam_id)},
        {"$set": {
            "is_active": is_active,
            "toggled_at": get_ist_time()
        }}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Exam not found.")
    state = "LIVE" if is_active else "OFFLINE"
    return {"message": f"Exam status: {state}"}


@router.patch("/{exam_id}/questions")
async def update_exam_questions(exam_id: str, questions: List[Dict[str, Any]], db=Depends(get_db)):
    """Update assessment items for a specific exam node."""
    result = await db["exams"].update_one(
        {"_id": ObjectId(exam_id)},
        {"$set": {"questions": questions}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Exam not found.")
    return {"message": f"Synchronized {len(questions)} assessment items to node."}


@router.get("/results/{exam_id}", response_model=List[dict])
async def get_exam_results(exam_id: str, db=Depends(get_db)):
    """Fetch all intern results for a given exam. Shared DB — written by intern portal."""
    cursor = db["exam_results"].find({"exam_id": exam_id}).sort("submitted_at", -1)
    results = await cursor.to_list(length=500)
    for r in results:
        r["_id"] = str(r["_id"])
    return results


@router.get("/drafts/{exam_id}", response_model=List[dict])
async def list_exam_drafts(exam_id: str, db=Depends(get_db)):
    """Fetch real-time drafts for interns currently taking the exam."""
    cursor = db["exam_drafts"].find({"exam_id": exam_id}).sort("updated_at", -1)
    drafts = await cursor.to_list(length=200)
    for d in drafts:
        d["_id"] = str(d["_id"])
    return drafts


@router.delete("/{exam_id}")
async def delete_exam(exam_id: str, db=Depends(get_db)):
    result = await db["exams"].delete_one({"_id": ObjectId(exam_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Exam not found.")
    return {"message": "Exam node decommissioned."}
from app.api.system import run_tests, TestRunRequest, TestCase

def safe_int(value: Any, default: int = 1) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default

def normalize_question(question: Dict[str, Any]) -> Dict[str, Any]:
    normalized = dict(question or {})
    raw_type = str(
        normalized.get("type")
        or normalized.get("question_type")
        or normalized.get("kind")
        or ""
    ).strip().lower()

    if raw_type in {"mcq", "multiple choice", "multiple_choice"}:
        normalized["type"] = "mcq"
        normalized["options"] = normalized.get("options") or normalized.get("choices") or normalized.get("answers") or []
        normalized["correct_answer_index"] = normalized.get(
            "correct_answer_index",
            normalized.get("correctAnswerIndex", 0),
        )
        normalized["points"] = safe_int(normalized.get("points", normalized.get("marks", 1)), 1)
    elif raw_type in {"coding", "code", "programming"}:
        normalized["type"] = "coding"
        normalized["language"] = normalized.get("language") or normalized.get("code_language") or "javascript"
        normalized["boilerplate"] = normalized.get("boilerplate") or normalized.get("starter_code") or ""
        normalized["constraints"] = normalized.get("constraints") or ""
        
        # Normalize test cases (handle JSON string and field name aliases)
        tcs = normalized.get("test_cases") or normalized.get("testCases") or []
        if isinstance(tcs, str) and tcs.strip():
            try:
                import json
                tcs = json.loads(tcs)
            except:
                tcs = []
        
        norm_tcs = []
        if isinstance(tcs, list):
            for tc in tcs:
                if isinstance(tc, dict):
                    norm_tcs.append({
                        "input": str(tc.get("input", "")),
                        "expected": str(tc.get("expected") if tc.get("expected") is not None else tc.get("output", ""))
                    })
        normalized["test_cases"] = norm_tcs
        normalized["points"] = safe_int(normalized.get("points", normalized.get("marks", 1)), 1)
    else:
        has_mcq_fields = bool(normalized.get("options") or normalized.get("choices"))
        normalized["type"] = "mcq" if has_mcq_fields else "coding"
        if normalized["type"] == "mcq":
            normalized["options"] = normalized.get("options") or normalized.get("choices") or normalized.get("answers") or []
            normalized["correct_answer_index"] = normalized.get(
                "correct_answer_index",
                normalized.get("correctAnswerIndex", 0),
            )
            normalized["points"] = safe_int(normalized.get("points", normalized.get("marks", 1)), 1)
        else:
            normalized["language"] = normalized.get("language") or normalized.get("code_language") or "javascript"
            normalized["boilerplate"] = normalized.get("boilerplate") or normalized.get("starter_code") or ""
            normalized["constraints"] = normalized.get("constraints") or ""
            
            tcs = normalized.get("test_cases") or normalized.get("testCases") or []
            if isinstance(tcs, str) and tcs.strip():
                try:
                    import json
                    tcs = json.loads(tcs)
                except:
                    tcs = []
            
            norm_tcs = []
            if isinstance(tcs, list):
                for tc in tcs:
                    if isinstance(tc, dict):
                        norm_tcs.append({
                            "input": str(tc.get("input", "")),
                            "expected": str(tc.get("expected") if tc.get("expected") is not None else tc.get("output", ""))
                        })
            normalized["test_cases"] = norm_tcs
            normalized["points"] = safe_int(normalized.get("points", normalized.get("marks", 1)), 1)

    return normalized

def normalize_questions(questions: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    return [normalize_question(question) for question in (questions or [])]

def extract_mcq_answer_choice(answer: Any) -> Optional[int]:
    if isinstance(answer, dict):
        for key in ("answer_index", "answerIndex", "selected_index", "selectedIndex"):
            if key in answer and answer[key] is not None:
                try: return int(answer[key])
                except: continue
    elif isinstance(answer, (int, str)):
        try: return int(answer)
        except: return None
    return None

@router.post("/regrade/{submission_id}")
async def regrade_result(submission_id: str, db=Depends(get_db)):
    """
    Repair a submission by re-running auto-grading.
    Uses student-selected languages and recovers them if missing.
    """
    collection_name = "exam_results"
    try:
        obj_id = ObjectId(submission_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid submission ID format")

    result = await db["exam_results"].find_one({"_id": obj_id})
    if not result:
        result = await db["mock_results"].find_one({"_id": obj_id})
        if not result:
            raise HTTPException(status_code=404, detail="Submission not found")
        collection_name = "mock_results"

    exam_id = result.get("exam_id")
    exam = await db["exams"].find_one({"_id": ObjectId(exam_id)})
    if not exam:
        exam = await db["mocks"].find_one({"_id": ObjectId(exam_id)})
        if not exam:
            raise HTTPException(status_code=404, detail="Exam definition not found")

    questions = normalize_questions(exam.get("questions", []))
    answers = result.get("answers", [])
    
    # Recover languages from candidate_answers if missing
    if not result.get("languages"):
        student_id = result.get("student_id")
        ca_cursor = db["candidate_answers"].find(
            {"exam_id": str(exam_id), "candidate_id": str(student_id)},
            {"_id": 0, "question_idx": 1, "language": 1}
        ).sort("question_idx", 1)
        ca_docs = await ca_cursor.to_list(length=200)
        if ca_docs:
            ca_map = {doc["question_idx"]: doc.get("language", "python") for doc in ca_docs}
            recovered_langs = [ca_map.get(idx, "python") for idx in range(len(questions))]
            result["languages"] = recovered_langs
            await db[collection_name].update_one(
                {"_id": obj_id},
                {"$set": {"languages": recovered_langs}}
            )

    total_score = 0
    breakdown = []

    for i, q in enumerate(questions):
        student_ans = answers[i] if i < len(answers) else None
        points = safe_int(q.get("points", 1), 1)
        
        item = {
            "title": q.get("title") or q.get("text") or q.get("question") or f"Question {i+1}",
            "type": q.get("type"),
            "language": q.get("language", "python"),
            "points_earned": 0,
            "max_points": points,
            "is_correct": False
        }

        if q.get("type") == "mcq":
            student_choice = extract_mcq_answer_choice(student_ans)
            correct_choice = extract_mcq_answer_choice(q.get("correct_answer_index", 0))
            item["student_answer"] = student_choice
            item["correct_answer"] = correct_choice
            item["language"] = "mcq"
            if student_choice is not None and student_choice == correct_choice:
                total_score += points
                item["points_earned"] = points
                item["is_correct"] = True
                
        elif q.get("type") == "coding":
            code_answer = str(student_ans) if student_ans else ""
            item["student_answer"] = code_answer
            
            res_langs = result.get("languages")
            lang = q.get("language", "python")
            if res_langs and i < len(res_langs) and res_langs[i] and res_langs[i] != "mcq":
                lang = res_langs[i]
            
            item["language"] = lang
            test_cases_data = q.get("test_cases", [])
            
            if code_answer.strip() and isinstance(test_cases_data, list) and len(test_cases_data) > 0:
                tcs = [TestCase(input=tc.get("input", ""), expected=tc.get("expected", "")) for tc in test_cases_data]
                payload = TestRunRequest(language=lang, code=code_answer, test_cases=tcs)
                try:
                    res = await run_tests(payload)
                    passed = res.get("passed", 0)
                    total = res.get("total", 1)
                    if total > 0:
                        earned = round((passed / total) * points)
                        total_score += earned
                        item["points_earned"] = earned
                        item["passed_tests"] = passed
                        item["total_tests"] = total
                        item["is_correct"] = (passed == total)
                except Exception as e:
                    import logging
                    logging.error(f"Execution error for sub {submission_id} Q{i}: {e}")
                    item["total_tests"] = len(test_cases_data)
                    item["passed_tests"] = 0
        
        breakdown.append(item)

    await db[collection_name].update_one(
        {"_id": obj_id},
        {"$set": {
            "breakdown": breakdown,
            "score": total_score,
            "repaired_at": get_ist_time()
        }}
    )

    return {"message": "Success", "score": total_score, "breakdown": breakdown}

import traceback
import logging

async def process_bulk_regrade(results: List[dict], db):
    logging.info(f"Starting bulk regrade for {len(results)} submissions...")
    for res in results:
        sub_id = str(res["_id"])
        try:
            await regrade_result(sub_id, db)
        except Exception as e:
            logging.error(f"Error regrading {sub_id}: {e}")
            continue
    logging.info("Bulk regrade finished.")

@router.post("/regrade-exam/{exam_id}")
async def regrade_all_exam_submissions(exam_id: str, background_tasks: BackgroundTasks, db=Depends(get_db)):
    """Regrade all submissions for an exam in the background."""
    cursor = db["exam_results"].find({"exam_id": exam_id})
    results = await cursor.to_list(length=1000)
    
    if not results:
        # Check mock_results collection
        cursor = db["mock_results"].find({"exam_id": exam_id})
        results = await cursor.to_list(length=1000)
        
        if not results:
            return {"message": "No submissions found", "count": 0}
    
    background_tasks.add_task(process_bulk_regrade, results, db)
            
    return {"message": f"Bulk regrade initiated for {len(results)} submissions. This will run in the background.", "count": len(results)}
