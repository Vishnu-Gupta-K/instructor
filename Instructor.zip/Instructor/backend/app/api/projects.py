from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.core.database import get_db
from app.core.config import get_ist_time
from bson import ObjectId

router = APIRouter()


class ProjectCreate(BaseModel):
    title: str
    description: str
    deadline: str              # "YYYY-MM-DD"
    team_members: List[str]    # list of intern user_ids/emails
    tech_stack: Optional[str] = ""


class ProjectUpdate(BaseModel):
    progress: Optional[int] = None   # 0-100
    status: Optional[str] = None     # "in_progress", "completed", "on_hold"
    description: Optional[str] = None


@router.post("/create")
async def create_project(project: ProjectCreate, db=Depends(get_db)):
    doc = project.dict()
    doc["progress"] = 0
    doc["status"] = "in_progress"
    doc["created_at"] = get_ist_time()
    doc["updated_at"] = get_ist_time()
    result = await db["projects"].insert_one(doc)
    return {"message": "Project deployed to Atlas.", "project_id": str(result.inserted_id)}


@router.get("/list", response_model=List[dict])
async def list_projects(db=Depends(get_db)):
    cursor = db["projects"].find().sort("created_at", -1)
    projects = await cursor.to_list(length=200)
    for p in projects:
        p["_id"] = str(p["_id"])
        # Ensure defaults exist
        p.setdefault("progress", 0)
        p.setdefault("status", "in_progress")
        p.setdefault("tech_stack", "")
        p.setdefault("team_members", [])
    return projects


@router.patch("/{project_id}")
async def update_project(project_id: str, body: ProjectUpdate, db=Depends(get_db)):
    update_data = {k: v for k, v in body.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update.")
    update_data["updated_at"] = get_ist_time()

    result = await db["projects"].update_one(
        {"_id": ObjectId(project_id)},
        {"$set": update_data}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Project not found.")
    return {"message": "Project telemetry synchronized."}


@router.delete("/{project_id}")
async def delete_project(project_id: str, db=Depends(get_db)):
    result = await db["projects"].delete_one({"_id": ObjectId(project_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found.")
    return {"message": "Project decommissioned from Atlas."}
