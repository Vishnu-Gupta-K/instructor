from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from app.core.database import get_db
from app.core.config import get_ist_time
from bson import ObjectId

router = APIRouter()


class MockCreate(BaseModel):
    title: str
    description: str
    duration: int = 30   # minutes
    category: Optional[str] = "General"
    questions: List[Dict[str, Any]] = []
    wifi_lock: bool = True  # Require company WiFi to access & submit


@router.get("/network-info")
async def get_network_info(request: Request, db=Depends(get_db)):
    """Return the currently registered company WiFi prefix from attendance settings."""
    config = await db["system_settings"].find_one({"type": "attendance"})
    prefix = config.get("allowed_ip_prefix", "") if config else ""
    return {
        "allowed_ip_prefix": prefix,
        "display": f"{prefix}.*" if prefix else "Not configured",
        "configured": bool(prefix)
    }


@router.post("/create")
async def create_mock(mock: MockCreate, request: Request, db=Depends(get_db)):
    doc = mock.dict()
    doc.pop("wifi_lock", None)  # Remove helper flag before storing

    # Auto-inject company WiFi prefix from attendance system settings
    if mock.wifi_lock:
        config = await db["system_settings"].find_one({"type": "attendance"})
        prefix = config.get("allowed_ip_prefix", "") if config else ""
        doc["allowed_ip_prefix"] = prefix
    else:
        doc["allowed_ip_prefix"] = ""  # No network restriction

    doc["is_active"] = False
    doc["created_at"] = get_ist_time()
    result = await db["mocks"].insert_one(doc)
    return {
        "message": "Mock exam deployed.",
        "mock_id": str(result.inserted_id),
        "wifi_lock_prefix": doc["allowed_ip_prefix"]
    }


@router.get("/list", response_model=List[dict])
async def list_mocks(db=Depends(get_db)):
    cursor = db["mocks"].find().sort("created_at", -1)
    mocks = await cursor.to_list(length=200)
    for m in mocks:
        m["_id"] = str(m["_id"])
        m.setdefault("is_active", False)
        m.setdefault("category", "General")
        m.setdefault("wifi_lock", bool(m.get("allowed_ip_prefix", "")))
        m["results_count"] = await db["mock_results"].count_documents({"exam_id": m["_id"]})
    return mocks


@router.patch("/toggle/{mock_id}")
async def toggle_mock(mock_id: str, is_active: bool, db=Depends(get_db)):
    result = await db["mocks"].update_one(
        {"_id": ObjectId(mock_id)},
        {"$set": {"is_active": is_active, "toggled_at": get_ist_time()}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Mock not found.")
    return {"message": f"Mock {'activated' if is_active else 'deactivated'}."}


@router.patch("/{mock_id}/questions")
async def update_mock_questions(mock_id: str, questions: List[Dict[str, Any]], db=Depends(get_db)):
    """Update question bank for a specific mock assessment."""
    result = await db["mocks"].update_one(
        {"_id": ObjectId(mock_id)},
        {"$set": {"questions": questions}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Mock not found.")
    return {"message": f"Synchronized {len(questions)} mock assessment items."}


@router.get("/results/{mock_id}", response_model=List[dict])
async def get_mock_results(mock_id: str, db=Depends(get_db)):
    """Fetch intern submissions for a specific mock assessment."""
    cursor = db["mock_results"].find({"exam_id": mock_id}).sort("submitted_at", -1)
    results = await cursor.to_list(length=500)
    for r in results:
        r["_id"] = str(r["_id"])
    return results


@router.delete("/{mock_id}")
async def delete_mock(mock_id: str, db=Depends(get_db)):
    result = await db["mocks"].delete_one({"_id": ObjectId(mock_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Mock not found.")
    return {"message": "Mock decommissioned."}
