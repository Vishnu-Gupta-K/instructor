from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from app.models.schemas import Token
from app.core.security import get_password_hash, create_access_token, verify_password
from app.core.database import get_db
from app.core.config import settings, get_ist_time
from app.core.mail import build_otp_email_payload, build_welcome_email_payload, send_mail
from datetime import datetime, timedelta, timezone
from pymongo import ReturnDocument
import random
from jose import jwt, JWTError
from aiosmtplib import send
from typing import List, Optional

router = APIRouter()
bearer_scheme = HTTPBearer(auto_error=False)


# ─────────────────────────────────────────────────────
# Schemas
# ─────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email: str
    password: str

class ForgotPasswordRequest(BaseModel):
    email: str

class ResetWithOTPRequest(BaseModel):
    email: str
    otp: str
    new_password: str

class ProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    department: Optional[str] = None


class ProvisionOTPRequest(BaseModel):
    email: EmailStr


class InternProvisionCreate(BaseModel):
    full_name: str
    email: EmailStr
    password: str
    phone: Optional[str] = None
    department: Optional[str] = "Information Technology"
    designation: Optional[str] = "Member"
    internship_role: Optional[str] = None
    internship_duration: Optional[str] = None
    batch: Optional[str] = None
    otp: str


# ─────────────────────────────────────────────────────
# Helper: decode JWT and return user_id
# ─────────────────────────────────────────────────────
async def get_current_user_id(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db = Depends(get_db)
) -> str:
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated.")
    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        user_id: str = payload.get("sub")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token payload.")
        
        # Security Lockdown Check: Verify status and maintenance mode
        user = await db["users"].find_one({"user_id": user_id})
        if not user:
            raise HTTPException(status_code=404, detail="Identity no longer exists.")
        
        if user.get("status") != "active" or not user.get("is_active", True):
            raise HTTPException(
                status_code=403, 
                detail="Your account has been deactivated by the administrator."
            )
            
        # Global Maintenance Check
        settings_doc = await db["system_settings"].find_one({"_id": "global_config"})
        if settings_doc and settings_doc.get("maintenance_mode"):
            raise HTTPException(
                status_code=503, 
                detail="System under maintenance. Performance operations suspended."
            )

        return user_id
    except JWTError:
        raise HTTPException(status_code=401, detail="Token expired or invalid.")


# ─────────────────────────────────────────────────────
# POST /login
# ─────────────────────────────────────────────────────
@router.post("/login", response_model=Token)
async def login(request: LoginRequest, db=Depends(get_db)):
    user = await db["users"].find_one({"email": request.email})
    if not user:
        raise HTTPException(status_code=401, detail="Please enter valid details.")

    if not verify_password(request.password, user["hashed_password"]):
        raise HTTPException(status_code=401, detail="Please enter valid details.")

    if user.get("role") != "INSTRUCTOR":
        raise HTTPException(
            status_code=403,
            detail="Please enter valid details."
        )

    if user.get("status") != "active" or not user.get("is_active", True):
        raise HTTPException(
            status_code=403,
            detail="Account is deactivated. Contact Administrator."
        )

    access_token = create_access_token(data={
        "sub": user["user_id"],
        "role": user["role"],
        "full_name": user.get("full_name", "Faculty")
    })
    return {"access_token": access_token, "token_type": "bearer"}


# ─────────────────────────────────────────────────────
# GET /me — Real faculty profile from DB
# ─────────────────────────────────────────────────────
@router.get("/me")
async def get_me(
    user_id: str = Depends(get_current_user_id),
    db=Depends(get_db)
):
    user = await db["users"].find_one({"user_id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="Faculty identity not found.")
    user["_id"] = str(user["_id"])
    if "hashed_password" in user:
        del user["hashed_password"]
    return user


# ─────────────────────────────────────────────────────
# PUT /me — Update faculty profile
# ─────────────────────────────────────────────────────
@router.put("/me")
async def update_me(
    body: ProfileUpdate,
    user_id: str = Depends(get_current_user_id),
    db=Depends(get_db)
):
    update_data = {k: v for k, v in body.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update.")

    update_data["profile_updated_at"] = get_ist_time()
    await db["users"].update_one(
        {"user_id": user_id},
        {"$set": update_data}
    )
    return {"message": "Profile synchronized successfully."}


# ─────────────────────────────────────────────────────
# GET /interns — All intern profiles (no passwords)
# ─────────────────────────────────────────────────────
@router.get("/interns", response_model=List[dict])
async def get_interns(db=Depends(get_db)):
    cursor = db["users"].find({"role": "INTERN"}).sort("full_name", 1)
    interns = await cursor.to_list(length=500)
    for i in interns:
        i["_id"] = str(i["_id"])
        if "hashed_password" in i:
            del i["hashed_password"]
        i["performance_label"] = i.get("performance_label", "Needs Evaluation")
        i["overall_progress"] = i.get("overall_progress", 0)
    return interns


async def dispatch_welcome_email(
    email: str,
    full_name: str,
    role_label: str,
    account_details: Optional[dict[str, str | None]] = None,
):
    payload = build_welcome_email_payload(
        full_name=full_name,
        role_label=role_label,
        account_details=account_details,
    )
    return await send_mail(
        subject=payload["subject"],
        recipient=email,
        text_body=payload["text"],
        html_body=payload["html"],
    )


@router.post("/send-otp")
async def send_intern_provision_otp(req: ProvisionOTPRequest, db=Depends(get_db)):
    existing = await db["users"].find_one({"email": req.email})
    if existing:
        raise HTTPException(status_code=400, detail="Identity Already Provisioned.")

    otp_code = str(random.randint(100000, 999999))
    expiry_minutes = max(1, int(settings.OTP_EXPIRE_MINUTES or 5))

    await db["otp_verifications"].update_one(
        {"email": req.email},
        {"$set": {
            "otp": otp_code,
            "created_at": datetime.now(timezone.utc),
            "expires_at": datetime.now(timezone.utc) + timedelta(minutes=expiry_minutes),
        }},
        upsert=True,
    )

    payload = build_otp_email_payload(
        otp_code=otp_code,
        expires_minutes=expiry_minutes,
        purpose="intern account provisioning",
        recipient_name=req.email,
    )

    settings_doc = await db["system_settings"].find_one({"_id": "global_config"})
    smtp_enabled = settings_doc.get("smtp_enabled", False) if settings_doc else False

    if not smtp_enabled:
        fallback_payload = {
            "message": "Verification sequence generated (SMTP Relay restricted).",
            "delivery": "administrative-bypass",
        }
        if settings.MAIL_DEBUG_MODE:
            fallback_payload["debug_token"] = otp_code
        return fallback_payload

    dispatch = await send_mail(
        subject=payload["subject"],
        recipient=req.email,
        text_body=payload["text"],
        html_body=payload["html"],
    )

    if not dispatch.sent:
        fallback_payload = {
            "message": "Verification sequence generated. Mail relay unavailable, contact administrator if inbox delivery is delayed.",
            "delivery": dispatch.reason,
        }
        if settings.MAIL_DEBUG_MODE:
            fallback_payload["debug_token"] = otp_code
        return fallback_payload

    return {
        "message": "Verification sequence dispatched.",
        "delivery": dispatch.reason,
    }


@router.post("/create")
async def create_intern_account(user: InternProvisionCreate, db=Depends(get_db)):
    existing_query = {"email": user.email}
    if user.phone:
        existing_query = {"$or": [{"email": user.email}, {"phone": user.phone}]}

    existing = await db["users"].find_one(existing_query)
    if existing:
        raise HTTPException(status_code=400, detail="Existing account detected (Email or Phone collision).")

    otp_record = await db["otp_verifications"].find_one({"email": user.email})
    if not otp_record or otp_record.get("otp") != user.otp:
        raise HTTPException(status_code=400, detail="Verification Sequence Invalid or Expired.")

    expires_at = otp_record.get("expires_at")
    if isinstance(expires_at, datetime):
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expires_at:
            await db["otp_verifications"].delete_one({"email": user.email})
            raise HTTPException(status_code=400, detail="Verification Sequence Expired.")

    seq = await db["sequences"].find_one_and_update(
        {"_id": "INTERN"},
        {"$inc": {"sequence_value": 1}},
        upsert=True,
        return_document=ReturnDocument.AFTER,
    )
    year = get_ist_time().year
    padded_seq = str(seq["sequence_value"]).zfill(2)
    user_id = f"SPX_INTERN_{year}{padded_seq}"

    new_user = {
        "user_id": user_id,
        "email": user.email,
        "role": "INTERN",
        "full_name": user.full_name,
        "phone": user.phone,
        "department": user.department,
        "designation": user.designation,
        "internship_role": user.internship_role,
        "internship_duration": user.internship_duration,
        "batch": user.batch,
        "status": "active",
        "is_active": True,
        "hashed_password": get_password_hash(user.password),
        "is_verified": True,
        "performance_label": "Needs Evaluation",
        "overall_progress": 0,
        "github": "",
        "linkedin": "",
        "created_at": get_ist_time(),
    }

    await db["users"].insert_one(new_user)
    await db["otp_verifications"].delete_one({"email": user.email})

    welcome_details = {
        "Intern ID": user_id,
        "Email": user.email,
        "Full Name": user.full_name,
        "Phone": user.phone,
        "Department": user.department,
        "Designation": user.designation,
        "Internship Role": user.internship_role,
        "Internship Duration": user.internship_duration,
        "Batch": user.batch,
    }
    welcome_dispatch = await dispatch_welcome_email(
        user.email,
        user.full_name,
        "Intern",
        welcome_details,
    )

    if not welcome_dispatch.sent:
        print(f"[AUTH] Welcome mail failed for {user.email}: {welcome_dispatch.reason}")

    return {
        "message": "Intern account provisioned successfully.",
        "user_id": user_id,
    }


# ─────────────────────────────────────────────────────
# POST /forgot-password — OTP Generation
# ─────────────────────────────────────────────────────
@router.post("/forgot-password")
async def forgot_password(request: ForgotPasswordRequest, db=Depends(get_db)):
    user = await db["users"].find_one({"email": request.email})
    if not user:
        return {"message": "Verification code dispatched (if identity exists)."}

    otp_code = str(random.randint(100000, 999999))
    expiry_minutes = max(1, int(settings.OTP_EXPIRE_MINUTES or 5))
    
    # Store OTP in DB with configured expiry
    await db["otp_codes"].update_one(
        {"email": request.email},
        {"$set": {
            "otp": otp_code,
            "expires_at": datetime.now(timezone.utc) + timedelta(minutes=expiry_minutes)
        }},
        upsert=True
    )

    payload = build_otp_email_payload(
        otp_code=otp_code,
        expires_minutes=expiry_minutes,
        purpose="faculty password reset",
        recipient_name=user.get("full_name") or user.get("email") or "Faculty",
    )
    # Global SMTP Toggle Check
    settings_doc = await db["system_settings"].find_one({"_id": "global_config"})
    smtp_enabled = settings_doc.get("smtp_enabled", False) if settings_doc else False
    
    if not smtp_enabled:
        fallback_payload = {
            "message": "Verification code generated (SMTP Relay restricted).",
            "delivery": "administrative-bypass"
        }
        if settings.MAIL_DEBUG_MODE:
            fallback_payload["debug_token"] = otp_code
        return fallback_payload

    dispatch = await send_mail(
        subject=payload["subject"],
        recipient=user["email"],
        text_body=payload["text"],
        html_body=payload["html"],
    )

    if not dispatch.sent:
        fallback_payload = {
            "message": "Verification code generated. Mail relay unavailable, contact administrator if inbox delivery is delayed.",
            "delivery": dispatch.reason,
        }
        if settings.MAIL_DEBUG_MODE:
            fallback_payload["debug_token"] = otp_code
        return fallback_payload

    return {
        "message": "Verification code dispatched to your institutional inbox.",
        "delivery": dispatch.reason,
    }


# ─────────────────────────────────────────────────────
# POST /reset-password — OTP Verification & Reset
# ─────────────────────────────────────────────────────
@router.post("/reset-password")
async def reset_password(request: ResetWithOTPRequest, db=Depends(get_db)):
    # Verify OTP
    record = await db["otp_codes"].find_one({"email": request.email})
    if not record:
        raise HTTPException(status_code=400, detail="No pending clearance found for this entity.")
    
    # Check expiry (manual timezone guard)
    db_expires = record["expires_at"]
    if db_expires.tzinfo is None:
        db_expires = db_expires.replace(tzinfo=timezone.utc)

    if datetime.now(timezone.utc) > db_expires:
         raise HTTPException(status_code=400, detail="OTP expired. Request new clearance.")
        
    if record["otp"] != request.otp:
        raise HTTPException(status_code=400, detail="Invalid Crypto-Signature (OTP mismatch).")

    # Finalize Reset
    hashed = get_password_hash(request.new_password)
    await db["users"].update_one(
        {"email": request.email},
        {"$set": {
            "hashed_password": hashed,
            "password_reset_at": get_ist_time()
        }}
    )
    
    # Delete OTP after successful use
    await db["otp_codes"].delete_one({"email": request.email})
    
    return {"message": "Identity credential synchronized successfully."}
    
class ChangePasswordRequest(BaseModel):
    new_password: str

@router.post("/change-password")
async def change_password(
    request: ChangePasswordRequest,
    user_id: str = Depends(get_current_user_id),
    db = Depends(get_db)
):
    hashed = get_password_hash(request.new_password)
    await db["users"].update_one(
        {"user_id": user_id},
        {"$set": {
            "hashed_password": hashed,
            "password_updated_at": get_ist_time()
        }}
    )
    return {"message": "Security credentials updated successfully."}
