from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.core.database import get_db
from app.core.config import get_ist_time
from bson import ObjectId

router = APIRouter()


class InterviewSchedule(BaseModel):
    intern_email: str
    intern_name: Optional[str] = ""
    category: str          # "Logic", "Architecture", "Soft Skills", "Technical"
    scheduled_at: str      # ISO datetime string
    notes: Optional[str] = ""
    duration_minutes: int = 45


class InterviewScore(BaseModel):
    score: int             # 0-100
    feedback: str
    outcome: str           # "Pass", "Fail", "On Hold"


@router.post("/schedule")
async def schedule_interview(body: InterviewSchedule, db=Depends(get_db)):
    doc = body.dict()
    doc["status"] = "Scheduled"
    doc["created_at"] = get_ist_time()
    doc["score"] = None
    doc["feedback"] = None
    doc["outcome"] = None
    result = await db["interviews"].insert_one(doc)
    return {"message": "Interview session scheduled.", "interview_id": str(result.inserted_id)}


@router.get("/list", response_model=List[dict])
async def list_interviews(db=Depends(get_db)):
    cursor = db["interviews"].find().sort("scheduled_at", 1)
    interviews = await cursor.to_list(length=200)
    for i in interviews:
        i["_id"] = str(i["_id"])
        i.setdefault("status", "Scheduled")
        i.setdefault("category", "Technical")
        i.setdefault("score", None)
        i.setdefault("feedback", None)
        i.setdefault("outcome", None)
    return interviews


@router.post("/score/{interview_id}")
async def score_interview(interview_id: str, body: InterviewScore, db=Depends(get_db)):
    if not 0 <= body.score <= 100:
        raise HTTPException(status_code=400, detail="Score must be between 0 and 100.")

    result = await db["interviews"].update_one(
        {"_id": ObjectId(interview_id)},
        {"$set": {
            "score": body.score,
            "feedback": body.feedback,
            "outcome": body.outcome,
            "status": "Completed",
            "scored_at": get_ist_time()
        }}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Interview not found.")
    return {"message": f"Interview scored. Outcome: {body.outcome}"}


@router.delete("/{interview_id}")
async def cancel_interview(interview_id: str, db=Depends(get_db)):
    result = await db["interviews"].delete_one({"_id": ObjectId(interview_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Interview not found.")
    return {"message": "Interview session cancelled."}
