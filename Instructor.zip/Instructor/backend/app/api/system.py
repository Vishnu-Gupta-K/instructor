from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from pydantic import BaseModel
from typing import List, Optional
import psutil
import time
import base64
import httpx
import asyncio
from datetime import datetime

router = APIRouter()

# ── Models ───────────────────────────────────────────────────────────────────

class TestCase(BaseModel):
    input: str
    expected: str

class TestRunRequest(BaseModel):
    language: str
    code: str
    test_cases: List[TestCase]

# ── Judge0 Cloud API ─────────────────────────────────────────────────────────

JUDGE0_URL = "https://ce.judge0.com"

LANG_MAP = {
    "python":     71,  # Python 3.8.1
    "python3":    71,
    "c":          50,  # C (GCC 9.2.0)
    "cpp":        54,  # C++ (GCC 9.2.0)
    "java":       62,  # Java (OpenJDK 13.0.1)
    "javascript": 63,  # Node.js 12.14.0
    "node":       63,
    "typescript": 74,  # TypeScript 3.7.4
    "csharp":     51,  # C# (Mono 6.6.0)
    "go":         60,  # Go 1.13.5
}

def b64e(s: str) -> str:
    return base64.b64encode((s or "").encode("utf-8")).decode("utf-8")

def b64d(s: str) -> str:
    try:
        return base64.b64decode(s or "").decode("utf-8")
    except Exception:
        return s or ""

async def run_code_online(language: str, code: str, user_input: str) -> dict:
    """Submit code to Judge0 cloud API (base64-encoded for safety)."""
    lang_id = LANG_MAP.get(language.lower().strip(), 71)
    payload = {
        "source_code": b64e(code),
        "language_id": lang_id,
        "stdin":       b64e(user_input),
    }
    async with httpx.AsyncClient() as client:
        try:
            url = f"{JUDGE0_URL}/submissions?base64_encoded=true&wait=true"
            response = await client.post(url, json=payload, timeout=25)
            if response.status_code not in (200, 201):
                return {"ok": False, "error": f"Cloud API Error: {response.text}"}
            data = response.json()
            status_id      = data.get("status", {}).get("id")
            stdout         = b64d(data.get("stdout"))
            stderr         = b64d(data.get("stderr"))
            compile_output = b64d(data.get("compile_output"))
            error = stderr if stderr else compile_output
            return {
                "ok":            status_id == 3,
                "output":        stdout,
                "error":         error,
                "compile_error": status_id == 6,
                "exit_code":     0 if status_id == 3 else 1,
                "duration_ms":   int(float(data.get("time") or 0) * 1000),
            }
        except Exception as e:
            return {"ok": False, "error": f"Cloud Execution Failed: {str(e)}"}

@router.post("/run-tests")
async def run_tests(payload: TestRunRequest):
    """
    Execute multiple test cases in parallel via Judge0 cloud.
    Returns pass/fail results for each case.
    """
    tasks = [
        run_code_online(payload.language, payload.code, tc.input or "")
        for tc in payload.test_cases
    ]
    results_raw = await asyncio.gather(*tasks)

    def normalize(s: str) -> str:
        if not s:
            return ""
        lines = [line.strip() for line in s.replace("\r", "").strip().splitlines()]
        return "\n".join(lines)

    processed = []
    passed    = 0

    for idx, result in enumerate(results_raw):
        if result.get("compile_error"):
            return {
                "ok":            False,
                "compile_error": True,
                "error":         result.get("error"),
                "results":       [],
            }

        actual_raw   = result.get("output") or ""
        expected_raw = payload.test_cases[idx].expected or ""

        actual_norm   = normalize(actual_raw)
        expected_norm = normalize(expected_raw)
        is_passed     = result.get("ok", False) and (actual_norm == expected_norm)

        if is_passed:
            passed += 1

        processed.append({
            "input":       payload.test_cases[idx].input,
            "expected":    expected_raw,
            "actual":      actual_raw,
            "status":      "passed" if is_passed else "failed",
            "stderr":      result.get("error", ""),
            "duration_ms": result.get("duration_ms", 0),
        })

    return {
        "total":   len(payload.test_cases),
        "passed":  passed,
        "failed":  len(payload.test_cases) - passed,
        "results": processed,
    }

@router.get("/stats")
async def get_system_stats(db = Depends(get_db)):
    """
    Returns real-time hardware telemetry for the Instructor Terminal.
    Uses psutil to read CPU/RAM sensors and boot time.
    """
    # Database stats
    db_stats = await db.command("dbstats")
    
    # CPU Usage
    cpu_usage = psutil.cpu_percent(interval=0.1)
    
    # RAM Usage
    ram = psutil.virtual_memory()
    
    # Uptime Calculation
    boot_time = psutil.boot_time()
    uptime_seconds = time.time() - boot_time
    days = int(uptime_seconds // 86400)
    hours = int((uptime_seconds % 86400) // 3600)
    minutes = int((uptime_seconds % 3600) // 60)
    
    uptime_str = f"{days}d, {hours}h" if days > 0 else f"{hours}h, {minutes}m"
    
    # Counts
    intern_count = await db["users"].count_documents({"role": "INTERN"})
    task_count = await db["tasks"].count_documents({})
    
    return {
        "hardware": {
            "cpu_load": f"{cpu_usage}%",
            "ram_usage": f"{ram.percent}%",
            "uptime": uptime_str
        },
        "database": {
            "size": f"{round(db_stats['dataSize'] / (1024*1024), 2)} MB",
            "collections": db_stats['collections']
        },
        "counts": {
            "interns": intern_count,
            "tasks": task_count
        }
    }
