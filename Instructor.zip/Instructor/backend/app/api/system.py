from fastapi import APIRouter, Depends
from app.core.database import get_db
import psutil
import time
from datetime import datetime

router = APIRouter()

@router.get("/stats")
async def get_system_stats(db = Depends(get_db)):
    """
    Returns real-time hardware telemetry for the Instructor Terminal.
    Uses psutil to read CPU/RAM sensors and boot time.
    """
    # Database stats
    db_stats = await db.command("dbstats")
    
    # CPU Usage
    cpu_usage = psutil.cpu_percent(interval=0.1)
    
    # RAM Usage
    ram = psutil.virtual_memory()
    
    # Uptime Calculation
    boot_time = psutil.boot_time()
    uptime_seconds = time.time() - boot_time
    days = int(uptime_seconds // 86400)
    hours = int((uptime_seconds % 86400) // 3600)
    minutes = int((uptime_seconds % 3600) // 60)
    
    uptime_str = f"{days}d, {hours}h" if days > 0 else f"{hours}h, {minutes}m"
    
    # Counts
    intern_count = await db["users"].count_documents({"role": "INTERN"})
    task_count = await db["tasks"].count_documents({})
    
    return {
        "hardware": {
            "cpu_load": f"{cpu_usage}%",
            "ram_usage": f"{ram.percent}%",
            "uptime": uptime_str
        },
        "database": {
            "size": f"{round(db_stats['dataSize'] / (1024*1024), 2)} MB",
            "collections": db_stats['collections']
        },
        "counts": {
            "interns": intern_count,
            "tasks": task_count
        }
    }
