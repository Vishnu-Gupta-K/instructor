from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.core.database import get_db
from app.core.config import get_ist_time
from bson import ObjectId

router = APIRouter()

class LeaveResponse(BaseModel):
    status: str # "APPROVED" or "REJECTED"
    instructor_response: str

@router.get("/all", response_model=List[dict])
async def get_all_leaves(db=Depends(get_db)):
    """Fetch all leave requests across the ecosystem."""
    cursor = db["leaves"].find().sort("submitted_at", -1)
    leaves = await cursor.to_list(length=500)
    for l in leaves:
        l["_id"] = str(l["_id"])
    return leaves

@router.patch("/{leave_id}/respond")
async def respond_to_leave(leave_id: str, resp: LeaveResponse, db=Depends(get_db)):
    """Instructor respond to a leave request with status and comments."""
    result = await db["leaves"].update_one(
        {"_id": ObjectId(leave_id)},
        {"$set": {
            "status": resp.status,
            "instructor_response": resp.instructor_response,
            "responded_at": get_ist_time()
        }}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Leave request node not found.")
    return {"message": f"Leave request updated to: {resp.status}"}
