from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from bson import ObjectId

router = APIRouter()

@router.get("/report/{submission_id}")
async def get_ai_review(submission_id: str, db = Depends(get_db)):
    """Fetch the AI review report for a specific submission (Shared with Intern DB)."""
    # Robust lookup: handle cases where submission_id might be stored as string or ObjectId
    query = {
        "$or": [
            {"submission_id": submission_id},
            {"submission_id": ObjectId(submission_id) if ObjectId.is_valid(submission_id) else None}
        ]
    }
    report = await db["ai_review_reports"].find_one(query)
    
    if not report:
        raise HTTPException(status_code=404, detail="AI Review not found or still processing.")
    
    report["_id"] = str(report["_id"])
    return report

@router.get("/exam/{exam_id}")
async def get_exam_reviews(exam_id: str, db = Depends(get_db)):
    """Fetch all AI reviews for a specific exam for comparison."""
    cursor = db["ai_review_reports"].find({"exam_id": exam_id})
    reports = await cursor.to_list(length=100)
    for r in reports:
        r["_id"] = str(r["_id"])
    return reports
