from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from bson import ObjectId
import json
from datetime import datetime
import google.generativeai as genai
from app.core.config import settings

router = APIRouter()

async def regenerate_ai_review(submission_id: str, db) -> dict:
    """Regenerate a clean AI review report on-the-fly."""
    obj_id = ObjectId(submission_id) if ObjectId.is_valid(submission_id) else None
    if not obj_id:
        return None

    # Try both standard and mock submission collections
    sub = await db["exam_results"].find_one({"_id": obj_id})
    if not sub:
        sub = await db["mock_results"].find_one({"_id": obj_id})
        if not sub:
            return None

    answers = sub.get("answers", [])
    languages = sub.get("languages", [])
    breakdown = sub.get("breakdown", [])

    # Find the coding response
    coding_idx = -1
    for i, b in enumerate(breakdown):
        if b.get("type") == "coding":
            coding_idx = i
            break

    if coding_idx == -1:
        code = answers[0] if answers else ""
        lang = languages[0] if languages else "python"
        passed = 0
        total = 1
    else:
        b_item = breakdown[coding_idx]
        code = b_item.get("student_answer", "")
        lang = b_item.get("language", "python")
        passed = b_item.get("passed_tests", 0)
        total = b_item.get("total_tests", 1)

    prompt = f"""
You are an elite principal software engineer and strict code reviewer. 
Analyze the following {lang} code. The code passed {passed} out of {total} test cases.

CODE:
{code}

Output ONLY valid JSON matching this schema: 
{{
  "metrics": {{"correctness": 0-100, "efficiency": 0-100, "maintainability": 0-100, "code_quality": 0-100, "overall_score": 0-100}},
  "complexity": {{"time_complexity": "O(N)", "space_complexity": "O(1)", "reasoning": "..."}},
  "optimizations": [{{"issue": "...", "suggestion": "...", "code_snippet": "..."}}],
  "bugs_and_risks": ["..."],
  "best_practices": ["..."],
  "instructor_summary": "...",
  "intern_feedback": "..."
}}
"""
    api_key = settings.GOOGLE_API_KEY
    if not api_key:
        return None

    genai.configure(api_key=api_key)
    model = genai.GenerativeModel('gemini-2.5-flash')

    # LLM inference
    response = await model.generate_content_async(
        prompt,
        generation_config=genai.types.GenerationConfig(
            response_mime_type="application/json"
        )
    )

    content = response.text.strip()
    if "```json" in content:
        content = content.split("```json")[1].split("```")[0].strip()
    elif "```" in content:
        content = content.split("```")[1].split("```")[0].strip()

    raw_ai_json = json.loads(content)

    new_report = {
        "submission_id": submission_id,
        "exam_id": sub.get("exam_id") or sub.get("mock_id"),
        "student_id": sub.get("student_id"),
        "language": lang,
        "metrics": raw_ai_json.get("metrics"),
        "complexity": raw_ai_json.get("complexity"),
        "optimizations": raw_ai_json.get("optimizations"),
        "bugs_and_risks": raw_ai_json.get("bugs_and_risks"),
        "best_practices": raw_ai_json.get("best_practices", []),
        "instructor_summary": raw_ai_json.get("instructor_summary"),
        "intern_feedback": raw_ai_json.get("intern_feedback"),
        "created_at": datetime.utcnow()
    }

    # Delete any existing failed report and save the clean one
    query = {
        "$or": [
            {"submission_id": submission_id},
            {"submission_id": obj_id}
        ]
    }
    await db["ai_review_reports"].delete_many(query)
    await db["ai_review_reports"].insert_one(new_report)

    return new_report

@router.get("/report/{submission_id}")
async def get_ai_review(submission_id: str, db = Depends(get_db)):
    """Fetch the AI review report for a specific submission (with auto-regeneration fallback)."""
    query = {
        "$or": [
            {"submission_id": submission_id},
            {"submission_id": ObjectId(submission_id) if ObjectId.is_valid(submission_id) else None}
        ]
    }
    report = await db["ai_review_reports"].find_one(query)

    # Self-healing: if report contains a Gemini error or is completely missing, regenerate it!
    should_regenerate = False
    if not report:
        should_regenerate = True
    elif "Gemini Error" in report.get("complexity", {}).get("reasoning", ""):
        should_regenerate = True

    if should_regenerate:
        try:
            print(f"[AI Self-Healing] Attempting to generate review for submission {submission_id}...")
            regenerated = await regenerate_ai_review(submission_id, db)
            if regenerated:
                report = regenerated
        except Exception as e:
            print(f"[AI Self-Healing Failed] Error: {e}")

    if not report:
        raise HTTPException(status_code=404, detail="AI Review not found or still processing.")

    report["_id"] = str(report["_id"])
    return report

@router.get("/exam/{exam_id}")
async def get_exam_reviews(exam_id: str, db = Depends(get_db)):
    """Fetch all AI reviews for a specific exam for comparison."""
    cursor = db["ai_review_reports"].find({"exam_id": exam_id})
    reports = await cursor.to_list(length=100)
    for r in reports:
        r["_id"] = str(r["_id"])
    return reports
