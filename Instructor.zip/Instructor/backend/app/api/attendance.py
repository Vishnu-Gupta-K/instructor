from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from typing import List, Optional, Tuple
from app.core.database import get_db
from app.core.config import get_ist_time
from datetime import datetime, timezone, timedelta
import ipaddress
import socket

router = APIRouter()

IST = timezone(timedelta(hours=5, minutes=30))
CLIENT_IP_HEADERS = ("X-Forwarded-For", "X-Real-IP", "CF-Connecting-IP", "True-Client-IP")


class AttendanceConfig(BaseModel):
    is_active: bool
    require_geo: bool = False
    require_ip: bool = False
    geo_lat: Optional[float] = None
    geo_lng: Optional[float] = None
    geo_radius_meters: Optional[int] = 200
    allowed_ip_prefix: Optional[str] = ""


class ManualOverride(BaseModel):
    student_id: str
    student_name: Optional[str] = None
    status: str        # "present" or "absent"
    reason: Optional[str] = "Faculty Override"


def _extract_ip(request: Request) -> str:
    """Extract and normalize client IP, accounting for proxies."""
    for header_name in CLIENT_IP_HEADERS:
        parsed = _parse_ip(request.headers.get(header_name))
        if parsed:
            return str(parsed)

    host = request.client.host if request.client else None
    parsed = _parse_ip(host)
    return str(parsed) if parsed else "0.0.0.0"


def _ip_prefix(ip: str, octets: int = 3) -> str:
    """Return a canonical network prefix for IP matching."""
    parsed = _parse_ip(ip)
    if not parsed:
        return ""

    if isinstance(parsed, ipaddress.IPv4Address):
        parts = str(parsed).split(".")
        return ".".join(parts[:octets]) if len(parts) >= octets else str(parsed)

    hextets = parsed.exploded.split(":")
    return ":".join(hextets[:4])


def _parse_ip(raw_value: Optional[str]):
    if not raw_value:
        return None

    candidate = str(raw_value).strip()
    if not candidate:
        return None

    if "," in candidate:
        candidate = candidate.split(",", 1)[0].strip()

    if candidate.startswith("[") and "]" in candidate:
        candidate = candidate[1:candidate.index("]")]

    if ":" in candidate and candidate.count(":") == 1 and "." in candidate:
        host_part, port_part = candidate.rsplit(":", 1)
        if port_part.isdigit():
            candidate = host_part

    try:
        parsed = ipaddress.ip_address(candidate)
    except ValueError:
        return None

    if isinstance(parsed, ipaddress.IPv6Address) and parsed.ipv4_mapped:
        return parsed.ipv4_mapped
    return parsed


def _sanitize_prefix(raw_prefix: Optional[str]) -> str:
    value = (raw_prefix or "").strip().lower().replace(" ", "")
    if not value:
        return ""

    if value.endswith(".*") or value.endswith(".x"):
        value = value[:-2]

    parsed_direct = _parse_ip(value)
    if parsed_direct:
        return _ip_prefix(str(parsed_direct))

    if "/" in value:
        try:
            network = ipaddress.ip_network(value, strict=False)
            return _ip_prefix(str(network.network_address))
        except ValueError:
            pass

    parts = value.split(".")
    if len(parts) >= 3 and all(part.isdigit() and 0 <= int(part) <= 255 for part in parts[:3]):
        return ".".join(parts[:3])

    return value


def _detect_host_ipv4() -> Optional[str]:
    """Best-effort detection of the server host LAN IPv4 for localhost sessions."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("8.8.8.8", 80))
            parsed = _parse_ip(probe.getsockname()[0])
            if isinstance(parsed, ipaddress.IPv4Address) and not (
                parsed.is_loopback or parsed.is_unspecified or parsed.is_link_local
            ):
                return str(parsed)
    except OSError:
        pass

    try:
        infos = socket.getaddrinfo(socket.gethostname(), None, family=socket.AF_INET)
    except OSError:
        infos = []

    for info in infos:
        if not info[4]:
            continue
        parsed = _parse_ip(info[4][0])
        if isinstance(parsed, ipaddress.IPv4Address) and not (
            parsed.is_loopback or parsed.is_unspecified or parsed.is_link_local
        ):
            return str(parsed)

    return None


def _resolve_reference_prefix(request_ip: str, manual_prefix: Optional[str] = None) -> Tuple[str, str]:
    normalized_manual = _sanitize_prefix(manual_prefix)
    if normalized_manual:
        return normalized_manual, "manual"

    parsed_request = _parse_ip(request_ip)
    if parsed_request and not parsed_request.is_loopback and not parsed_request.is_unspecified:
        return _ip_prefix(str(parsed_request)), "request"

    host_ip = _detect_host_ipv4()
    if host_ip:
        return _ip_prefix(host_ip), "host"

    if parsed_request:
        return _ip_prefix(str(parsed_request)), "request"

    return "", "unknown"


def _format_prefix_display(prefix: str) -> str:
    if not prefix:
        return "Unavailable"
    return f"{prefix}.*" if "." in prefix else f"{prefix}::*"


def _normalize_identifier(value: Optional[str]) -> str:
    return (value or "").strip().lower()


async def _get_todays_attendance_identifiers(db, log_type: Optional[str] = None) -> set:
    """Return identifiers that already have an attendance record today."""
    today_start = datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)
    query = {"timestamp": {"$gte": today_start}, "status": "present"}
    if log_type:
        query["log_type"] = log_type
        
    cursor = db["attendance_logs"].find(query, {"student_id": 1, "student_email": 1})
    logs = await cursor.to_list(length=2000)
 
    identifiers = set()
    for log in logs:
        if log.get("student_id"):
            identifiers.add(_normalize_identifier(log.get("student_id")))
        if log.get("student_email"):
            identifiers.add(_normalize_identifier(log.get("student_email")))
    return identifiers


async def _load_pending_students(db) -> List[dict]:
    """Return interns/students who do not yet have an attendance record today."""
    marked_identifiers = await _get_todays_attendance_identifiers(db)
    cursor = db["users"].find({"role": {"$in": ["INTERN", "STUDENT"]}}).sort("full_name", 1)
    students = await cursor.to_list(length=1000)

    pending = []
    for student in students:
        student_id = _normalize_identifier(student.get("user_id"))
        student_email = _normalize_identifier(student.get("email"))
        if student_id in marked_identifiers or student_email in marked_identifiers:
            continue

        student["_id"] = str(student["_id"])
        if "hashed_password" in student:
            del student["hashed_password"]
        student["display_name"] = student.get("full_name") or student.get("email") or student.get("user_id")
        pending.append(student)

    return pending


@router.get("/status")
async def get_status(db=Depends(get_db)):
    """Fetch current attendance configuration. Intern portal polls this."""
    config = await db["system_settings"].find_one({"type": "attendance"})
    if not config:
        return {
            "is_active": False,
            "require_geo": False,
            "require_ip": False,
            "geo_lat": None,
            "geo_lng": None,
            "geo_radius_meters": 200,
            "allowed_ip_prefix": "",
            "configured_at": None
        }
    config["_id"] = str(config["_id"])
    return config


@router.get("/network-info")
async def get_network_info(request: Request):
    """Return the instructor's current live IP — used for one-click network capture."""
    ip = _extract_ip(request)
    prefix, source = _resolve_reference_prefix(ip)

    warning = None
    if source == "host":
        warning = "Client IP appears local/proxied; using detected server LAN network for WiFi lock."
    elif source == "unknown":
        warning = "Could not confidently detect a WiFi network prefix from this request."

    return {
        "ip": ip,
        "suggested_prefix": prefix,
        "source": source,
        "warning": warning,
        "display": f"{_format_prefix_display(prefix)} (auto-detected for WiFi lock)"
    }


@router.post("/configure")
async def configure_attendance(body: AttendanceConfig, request: Request, db=Depends(get_db)):
    """
    Arm or disarm attendance scanner.
    When arming, automatically captures instructor IP as the reference network.
    """
    instructor_ip = _extract_ip(request)

    # Prefer manual value, else request-derived value, else host LAN fallback.
    auto_prefix, network_source = _resolve_reference_prefix(instructor_ip, body.allowed_ip_prefix)

    if body.require_ip and not auto_prefix:
        raise HTTPException(
            status_code=400,
            detail="Unable to detect WiFi network prefix. Capture network again before enabling WiFi lock."
        )

    update_doc = {
        "type": "attendance",
        "is_active": body.is_active,
        "require_ip": body.require_ip,
        "require_geo": body.require_geo,
        "geo_lat": body.geo_lat,
        "geo_lng": body.geo_lng,
        "geo_radius_meters": body.geo_radius_meters or 200,
        "allowed_ip_prefix": auto_prefix,
        "network_source": network_source,
        "configured_by_ip": instructor_ip,
        "configured_at": get_ist_time()
    }

    await db["system_settings"].update_one(
        {"type": "attendance"},
        {"$set": update_doc},
        upsert=True
    )
    state = "ARMED" if body.is_active else "DISARMED"
    return {
        "message": f"Attendance scanner {state}.",
        "captured_ip_prefix": auto_prefix,
        "instructor_ip": instructor_ip,
        "network_source": network_source
    }


@router.get("/logs/today", response_model=List[dict])
async def get_today_logs(db=Depends(get_db)):
    """All check-ins from midnight IST today onwards."""
    today_start = datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)
    cursor = db["attendance_logs"].find(
        {"timestamp": {"$gte": today_start}}
    ).sort("timestamp", -1)
    logs = await cursor.to_list(length=500)
    for log in logs:
        log["_id"] = str(log["_id"])
        if isinstance(log.get("timestamp"), datetime):
            log["timestamp_display"] = log["timestamp"].astimezone(IST).strftime(
                "%d %b %Y %I:%M %p IST"
            )
    return logs


@router.get("/logs/all", response_model=List[dict])
async def get_all_logs(db=Depends(get_db)):
    """All attendance logs across all dates."""
    cursor = db["attendance_logs"].find().sort("timestamp", -1)
    logs = await cursor.to_list(length=2000)
    for log in logs:
        log["_id"] = str(log["_id"])
        if isinstance(log.get("timestamp"), datetime):
            log["timestamp_display"] = log["timestamp"].astimezone(IST).strftime(
                "%d %b %Y %I:%M %p IST"
            )
    return logs


@router.get("/logs/records")
async def get_attendance_records(
    filter_type: str = "daily",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    student_id: Optional[str] = None,
    db=Depends(get_db)
):
    """
    Fetch attendance logs based on timeframes: daily, weekly, monthly, yearly, or custom.
    """
    now = datetime.now(IST)
    query = {}

    if filter_type == "daily":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        query["timestamp"] = {"$gte": start}
    elif filter_type == "weekly":
        # Strictly Current Week (starting Monday)
        days_to_monday = now.weekday() 
        start = (now - timedelta(days=days_to_monday)).replace(hour=0, minute=0, second=0, microsecond=0)
        query["timestamp"] = {"$gte": start}
    elif filter_type == "monthly":
        # This month
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        query["timestamp"] = {"$gte": start}
    elif filter_type == "yearly":
        # This year
        start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        query["timestamp"] = {"$gte": start}
    elif filter_type == "custom" and start_date and end_date:
        try:
            # Expecting YYYY-MM-DD
            start = datetime.strptime(start_date, "%Y-%m-%d").replace(tzinfo=IST)
            end = datetime.strptime(end_date, "%Y-%m-%d").replace(hour=23, minute=59, second=59, tzinfo=IST)
            query["timestamp"] = {"$gte": start, "$lte": end}
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD")

    if student_id:
        query["student_id"] = student_id

    cursor = db["attendance_logs"].find(query).sort("timestamp", -1)
    logs = await cursor.to_list(length=5000)
    
    for log in logs:
        log["_id"] = str(log["_id"])
        if isinstance(log.get("timestamp"), datetime):
            log["timestamp_display"] = log["timestamp"].astimezone(IST).strftime("%d %b %Y %I:%M %p IST")
            
    return logs


@router.get("/pending-students", response_model=List[dict])
async def get_pending_students(db=Depends(get_db)):
    """Students/interns who have not yet been marked for today's attendance."""
    return await _load_pending_students(db)


@router.post("/override")
async def manual_override(body: ManualOverride, db=Depends(get_db)):
    """Faculty can manually mark an intern as present or absent."""
    student = await db["users"].find_one({
        "role": {"$in": ["INTERN", "STUDENT"]},
        "$or": [
            {"user_id": body.student_id},
            {"email": body.student_id}
        ]
    })
    if not student:
        raise HTTPException(status_code=404, detail="Student not found in MongoDB Atlas.")

    if not body.student_name:
        body.student_name = student.get("full_name") or student.get("email") or student.get("user_id")

    marked_identifiers = await _get_todays_attendance_identifiers(db)
    student_id = _normalize_identifier(student.get("user_id"))
    student_email = _normalize_identifier(student.get("email"))
    if student_id in marked_identifiers or student_email in marked_identifiers:
        raise HTTPException(status_code=409, detail="Attendance has already been recorded for this student today.")

    log_entry = {
        "student_id": student.get("user_id") or body.student_id,
        "student_email": student.get("email"),
        "student_name": body.student_name,
        "status": body.status,
        "method": "manual_override",
        "reason": body.reason,
        "timestamp": get_ist_time(),
        "ip_verified": True,
        "geo_verified": True,
        "verified": True
    }
    await db["attendance_logs"].insert_one(log_entry)
    return {"message": f"Override applied: {body.student_name} marked as {body.status.upper()}."}

@router.post("/finalize-day")
async def finalize_day(db=Depends(get_db)):
    """
    Mark all interns as ABSENT if they haven't checked in/out and it's past 10:00 PM IST.
    """
    now_ist = get_ist_time()
    
    # 🚨 SKIP WEEKENDS: Only finalize attendance on working days (Monday=0 to Friday=4)
    if now_ist.weekday() >= 5:
        return {"message": "Attendance finalization skipped. Today is a weekend.", "count": 0}

    if now_ist.hour < 22:
        raise HTTPException(status_code=400, detail="Day can only be finalized after 10:00 PM IST.")

    marked_in_ids = await _get_todays_attendance_identifiers(db, log_type="check-in")
    marked_out_ids = await _get_todays_attendance_identifiers(db, log_type="check-out")
    
    # Fetch all interns
    cursor = db["users"].find({"role": {"$in": ["INTERN", "STUDENT"]}})
    interns = await cursor.to_list(length=1000)
    
    absent_logs = []
    today_start = now_ist.replace(hour=0, minute=0, second=0, microsecond=0)
    timestamp_display = now_ist.strftime("%d %b %Y %I:%M %p IST")

    for intern in interns:
        sid = _normalize_identifier(intern.get("user_id"))
        
        # 1. NO CHECK-IN: Full Absence (0 points)
        if sid not in marked_in_ids:
            already_marked = await db["attendance_logs"].find_one({
                "student_id": intern.get("user_id"),
                "log_type": "check-in",
                "timestamp": {"$gte": today_start}
            })
            if not already_marked:
                absent_logs.append({
                    "student_id": intern.get("user_id"),
                    "student_name": intern.get("full_name") or intern.get("email"),
                    "log_type": "check-in",
                    "status": "absent",
                    "method": "automatic_system",
                    "timestamp": now_ist,
                    "timestamp_display": timestamp_display,
                    "verified": True
                })
        
        # 2. HAS CHECK-IN BUT NO CHECK-OUT: Partial Absence (50% score)
        elif sid not in marked_out_ids:
            already_marked = await db["attendance_logs"].find_one({
                "student_id": intern.get("user_id"),
                "log_type": "check-out",
                "timestamp": {"$gte": today_start}
            })
            if not already_marked:
                absent_logs.append({
                    "student_id": intern.get("user_id"),
                    "student_name": intern.get("full_name") or intern.get("email"),
                    "log_type": "check-out",
                    "status": "absent",
                    "method": "automatic_system",
                    "timestamp": now_ist,
                    "timestamp_display": timestamp_display,
                    "verified": True
                })

    if absent_logs:
        await db["attendance_logs"].insert_many(absent_logs)
    
    return {"message": f"Day finalized at 10 PM. {len(absent_logs)} absence records generated.", "count": len(absent_logs)}
