from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.services.ai.question_generator import AIQuestionGenerator

router = APIRouter(tags=["AI Generation"])
generator = AIQuestionGenerator()

class GenerationRequest(BaseModel):
    topic: str
    difficulty: str = "Medium"
    count: int = 1

@router.post("/generate-question")
async def generate_question(request: GenerationRequest):
    """
    Generate questions using AI based on topic and difficulty.
    """
    try:
        questions = await generator.generate_questions(
            topic=request.topic,
            difficulty=request.difficulty,
            count=request.count
        )
        return {"success": True, "questions": questions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
