from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from app.core.database import get_db
from app.core.config import get_ist_time
import asyncio
from bson import ObjectId

router = APIRouter()

VALID_LABELS = ["Excellent", "Average", "Needs Improvement", "Underperforming", "Needs Evaluation"]

class LabelUpdate(BaseModel):
    label: str

class ProgressUpdate(BaseModel):
    progress: int  # 0-100


async def _get_total_working_days(db):
    pipeline = [
        {"$project": {"date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$timestamp"}}}},
        {"$group": {"_id": "$date"}},
        {"$count": "count"}
    ]
    res = await db["attendance_logs"].aggregate(pipeline).to_list(length=1)
    return res[0]["count"] if res else 0

def _calculate_metrics_in_memory(intern, stats, total_working_days, global_tasks):
    user_id = intern.get("user_id", "")
    email = intern.get("email", "")

    # 1. Attendance Rate
    # Each day has 2 slots (check-in, check-out). Total possible logs = total_working_days * 2
    present_logs = stats["attendance"].get(user_id, 0) or stats["attendance"].get(email, 0)
    possible_logs = total_working_days * 2
    att_rate = round((present_logs / possible_logs * 100), 1) if possible_logs > 0 else 0.0

    # 2. Task Completion Rate
    # specific_tasks = stats["task_assignments"].get(user_id, 0)
    # Actually, global_tasks is the count of tasks with assigned_to: []
    # Plus tasks specifically assigned to this user.
    assigned_count = stats["task_counts"].get(user_id, global_tasks)
    
    sub_stats = stats["submissions"].get(user_id, {"total": 0, "graded": 0, "avg_marks": 0})
    my_submissions = sub_stats["total"]
    tcr = round((my_submissions / assigned_count * 100), 1) if assigned_count > 0 else 0.0

    # 3. Academic Average
    task_marks = sub_stats["avg_marks"]
    exam_score = stats["exams"].get(user_id, 0) or stats["exams"].get(email, 0)
    mock_score = stats["mocks"].get(user_id, 0) or stats["mocks"].get(email, 0)

    academic_vals = [v for v in [task_marks, exam_score, mock_score] if v > 0]
    avg_academic = round(sum(academic_vals) / len(academic_vals), 1) if academic_vals else 0.0

    # 4. Overall Performance Index (OI)
    oi = round((att_rate * 0.3) + (tcr * 0.3) + (avg_academic * 0.4), 1)

    suggested_label = "Needs Evaluation"
    if assigned_count > 0 or total_working_days > 0:
        if oi >= 85: suggested_label = "Excellent"
        elif oi >= 65: suggested_label = "Average"
        elif oi >= 45: suggested_label = "Needs Improvement"
        else: suggested_label = "Underperforming"

    return {
        "attendance_rate": att_rate,
        "task_completion": tcr,
        "academic_avg": avg_academic,
        "overall_index": oi,
        "suggested_label": suggested_label,
        "present_days": present_logs,
        "total_working_days": total_working_days
    }, sub_stats, assigned_count


@router.get("/overview")
async def get_overview(db=Depends(get_db)):
    """Aggregated analytics for the performance dashboard."""
    # Run independent counts in parallel
    interns_task = db["users"].find({"role": "INTERN"}).to_list(length=1000)
    total_tasks_task = db["tasks"].count_documents({})
    graded_tasks_task = db["tasks"].count_documents({"status": "graded"})
    submitted_tasks_task = db["tasks"].count_documents({"status": {"$in": ["partially_submitted", "submitted"]}})
    assigned_tasks_task = db["tasks"].count_documents({"status": "assigned"})
    total_subs_task = db["submissions"].count_documents({})
    graded_subs_task = db["submissions"].count_documents({"graded": True})
    pending_subs_task = db["submissions"].count_documents({"graded": {"$ne": True}})

    from datetime import datetime, timezone, timedelta
    IST = timezone(timedelta(hours=5, minutes=30))
    today_start = datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)
    today_att_task = db["attendance_logs"].count_documents({"timestamp": {"$gte": today_start}})

    interns, total_tasks, graded_tasks, submitted_tasks, assigned_tasks, total_subs, graded_subs, pending_subs, today_att = await asyncio.gather(
        interns_task, total_tasks_task, graded_tasks_task, submitted_tasks_task, assigned_tasks_task, 
        total_subs_task, graded_subs_task, pending_subs_task, today_att_task
    )

    total = len(interns)
    if total == 0:
        return {
            "total_interns": 0, "label_distribution": {}, "avg_progress": 0,
            "task_stats": {"total": 0, "graded": 0, "submitted": 0, "assigned": 0},
            "submission_stats": {"total": 0, "graded": 0, "pending": 0},
            "today_attendance": 0
        }

    label_dist = {}
    for intern in interns:
        label = intern.get("performance_label", "Needs Evaluation")
        label_dist[label] = label_dist.get(label, 0) + 1

    avg_progress = round(sum(intern.get("overall_progress", 0) for intern in interns) / total, 1)

    return {
        "total_interns": total,
        "label_distribution": label_dist,
        "avg_progress": avg_progress,
        "task_stats": {
            "total": total_tasks, "graded": graded_tasks,
            "submitted": submitted_tasks, "assigned": assigned_tasks
        },
        "submission_stats": {
            "total": total_subs, "graded": graded_subs, "pending": pending_subs
        },
        "today_attendance": today_att
    }


@router.get("/interns")
async def get_all_interns(db=Depends(get_db)):
    """Optimized: Returns all interns with aggregated performance metrics."""
    # 1. Start parallel data fetching
    interns_task = db["users"].find({"role": "INTERN"}).sort("full_name", 1).to_list(length=1000)
    working_days_task = _get_total_working_days(db)
    
    # Global tasks (assigned to no one specific)
    global_tasks_task = db["tasks"].count_documents({"assigned_to": {"$size": 0}})
    
    # Specific task assignments count per user
    task_assignments_pipeline = [
        {"$match": {"assigned_to": {"$ne": []}}},
        {"$unwind": "$assigned_to"},
        {"$group": {"_id": "$assigned_to", "count": {"$sum": 1}}}
    ]
    task_assignments_task = db["tasks"].aggregate(task_assignments_pipeline).to_list(length=1000)

    # Submissions stats per user
    subs_pipeline = [
        {"$group": {
            "_id": "$student_id",
            "total": {"$sum": 1},
            "graded": {"$sum": {"$cond": ["$graded", 1, 0]}},
            "avg_marks": {"$avg": {"$cond": ["$graded", "$marks", None]}}
        }}
    ]
    subs_task = db["submissions"].aggregate(subs_pipeline).to_list(length=1000)

    # Attendance stats per user (Counting total present logs, not just unique days)
    att_pipeline = [
        {"$match": {"status": "present"}},
        {"$group": {"_id": "$student_id", "count": {"$sum": 1}}}
    ]
    att_task = db["attendance_logs"].aggregate(att_pipeline).to_list(length=1000)

    # Academic results (Exams/Mocks)
    exam_pipeline = [{"$group": {"_id": "$student_id", "avg": {"$avg": "$score"}}}]
    exams_task = db["exam_results"].aggregate(exam_pipeline).to_list(length=1000)
    mocks_task = db["mock_results"].aggregate(exam_pipeline).to_list(length=1000)

    # Await everything
    interns, total_working_days, global_tasks, task_assignments_res, subs_res, att_res, exams_res, mocks_res = await asyncio.gather(
        interns_task, working_days_task, global_tasks_task, task_assignments_task, subs_task, att_task, exams_task, mocks_task
    )

    # 2. Build look-up maps for O(1) access
    stats = {
        "task_counts": {r["_id"]: global_tasks + r["count"] for r in task_assignments_res},
        "submissions": {r["_id"]: {"total": r["total"], "graded": r["graded"], "avg_marks": round(r["avg_marks"] or 0, 1)} for r in subs_res},
        "attendance": {r["_id"]: r["count"] for r in att_res},
        "exams": {r["_id"]: round(r["avg"] or 0, 1) for r in exams_res},
        "mocks": {r["_id"]: round(r["avg"] or 0, 1) for r in mocks_res}
    }

    # 3. Assemble results
    result = []
    for intern in interns:
        intern["_id"] = str(intern["_id"])
        if "hashed_password" in intern: del intern["hashed_password"]

        intern["performance_label"] = intern.get("performance_label", "Needs Evaluation")
        intern["overall_progress"] = intern.get("overall_progress", 0)
        intern["is_active"] = intern.get("is_active", True)

        metrics, sub_stats, assigned_count = _calculate_metrics_in_memory(intern, stats, total_working_days, global_tasks)
        
        intern["performance_metrics"] = metrics
        intern["suggested_label"] = metrics["suggested_label"]
        intern["live_stats"] = {
            "tasks_assigned": assigned_count,
            "tasks_submitted": sub_stats["total"],
            "tasks_graded": sub_stats["graded"],
            "avg_marks": sub_stats["avg_marks"]
        }
        result.append(intern)

    return result


@router.put("/label/{user_id}")
async def update_performance_label(user_id: str, body: LabelUpdate, db=Depends(get_db)):
    """Update an intern's performance label."""
    if body.label not in VALID_LABELS:
        raise HTTPException(status_code=400, detail=f"Invalid label. Must be one of: {', '.join(VALID_LABELS)}")

    result = await db["users"].update_one(
        {"user_id": user_id, "role": "INTERN"},
        {"$set": {"performance_label": body.label, "label_updated_at": get_ist_time()}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Intern not found.")
    return {"message": f"Performance label updated to '{body.label}'."}


@router.put("/progress/{user_id}")
async def update_progress(user_id: str, body: ProgressUpdate, db=Depends(get_db)):
    """Update an intern's overall progress percentage."""
    if not 0 <= body.progress <= 100:
        raise HTTPException(status_code=400, detail="Progress must be between 0 and 100.")

    result = await db["users"].update_one(
        {"user_id": user_id, "role": "INTERN"},
        {"$set": {"overall_progress": body.progress, "progress_updated_at": get_ist_time()}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Intern not found.")
    return {"message": f"Progress updated to {body.progress}%."}


@router.patch("/toggle-active/{user_id}")
async def toggle_active_status(user_id: str, db=Depends(get_db)):
    """Toggle an intern's active status."""
    user = await db["users"].find_one({"user_id": user_id, "role": "INTERN"})
    if not user:
        raise HTTPException(status_code=404, detail="Intern not found.")

    new_status = not user.get("is_active", True)
    await db["users"].update_one(
        {"user_id": user_id},
        {"$set": {
            "is_active": new_status,
            "status": "active" if new_status else "disabled",
            "status_updated_at": get_ist_time(),
        }}
    )
    return {"message": f"Intern status updated to {'Active' if new_status else 'Deactivated'}.", "is_active": new_status}


@router.post("/sync-all")
async def sync_all_performance(db=Depends(get_db)):
    """Bulk analyze all interns and update their labels/progress."""
    interns = await db["users"].find({"role": "INTERN"}).to_list(length=1000)
    total_working_days = await _get_total_working_days(db)
    
    # Reuse the logic but optimized? 
    # Actually, for sync-all, we can use the same batching logic as get_all_interns if we want to be super fast.
    # But let's just use the existing helper logic for now as it's a background task usually.
    # Wait, I removed the helper. Let's just implement the loop efficiently.
    
    # For now, I'll just reuse the batch logic in a slightly different way.
    # Actually, let's keep it simple for sync-all.
    
    # Fetching stats once for sync-all
    global_tasks = await db["tasks"].count_documents({"assigned_to": {"$size": 0}})
    
    # (Optional: implement the same maps here for speed)
    # ... I'll just call get_all_interns logic ...
    
    data = await get_all_interns(db)
    
    updated_count = 0
    for intern_data in data:
        metrics = intern_data["performance_metrics"]
        await db["users"].update_one(
            {"user_id": intern_data["user_id"]},
            {"$set": {
                "performance_label": metrics["suggested_label"],
                "overall_progress": int(metrics["overall_index"]),
                "last_automated_sync": get_ist_time()
            }}
        )
        updated_count += 1
        
    return {"message": f"Successfully synchronized performance for {updated_count} interns."}
