from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from app.core.database import get_db
from app.core.config import get_ist_time

router = APIRouter()

VALID_LABELS = ["Excellent", "Average", "Needs Improvement", "Underperforming", "Needs Evaluation"]

class LabelUpdate(BaseModel):
    label: str

class ProgressUpdate(BaseModel):
    progress: int  # 0-100


async def _get_total_working_days(db):
    pipeline = [
        {"$project": {"date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$timestamp"}}}},
        {"$group": {"_id": "$date"}},
        {"$count": "count"}
    ]
    res = await db["attendance_logs"].aggregate(pipeline).to_list(length=1)
    return res[0]["count"] if res else 0

async def _calculate_intern_metrics(db, intern, total_working_days):
    user_id = intern.get("user_id", "")
    email = intern.get("email", "")

    # 1. Attendance Rate
    pipeline = [
        {"$match": {"$or": [{"student_id": user_id}, {"student_email": email}], "status": "present"}},
        {"$project": {"date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$timestamp"}}}},
        {"$group": {"_id": "$date"}},
        {"$count": "count"}
    ]
    att_res = await db["attendance_logs"].aggregate(pipeline).to_list(length=1)
    present_days = att_res[0]["count"] if att_res else 0
    att_rate = round((present_days / total_working_days * 100), 1) if total_working_days > 0 else 0.0

    # 2. Task Completion Rate
    assigned_tasks = await db["tasks"].count_documents({
        "$or": [
            {"assigned_to": {"$size": 0}},
            {"assigned_to": user_id}
        ]
    })
    my_submissions = await db["submissions"].count_documents({"student_id": user_id})
    tcr = round((my_submissions / assigned_tasks * 100), 1) if assigned_tasks > 0 else 0.0

    # 3. Academic Average (Tasks + Exams + Mocks)
    graded_subs = await db["submissions"].find({"student_id": user_id, "graded": True}).to_list(length=100)
    task_marks = sum(s.get("marks", 0) for s in graded_subs) / len(graded_subs) if graded_subs else 0

    exam_results = await db["exam_results"].find({"student_id": {"$in": [user_id, email]}}).to_list(length=100)
    exam_score = sum(r.get("score", 0) for r in exam_results) / len(exam_results) if exam_results else 0

    mock_results = await db["mock_results"].find({"student_id": {"$in": [user_id, email]}}).to_list(length=100)
    mock_score = sum(r.get("score", 0) for r in mock_results) / len(mock_results) if mock_results else 0

    academic_vals = [v for v in [task_marks, exam_score, mock_score] if v > 0]
    avg_academic = round(sum(academic_vals) / len(academic_vals), 1) if academic_vals else 0.0

    # 4. Overall Performance Index (OI)
    # Weighted: Att(30%) + Task(30%) + Academic(40%)
    oi = round((att_rate * 0.3) + (tcr * 0.3) + (avg_academic * 0.4), 1)

    suggested_label = "Needs Evaluation"
    if assigned_tasks > 0 or total_working_days > 0:
        if oi >= 85: suggested_label = "Excellent"
        elif oi >= 65: suggested_label = "Average"
        elif oi >= 45: suggested_label = "Needs Improvement"
        else: suggested_label = "Underperforming"

    return {
        "attendance_rate": att_rate,
        "task_completion": tcr,
        "academic_avg": avg_academic,
        "overall_index": oi,
        "suggested_label": suggested_label,
        "present_days": present_days,
        "total_working_days": total_working_days
    }


@router.get("/overview")
async def get_overview(db=Depends(get_db)):
    """
    Aggregated analytics for the performance dashboard.
    Returns total interns, label distribution, average progress, task completion rate.
    All data is live from the shared MongoDB Atlas cluster.
    """
    interns = await db["users"].find({"role": "INTERN"}).to_list(length=500)

    total = len(interns)
    if total == 0:
        return {
            "total_interns": 0,
            "label_distribution": {},
            "avg_progress": 0,
            "task_stats": {"total": 0, "graded": 0, "submitted": 0, "assigned": 0}
        }

    # Label distribution
    label_dist = {}
    for intern in interns:
        label = intern.get("performance_label", "Needs Evaluation")
        label_dist[label] = label_dist.get(label, 0) + 1

    # Average progress
    avg_progress = round(
        sum(intern.get("overall_progress", 0) for intern in interns) / total, 1
    )

    # Task statistics (from tasks collection)
    total_tasks = await db["tasks"].count_documents({})
    graded_tasks = await db["tasks"].count_documents({"status": "graded"})
    submitted_tasks = await db["tasks"].count_documents(
        {"status": {"$in": ["partially_submitted", "submitted"]}}
    )
    assigned_tasks = await db["tasks"].count_documents({"status": "assigned"})

    # Submission stats
    total_submissions = await db["submissions"].count_documents({})
    graded_submissions = await db["submissions"].count_documents({"graded": True})
    pending_submissions = await db["submissions"].count_documents({"graded": {"$ne": True}})

    # Attendance today
    from datetime import datetime, timezone, timedelta
    IST = timezone(timedelta(hours=5, minutes=30))
    today_start = datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)
    today_attendance = await db["attendance_logs"].count_documents(
        {"timestamp": {"$gte": today_start}}
    )

    return {
        "total_interns": total,
        "label_distribution": label_dist,
        "avg_progress": avg_progress,
        "task_stats": {
            "total": total_tasks,
            "graded": graded_tasks,
            "submitted": submitted_tasks,
            "assigned": assigned_tasks
        },
        "submission_stats": {
            "total": total_submissions,
            "graded": graded_submissions,
            "pending": pending_submissions
        },
        "today_attendance": today_attendance
    }


@router.get("/interns")
async def get_all_interns(db=Depends(get_db)):
    """
    Returns all interns with their real performance data from MongoDB.
    performance_label and overall_progress come directly from the users collection
    as set by the admin or updated by the instructor.
    """
    cursor = db["users"].find({"role": "INTERN"}).sort("full_name", 1)
    interns = await cursor.to_list(length=500)

    result = []
    for intern in interns:
        intern["_id"] = str(intern["_id"])
        if "hashed_password" in intern:
            del intern["hashed_password"]

        # Ensure these fields always exist with sensible defaults
        intern["performance_label"] = intern.get("performance_label", "Needs Evaluation")
        intern["overall_progress"] = intern.get("overall_progress", 0)
        intern["is_active"] = intern.get("is_active", True)

        # Live task completion stats for this intern
        assigned_tasks = await db["tasks"].count_documents({
            "$or": [
                {"assigned_to": {"$size": 0}},
                {"assigned_to": intern.get("user_id", "")}
            ]
        })
        my_submissions = await db["submissions"].count_documents({
            "student_id": intern.get("user_id", "")
        })
        my_graded = await db["submissions"].count_documents({
            "student_id": intern.get("user_id", ""),
            "graded": True
        })

        # Avg marks across graded submissions
        graded_subs = await db["submissions"].find({
            "student_id": intern.get("user_id", ""),
            "graded": True
        }).to_list(length=100)
        avg_marks = 0
        if graded_subs:
            avg_marks = round(
                sum(s.get("marks", 0) for s in graded_subs) / len(graded_subs), 1
            )

        # ─── Automated Analysis ───
        total_days = await _get_total_working_days(db)
        metrics = await _calculate_intern_metrics(db, intern, total_days)
        intern["performance_metrics"] = metrics
        intern["suggested_label"] = metrics["suggested_label"]

        intern["live_stats"] = {
            "tasks_assigned": assigned_tasks,
            "tasks_submitted": my_submissions,
            "tasks_graded": my_graded,
            "avg_marks": avg_marks
        }
        result.append(intern)

    return result


@router.put("/label/{user_id}")
async def update_performance_label(user_id: str, body: LabelUpdate, db=Depends(get_db)):
    """Update an intern's performance label. Reflects immediately in the intern's profile."""
    if body.label not in VALID_LABELS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid label. Must be one of: {', '.join(VALID_LABELS)}"
        )

    result = await db["users"].update_one(
        {"user_id": user_id, "role": "INTERN"},
        {"$set": {
            "performance_label": body.label,
            "label_updated_at": get_ist_time()
        }}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Intern not found.")

    return {"message": f"Performance label updated to '{body.label}'."}


@router.put("/progress/{user_id}")
async def update_progress(user_id: str, body: ProgressUpdate, db=Depends(get_db)):
    """Update an intern's overall progress percentage (0-100)."""
    if not 0 <= body.progress <= 100:
        raise HTTPException(status_code=400, detail="Progress must be between 0 and 100.")

    result = await db["users"].update_one(
        {"user_id": user_id, "role": "INTERN"},
        {"$set": {
            "overall_progress": body.progress,
            "progress_updated_at": get_ist_time()
        }}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Intern not found.")

    return {"message": f"Progress updated to {body.progress}%."}


@router.patch("/toggle-active/{user_id}")
async def toggle_active_status(user_id: str, db=Depends(get_db)):
    """Toggle an intern's active status. Deactivated interns cannot login."""
    user = await db["users"].find_one({"user_id": user_id, "role": "INTERN"})
    if not user:
        raise HTTPException(status_code=404, detail="Intern not found.")

    new_status = not user.get("is_active", True)
    await db["users"].update_one(
        {"user_id": user_id},
        {"$set": {
            "is_active": new_status,
            "status": "active" if new_status else "disabled",
            "status_updated_at": get_ist_time(),
        }}
    )
    return {
        "message": f"Intern status updated to {'Active' if new_status else 'Deactivated'}.",
        "is_active": new_status
    }

@router.post("/sync-all")
async def sync_all_performance(db=Depends(get_db)):
    """
    Bulk analyze all interns and update their labels/progress in MongoDB.
    This makes the performance dashboard data-driven.
    """
    interns = await db["users"].find({"role": "INTERN"}).to_list(length=500)
    total_days = await _get_total_working_days(db)
    
    updated_count = 0
    for intern in interns:
        metrics = await _calculate_intern_metrics(db, intern, total_days)
        
        await db["users"].update_one(
            {"_id": intern["_id"]},
            {"$set": {
                "performance_label": metrics["suggested_label"],
                "overall_progress": int(metrics["overall_index"]),
                "last_automated_sync": get_ist_time()
            }}
        )
        updated_count += 1
        
    return {"message": f"Successfully synchronized performance for {updated_count} interns."}
