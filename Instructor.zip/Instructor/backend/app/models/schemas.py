from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime

class UserBase(BaseModel):
    email: str
    role: str # "INTERN", "INSTRUCTOR", "ADMIN"
    full_name: str

class UserCreate(UserBase):
    password: str

class UserInDB(UserBase):
    user_id: str
    hashed_password: str
    is_verified: bool = False
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Token(BaseModel):
    access_token: str
    token_type: str
