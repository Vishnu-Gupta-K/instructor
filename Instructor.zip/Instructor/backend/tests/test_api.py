from datetime import datetime

import pytest
from httpx import ASGITransport, AsyncClient

import instructor_portal_app.api.auth as instructor_auth
from instructor_portal_app.core.config import get_ist_time
from instructor_portal_app.core.security import get_password_hash, verify_password
from instructor_portal_main import app


@pytest.mark.anyio
async def test_unit_password_hash_round_trip():
    password = "FacultyPass123!"
    hashed = get_password_hash(password)
    assert verify_password(password, hashed)


@pytest.mark.anyio
async def test_app_serves_shell_pages():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        root_response = await client.get("/")
        assert root_response.status_code == 200
        assert "text/html" in root_response.headers["content-type"]

        login_response = await client.get("/login")
        assert login_response.status_code == 200
        assert "text/html" in login_response.headers["content-type"]


@pytest.mark.anyio
async def test_integration_login_tasks_and_stats(fake_db):
    instructor_email = "faculty.one@gmail.com"
    instructor_password = "FacultyPass123!"
    intern_email = "intern.one@gmail.com"
    intern_user_id = "SPX_INTERN_202601"

    await fake_db["users"].insert_one(
        {
            "email": instructor_email,
            "user_id": "SPX_INSTRUCTOR_202601",
            "role": "INSTRUCTOR",
            "full_name": "Faculty One",
            "hashed_password": get_password_hash(instructor_password),
            "is_verified": True,
        }
    )
    await fake_db["users"].insert_one(
        {
            "email": intern_email,
            "user_id": intern_user_id,
            "role": "INTERN",
            "full_name": "Intern One",
            "hashed_password": get_password_hash("InternPass123!"),
            "is_verified": True,
        }
    )

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        login_response = await client.post(
            "/api/auth/login",
            json={"email": instructor_email, "password": instructor_password},
        )
        assert login_response.status_code == 200
        token = login_response.json()["access_token"]

        me_response = await client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert me_response.status_code == 200
        assert me_response.json()["user_id"] == "SPX_INSTRUCTOR_202601"

        task_response = await client.post(
            "/api/tasks/create",
            json={
                "title": "API Project",
                "description": "Build the service",
                "assigned_to": [intern_user_id],
            },
        )
        assert task_response.status_code == 200

        task_list_response = await client.get("/api/tasks/list")
        assert task_list_response.status_code == 200
        tasks = task_list_response.json()
        assert len(tasks) == 1
        assert tasks[0]["submission_count"] == 0

        stats_response = await client.get("/api/system/stats")
        assert stats_response.status_code == 200
        stats = stats_response.json()
        assert stats["counts"]["interns"] == 1
        assert stats["counts"]["tasks"] == 1


@pytest.mark.anyio
async def test_e2e_instructor_password_reset_flow(fake_db, monkeypatch):
    email = "faculty.reset@gmail.com"
    old_password = "OldFacultyPass123!"
    new_password = "NewFacultyPass123!"

    await fake_db["users"].insert_one(
        {
            "email": email,
            "user_id": "SPX_INSTRUCTOR_202602",
            "role": "INSTRUCTOR",
            "full_name": "Faculty Reset",
            "hashed_password": get_password_hash(old_password),
            "is_verified": True,
        }
    )

    async def fake_send(*args, **kwargs):
        return None

    monkeypatch.setattr(instructor_auth, "send", fake_send)

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        forgot_response = await client.post("/api/auth/forgot-password", json={"email": email})
        assert forgot_response.status_code == 200

        otp_record = await fake_db["otp_codes"].find_one({"email": email})
        assert otp_record is not None

        reset_response = await client.post(
            "/api/auth/reset-password",
            json={"email": email, "otp": otp_record["otp"], "new_password": new_password},
        )
        assert reset_response.status_code == 200

        login_response = await client.post("/api/auth/login", json={"email": email, "password": new_password})
        assert login_response.status_code == 200
        assert "access_token" in login_response.json()


@pytest.mark.anyio
async def test_login_rejects_non_instructor_roles(fake_db):
    await fake_db["users"].insert_one(
        {
            "email": "student.login@gmail.com",
            "user_id": "SPX_STUDENT_LOGIN_001",
            "role": "INTERN",
            "full_name": "Student Login",
            "hashed_password": get_password_hash("StudentPass123!"),
            "is_verified": True,
        }
    )

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/api/auth/login",
            json={"email": "student.login@gmail.com", "password": "StudentPass123!"},
        )

    assert response.status_code == 403
    assert response.json()["detail"] == "Please enter valid details."


@pytest.mark.anyio
async def test_attendance_pending_students_and_override_completion(fake_db):
    student_one = {
        "email": "student.one@gmail.com",
        "user_id": "SPX_STUDENT_001",
        "role": "INTERN",
        "full_name": "Student One",
        "hashed_password": get_password_hash("StudentPass123!"),
        "is_verified": True,
    }
    student_two = {
        "email": "student.two@gmail.com",
        "user_id": "SPX_STUDENT_002",
        "role": "INTERN",
        "full_name": "Student Two",
        "hashed_password": get_password_hash("StudentPass123!"),
        "is_verified": True,
    }

    await fake_db["users"].insert_one(student_one)
    await fake_db["users"].insert_one(student_two)
    await fake_db["attendance_logs"].insert_one(
        {
            "student_id": student_one["user_id"],
            "student_email": student_one["email"],
            "student_name": student_one["full_name"],
            "status": "present",
            "method": "manual_override",
            "reason": "Marked already",
            "timestamp": get_ist_time(),
            "ip_verified": True,
            "geo_verified": True,
            "verified": True,
        }
    )

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        pending_response = await client.get("/api/attendance/pending-students")
        assert pending_response.status_code == 200
        pending_students = pending_response.json()
        assert len(pending_students) == 1
        assert pending_students[0]["user_id"] == student_two["user_id"]
        assert pending_students[0]["display_name"] == student_two["full_name"]

        override_response = await client.post(
            "/api/attendance/override",
            json={
                "student_id": student_two["user_id"],
                "status": "present",
                "reason": "Manual attendance correction",
            },
        )
        assert override_response.status_code == 200

        duplicate_response = await client.post(
            "/api/attendance/override",
            json={
                "student_id": student_two["user_id"],
                "status": "present",
                "reason": "Manual attendance correction",
            },
        )
        assert duplicate_response.status_code == 409

        completion_response = await client.get("/api/attendance/pending-students")
        assert completion_response.status_code == 200
        assert completion_response.json() == []


@pytest.mark.anyio
async def test_mock_results_and_question_sync_endpoints(fake_db):
    mock_insert = await fake_db["mocks"].insert_one(
        {
            "title": "Mock Backend Validation",
            "description": "Ensure instructor mock controls are wired",
            "duration": 20,
            "category": "General",
            "is_active": True,
            "questions": [],
            "created_at": get_ist_time(),
        }
    )
    mock_id = str(mock_insert.inserted_id)

    await fake_db["mock_results"].insert_one(
        {
            "exam_id": mock_id,
            "student_id": "SPX_INTERN_201",
            "student_name": "Intern Alpha",
            "score": 7,
            "max_score": 10,
            "submitted_at": get_ist_time(),
        }
    )
    await fake_db["mock_results"].insert_one(
        {
            "exam_id": mock_id,
            "student_id": "SPX_INTERN_202",
            "student_name": "Intern Beta",
            "score": 9,
            "max_score": 10,
            "submitted_at": get_ist_time(),
        }
    )

    questions_payload = [
        {
            "type": "mcq",
            "text": "2 + 2 = ?",
            "options": ["3", "4"],
            "correct_answer_index": 1,
            "points": 5,
        }
    ]

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        list_response = await client.get("/api/mocks/list")
        assert list_response.status_code == 200
        mocks = list_response.json()
        target = next(m for m in mocks if m["_id"] == mock_id)
        assert target["results_count"] == 2

        results_response = await client.get(f"/api/mocks/results/{mock_id}")
        assert results_response.status_code == 200
        results = results_response.json()
        assert len(results) == 2

        sync_response = await client.patch(
            f"/api/mocks/{mock_id}/questions",
            json=questions_payload,
        )
        assert sync_response.status_code == 200

    stored_mock = await fake_db["mocks"].find_one({"_id": mock_insert.inserted_id})
    assert stored_mock is not None
    assert stored_mock["questions"] == questions_payload