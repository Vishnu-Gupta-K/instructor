import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_generate_question_success():
    """Test generating a coding question via AI."""
    payload = {
        "topic": "Python Recursion",
        "difficulty": "Medium",
        "count": 1
    }
    response = client.post("/api/ai-generator/generate-question", json=payload, follow_redirects=False)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert len(data["questions"]) == 1
    assert "Python Recursion" in data["questions"][0]["tags"]

def test_generate_question_invalid_count():
    """Test with zero count - should still work or return empty."""
    payload = {
        "topic": "SQL Joins",
        "count": 0
    }
    response = client.post("/api/ai-generator/generate-question", json=payload, follow_redirects=False)
    assert response.status_code == 200
    assert len(response.json()["questions"]) == 0

def test_generate_question_missing_topic():
    """Test validation error for missing topic."""
    payload = {
        "difficulty": "Hard"
    }
    response = client.post("/api/ai-generator/generate-question", json=payload)
    assert response.status_code == 422 # Unprocessable Entity
