from pathlib import Path
import sys
import importlib

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

for module_name in list(sys.modules):
    if module_name == "main" or module_name == "app" or module_name.startswith("app."):
        del sys.modules[module_name]

portal_main = importlib.import_module("main")
portal_app = importlib.import_module("app")
for module_name, module in list(sys.modules.items()):
    if module_name == "main":
        sys.modules["instructor_portal_main"] = module
    elif module_name == "app" or module_name.startswith("app."):
        sys.modules[module_name.replace("app", "instructor_portal_app", 1)] = module

app = portal_main.app
from app.core.database import get_db
from testing_utils import FakeDatabase


@pytest.fixture
def fake_db():
    database = FakeDatabase()

    async def override_get_db():
        yield database

    app.dependency_overrides[get_db] = override_get_db
    yield database
    app.dependency_overrides.clear()