from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

# ─── API Routers ────────────────────────────────────────────
from app.api.auth        import router as auth_router
from app.api.tasks       import router as tasks_router
from app.api.projects    import router as projects_router
from app.api.exams       import router as exams_router
from app.api.mocks       import router as mocks_router
from app.api.interviews  import router as interviews_router
from app.api.attendance  import router as att_router
from app.api.performance import router as perf_router
from app.api.leaves      import router as leaves_router
from app.api.system       import router as system_router
from app.api.ai_review    import router as ai_review_router
from app.api.ai_generator import router as ai_gen_router

# ─── App Init ───────────────────────────────────────────────
app = FastAPI(
    title="SPX Faculty Command Center API",
    description="Real-time instructor portal backed by MongoDB Atlas.",
    version="5.0.0"
)

# ─── CORS ───────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Route Registration ─────────────────────────────────────
app.include_router(auth_router,        prefix="/api/auth",        tags=["Auth"])
app.include_router(tasks_router,       prefix="/api/tasks",       tags=["Tasks"])
app.include_router(projects_router,    prefix="/api/projects",    tags=["Projects"])
app.include_router(exams_router,       prefix="/api/exams",       tags=["Exams"])
app.include_router(mocks_router,       prefix="/api/mocks",       tags=["Mocks"])
app.include_router(interviews_router,  prefix="/api/interviews",  tags=["Interviews"])
app.include_router(att_router,         prefix="/api/attendance",  tags=["Attendance"])
app.include_router(perf_router,        prefix="/api/performance", tags=["Performance"])
app.include_router(leaves_router,      prefix="/api/leaves",      tags=["Leaves"])
app.include_router(system_router,      prefix="/api/system",      tags=["System"])
app.include_router(ai_review_router,   prefix="/api/ai",          tags=["AI Review"])
app.include_router(ai_gen_router,      prefix="/api/ai-generator", tags=["AI Generator"])

# ─── Static File Serving ────────────────────────────────────
BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR  = os.path.normpath(os.path.join(BASE_DIR, "..", "frontend"))

# Mount CSS and JS first (high-precedence static nodes)
app.mount("/css", StaticFiles(directory=os.path.join(FRONTEND_DIR, "css")), name="css")
app.mount("/js",  StaticFiles(directory=os.path.join(FRONTEND_DIR, "js")),  name="js")


# ─── Page Routes ────────────────────────────────────────────
@app.get("/")
async def root():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

@app.get("/login")
async def login_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "login.html"))

@app.get("/dashboard")
async def dashboard_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "dashboard.html"))

@app.get("/forgot-password")
async def forgot_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "forgot-password.html"))

@app.get("/reset-password")
async def reset_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "reset-password.html"))

# ─── Catch-All (SPA Fallback) ───────────────────────────────
@app.get("/{page:path}")
async def catch_all(page: str):
    clean = page.lstrip("/")
    
    # NEW: If it's an API route that reached here, return 404 JSON instead of HTML
    if clean.startswith("api/"):
        return {"detail": "Endpoint not found"}

    if not clean:
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))
    # Direct file check
    target = os.path.join(FRONTEND_DIR, clean)
    if os.path.isfile(target):
        return FileResponse(target)
    # Virtual route → try page.html
    if "." not in clean:
        html_target = os.path.join(FRONTEND_DIR, f"{clean.split('/')[-1]}.html")
        if os.path.isfile(html_target):
            return FileResponse(html_target)
    # SPA fallback
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


# ─── Entry Point ────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
