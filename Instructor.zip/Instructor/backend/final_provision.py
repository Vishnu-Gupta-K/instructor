import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import bcrypt
from datetime import datetime, timezone

MONGO_URI = "mongodb+srv://spheronix:spheronix@dashboard.bjygupo.mongodb.net/?appName=Dashboard"
DATABASE_NAME = "spx_dashboard"

async def provision():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DATABASE_NAME]
    
    email = "faculty@spx.system"
    password = "password123"
    
    # Direct bcrypt hash (matching my new security.py logic)
    password_bytes = password[:72].encode('utf-8')
    hashed_password = bcrypt.hashpw(password_bytes, bcrypt.gensalt()).decode('utf-8')
    
    existing = await db["users"].find_one({"email": email})
    if existing:
        print(f"Updating existing user: {email}")
        await db["users"].update_one({"email": email}, {"$set": {"role": "INSTRUCTOR", "hashed_password": hashed_password}})
    else:
        print(f"Creating new faculty user: {email}")
        new_user = {
            "user_id": "SPX_INST_DEF_2026",
            "email": email,
            "role": "INSTRUCTOR",
            "full_name": "Faculty Alpha",
            "hashed_password": hashed_password,
            "is_verified": True,
            "created_at": datetime.now(timezone.utc)
        }
        await db["users"].insert_one(new_user)
    
    print("Provisioning Complete.")

if __name__ == "__main__":
    asyncio.run(provision())
