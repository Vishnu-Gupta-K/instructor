import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from passlib.context import CryptContext
from pymongo import ReturnDocument
import os
from datetime import datetime, timezone

# Sync with backend settings
MONGO_URI = "mongodb+srv://spheronix:spheronix@dashboard.bjygupo.mongodb.net/?appName=Dashboard"
DATABASE_NAME = "spx_dashboard"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

async def create_faculty():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DATABASE_NAME]
    
    email = "faculty@spx.system"
    password = "password123"
    
    # Check if exists
    existing = await db["users"].find_one({"email": email})
    if existing:
        print(f"User {email} already exists. Updating role to INSTRUCTOR.")
        await db["users"].update_one({"email": email}, {"$set": {"role": "INSTRUCTOR", "hashed_password": pwd_context.hash(password[:72])}})
    else:
        # Generate user_id
        seq = await db["sequences"].find_one_and_update(
            {"_id": "INSTRUCTOR"},
            {"$inc": {"sequence_value": 1}},
            upsert=True,
            return_document=ReturnDocument.AFTER
        )
        padded_seq = str(seq["sequence_value"]).zfill(2)
        user_id = f"SPX_INSTRUCTOR_2026{padded_seq}"
        
        new_user = {
            "user_id": user_id,
            "email": email,
            "role": "INSTRUCTOR",
            "full_name": "SPX Faculty Alpha",
            "hashed_password": pwd_context.hash(password[:72]),
            "is_verified": True,
            "created_at": datetime.now(timezone.utc)
        }
        await db["users"].insert_one(new_user)
        print(f"Created Faculty Identity: {user_id}")

if __name__ == "__main__":
    asyncio.run(create_faculty())
